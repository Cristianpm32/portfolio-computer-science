package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import io.reactivex.rxjava3.core.Observable;

public interface LogInUseCase {
  Observable<Client> execute(ClientId username, String enteredPassword);

  enum Error implements StudenError {
    USERNAME_EMPTY,
    PASSWORD_EMPTY,
    CLIENT_NOT_FOUND,
    PASSWORD_INCORRECT,
    CLIENTS_DATA_ACCESS_ERROR;
  }
}
