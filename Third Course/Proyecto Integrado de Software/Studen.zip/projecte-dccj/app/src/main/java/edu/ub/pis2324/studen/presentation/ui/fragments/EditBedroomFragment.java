package edu.ub.pis2324.studen.presentation.ui.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import java.util.ArrayList;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentEditBedroomBinding;
import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.viewmodels.EditBedroomViewModel;
import edu.ub.pis2324.studen.utils.livedata.StateData;

public class EditBedroomFragment extends Fragment {

    private EditBedroomViewModel editBedroomViewModel;

    /* View binding & navigation */
    private AppContainer appContainer;
    private NavController navController;
    private FragmentEditBedroomBinding binding;


    private boolean typeBedroomClicked;
    private boolean typeApartmentClicked;
    private boolean typeHouseClicked;

    private BedroomType bedroomType;

    // View Control
    private boolean balconyClicked;
    private boolean terraceClicked;
    private boolean bathroomClicked;
    private boolean kitchenClicked;
    private boolean exteriorClicked;
    private boolean furnishedClicked;

    

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentEditBedroomBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        binding.smallCl.setVisibility(View.GONE);
        binding.afegirBedroom.setVisibility(View.GONE);

        initViewModels();
    }


    private void initConfigEditBedroom() {

        binding.smallCl.setVisibility(View.VISIBLE);

        typeHouseClicked = false;
        typeApartmentClicked = false;
        typeBedroomClicked = false;

        binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border);
        binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border);
        binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border);

        balconyClicked = false;
        terraceClicked = false;
        bathroomClicked = false;
        kitchenClicked = false;
        exteriorClicked = false;
        furnishedClicked = false;

        // Inicialitzem els botons amb l'aparença de no clicats
        binding.btnBalcony.setBackgroundResource(R.drawable.button_border);
        binding.btnTerrace.setBackgroundResource(R.drawable.button_border);
        binding.btnBathroom.setBackgroundResource(R.drawable.button_border);
        binding.btnKitchen.setBackgroundResource(R.drawable.button_border);
        binding.btnExterior.setBackgroundResource(R.drawable.button_border);
        binding.btnFurnished.setBackgroundResource(R.drawable.button_border);

        initWidgetListeners();
    }

    private void initWidgetListeners() {

        binding.imBtnTypeBedroomABTA.setOnClickListener(ignoredView -> {
            if (!typeBedroomClicked) {

                binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border_pressed);
                typeBedroomClicked = true;
                bedroomType = BedroomType.BEDROOM;

                binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border);
                typeApartmentClicked = false;

                binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border);
                typeHouseClicked = false;
            }
            checkDesar();
        });

        binding.imBtnTypeApartmentABTA.setOnClickListener(ignoredView -> {
            if (!typeApartmentClicked) {

                binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border);
                typeBedroomClicked = false;

                binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border_pressed);
                typeApartmentClicked = true;
                bedroomType = BedroomType.APARTMENT;

                binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border);
                typeHouseClicked = false;
            }
            checkDesar();
        });

        binding.imBtnTypeHouseABTA.setOnClickListener(ignoredView -> {
            if (!typeHouseClicked) {

                binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border);
                typeBedroomClicked = false;

                binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border);
                typeApartmentClicked = false;

                binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border_pressed);
                typeHouseClicked = true;
                bedroomType = BedroomType.HOUSE;
            }
            checkDesar();
        });

        // PER FUNCIONAR ELS BOTONS DE FEATURES
        binding.btnBalcony.setOnClickListener(ignoredView -> {
            if (!balconyClicked) {
                binding.btnBalcony.setBackgroundResource(R.drawable.button_border_pressed);
                balconyClicked = true;
            } else {
                binding.btnBalcony.setBackgroundResource(R.drawable.button_border);
                balconyClicked = false;
            }
            checkDesar();
        });

        binding.btnTerrace.setOnClickListener(ignoredView -> {
            if (!terraceClicked) {
                binding.btnTerrace.setBackgroundResource(R.drawable.button_border_pressed);
                terraceClicked = true;
            } else {
                binding.btnTerrace.setBackgroundResource(R.drawable.button_border);
                terraceClicked = false;
            }
            checkDesar();
        });

        binding.btnBathroom.setOnClickListener(ignoredView -> {
            if (!bathroomClicked) {
                binding.btnBathroom.setBackgroundResource(R.drawable.button_border_pressed);
                bathroomClicked = true;
            } else {
                binding.btnBathroom.setBackgroundResource(R.drawable.button_border);
                bathroomClicked = false;
            }
            checkDesar();
        });

        binding.btnKitchen.setOnClickListener(ignoredView -> {
            if (!kitchenClicked) {
                binding.btnKitchen.setBackgroundResource(R.drawable.button_border_pressed);
                kitchenClicked = true;
            } else {
                binding.btnKitchen.setBackgroundResource(R.drawable.button_border);
                kitchenClicked = false;
            }
            checkDesar();
        });

        binding.btnExterior.setOnClickListener(ignoredView -> {
            if (!exteriorClicked) {
                binding.btnExterior.setBackgroundResource(R.drawable.button_border_pressed);
                exteriorClicked = true;
            } else {
                binding.btnExterior.setBackgroundResource(R.drawable.button_border);
                exteriorClicked = false;
            }
            checkDesar();
        });

        binding.btnFurnished.setOnClickListener(ignoredView -> {
            if (!furnishedClicked) {
                binding.btnFurnished.setBackgroundResource(R.drawable.button_border_pressed);
                furnishedClicked = true;
            } else {
                binding.btnFurnished.setBackgroundResource(R.drawable.button_border);
                furnishedClicked = false;
            }
            checkDesar();
        });
        // FI BOTONS DE FEATURES

        // ESCOLTADORS DELS TEXTOS
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override
            public void afterTextChanged(Editable s) {
                checkDesar();
            }
        };

        binding.etCountryABTA.addTextChangedListener(textWatcher);
        binding.etCityABTA.addTextChangedListener(textWatcher);
        binding.etDirectionABTA.addTextChangedListener(textWatcher);
        binding.etPostalCodeABTA.addTextChangedListener(textWatcher);
        binding.etSquaredMetersABF.addTextChangedListener(textWatcher);
        binding.etDescriptionABF.addTextChangedListener(textWatcher);


        // Guardem els canvis
        binding.btnDesarABF.setOnClickListener(ignoredView -> {

            float squaredMeters = Float.parseFloat(String.valueOf(binding.etSquaredMetersABF.getText()));
            String description = binding.etDescriptionABF.getText().toString();



            BedroomType bedroomType;
            if(typeBedroomClicked) bedroomType = BedroomType.BEDROOM;
            else if(typeApartmentClicked) bedroomType = BedroomType.APARTMENT;
            else bedroomType = BedroomType.HOUSE;
            ArrayList<BedroomFeatures> features = gatherFeatures();

            Address address = gatherAddress();

            editBedroomViewModel.editBedroom(squaredMeters, features, description, address, bedroomType);

        });
    }

    private void initConfigNoBedroom() {
        binding.smallCl.setVisibility(View.GONE);
        binding.afegirBedroom.setVisibility(View.VISIBLE);

        // Listener botó
        binding.afegirBedroom.setOnClickListener( ignoredView -> {
            navController.navigate(R.id.action_bedroomFragment_to_addBedroom);
        });
    }

    private void initViewModels() {
        editBedroomViewModel = new ViewModelProvider(this, new EditBedroomViewModel.Factory(
                appContainer.editBedroomUseCase,
                appContainer.fetchBedroomByClientIdUseCase,
                getActivity().getApplication())).get(EditBedroomViewModel.class);

        initObservers();
    }

    private void initObservers() {
        editBedroomViewModel.getBedroomPO().observe(getViewLifecycleOwner(), bedroom -> {
            switch (bedroom.getStatus()) {
                case SUCCESS:
                    fillData(bedroom);
                    break;
                case ERROR:
                    initConfigNoBedroom();
                    break;
            }
        });

        editBedroomViewModel.getEditBedroomState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    Toast.makeText(getContext(), "Habitació editada correctament", Toast.LENGTH_SHORT).show();
                    binding.btnDesarABF.setBackgroundResource(R.drawable.button_shape_gray);
                    binding.btnDesarABF.setEnabled(false);
                    break;
                case ERROR:
                    Toast.makeText(getContext(), "Error al editar la habitació", Toast.LENGTH_SHORT).show();
                    break;
            }
        });
    }



    private void fillData(StateData<BedroomPO> bedroom) {

        initConfigEditBedroom();

        BedroomPO bedroomPO = bedroom.getData();

        // Address
        binding.etCountryABTA.setText(String.valueOf(bedroomPO.getAddress().getCountry()));
        binding.etCityABTA.setText(String.valueOf(bedroomPO.getAddress().getCity()));
        binding.etDirectionABTA.setText(String.valueOf(bedroomPO.getAddress().getStreet()));
        binding.etPostalCodeABTA.setText(String.valueOf(bedroomPO.getAddress().getPostalCode()));

        // Bedroom Type
        if (bedroomPO.getType() == BedroomType.BEDROOM) {
            binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border_pressed);
            typeBedroomClicked = true;
        } else if (bedroomPO.getType() == BedroomType.APARTMENT) {
            binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border_pressed);
            typeApartmentClicked = true;
        } else {
            binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border_pressed);
            typeHouseClicked = true;
        }

        // Features
        ArrayList<BedroomFeatures> features = bedroomPO.getFeatures();
        if (features.contains(BedroomFeatures.BATHROOM)) {
            binding.btnBathroom.setBackgroundResource(R.drawable.button_border_pressed);
            bathroomClicked = true;
        }
        if (features.contains(BedroomFeatures.BALCONY)) {
            binding.btnBalcony.setBackgroundResource(R.drawable.button_border_pressed);
            balconyClicked = true;
        }
        if (features.contains(BedroomFeatures.EXTERIOR)) {
            binding.btnExterior.setBackgroundResource(R.drawable.button_border_pressed);
            exteriorClicked = true;
        }
        if (features.contains(BedroomFeatures.FURNISHED)) {
            binding.btnFurnished.setBackgroundResource(R.drawable.button_border_pressed);
            furnishedClicked = true;
        }
        if (features.contains(BedroomFeatures.KITCHEN)) {
            binding.btnKitchen.setBackgroundResource(R.drawable.button_border_pressed);
            kitchenClicked = true;
        }
        if (features.contains(BedroomFeatures.TERRACE)) {
            binding.btnTerrace.setBackgroundResource(R.drawable.button_border_pressed);
            terraceClicked = true;
        }
        binding.etSquaredMetersABF.setText(String.valueOf(bedroomPO.getSize()));

        // Descripció
        binding.etDescriptionABF.setText(String.valueOf(bedroomPO.getDescription()));

        // Ara que està tot omplert desactivem desar fins que es realitzi un canvi.
        binding.btnDesarABF.setBackgroundResource(R.drawable.button_shape_gray);
        binding.btnDesarABF.setText("Desar canvis");
        binding.btnDesarABF.setEnabled(false);
    }

    private Address gatherAddress() {
        String country = binding.etCountryABTA.getText().toString();
        String city = binding.etCityABTA.getText().toString();
        String street = binding.etDirectionABTA.getText().toString();
        String postalCode = binding.etPostalCodeABTA.getText().toString();

        return new Address(street,city,postalCode,country);
    }

    private ArrayList<BedroomFeatures> gatherFeatures() {
        ArrayList<BedroomFeatures> features = new ArrayList<>();

        if (balconyClicked) features.add(BedroomFeatures.BALCONY);

        if (terraceClicked) features.add(BedroomFeatures.TERRACE);

        if (bathroomClicked) features.add(BedroomFeatures.BATHROOM);

        if (kitchenClicked) features.add(BedroomFeatures.KITCHEN);

        if (exteriorClicked) features.add(BedroomFeatures.EXTERIOR);

        if (furnishedClicked) features.add(BedroomFeatures.FURNISHED);

        return features;
    }

    void checkDesar() {

        boolean textCountry = binding.etCountryABTA.getText().length() > 0;
        boolean textCity = binding.etCityABTA.getText().length() > 0;
        boolean textDirection = binding.etDirectionABTA.getText().length() > 0;
        boolean textPostalCode = binding.etPostalCodeABTA.getText().length() > 0;
        boolean textSquaredMeters = binding.etSquaredMetersABF.getText().length() > 0;
        boolean textDescription = binding.etDescriptionABF.getText().length() > 0;

        boolean typeClicked = typeBedroomClicked || typeApartmentClicked || typeHouseClicked;
        if (textCity && textCountry && textDirection && textPostalCode && typeClicked && textSquaredMeters && textDescription) {
            binding.btnDesarABF.setBackgroundResource(R.drawable.button_shape_black);
            binding.btnDesarABF.setText("Desar canvis");
            binding.btnDesarABF.setEnabled(true);
        } else {
            binding.btnDesarABF.setBackgroundResource(R.drawable.button_shape_gray);
            binding.btnDesarABF.setText("Desar canvis");
            binding.btnDesarABF.setEnabled(false);
        }
    }
}
