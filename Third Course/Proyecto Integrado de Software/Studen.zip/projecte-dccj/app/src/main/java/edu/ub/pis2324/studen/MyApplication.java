package edu.ub.pis2324.studen;

import android.app.Application;

/**
 *  AQUEST ÉS EL PUNT D'ENTRADA PER A L'APLICACIÓ, NOMÉS INSTANCIA AppContainer.
 */
public class MyApplication extends Application {

    private AppContainer appContainer;

    @Override
    public void onCreate() {
        super.onCreate();
        appContainer = new AppContainer();
    }

    public AppContainer getAppContainer() {
        return appContainer;
    }

}
