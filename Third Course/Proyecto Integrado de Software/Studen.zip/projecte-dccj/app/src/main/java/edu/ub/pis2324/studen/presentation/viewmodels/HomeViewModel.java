package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientFavoriteBedroomsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchPopularBedroomsUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class HomeViewModel extends ViewModel {


    // Use cases

    private final FetchPopularBedroomsUseCase fetchPopularBedroomsUseCase;
    private final FetchClientUseCase fetchClientUseCase;
    private final FetchClientFavoriteBedroomsUseCase fetchClientFavoriteBedroomsUseCase;


    // Presentation Objects
    private List<BedroomPO> popularBedroomPOs;
    private List<BedroomPO> favoriteBedroomPOs;

    private final ClientId clientId;
    private ClientPO clientPO;

    private StateLiveData<ClientPO> clientState;

    /* LiveData */
    private StateLiveData<List<BedroomPO>> popularBedroomListState;  // bedrooms' list
    private StateLiveData<List<BedroomPO>> favoriteBedroomListState;  // favorite bedrooms' list
    private StateLiveData<Integer> hiddenBedroomState;
    /* RxJava */
    private CompositeDisposable compositeDisposable;

    private final DomainToPOMapper domainToPOMapper;


    /**
     * Parent class (ViewModel's) lifecycle-related method
     * that is invoked when the activity is purposedly destroyed.
     */

    public HomeViewModel(Application application, FetchPopularBedroomsUseCase fetchPopularBedroomsUseCase, FetchClientFavoriteBedroomsUseCase fetchClientFavoriteBedroomsUseCase, FetchClientUseCase fetchClientUseCase) {
        super();

        this.fetchPopularBedroomsUseCase = fetchPopularBedroomsUseCase;
        this.fetchClientFavoriteBedroomsUseCase = fetchClientFavoriteBedroomsUseCase;
        this.fetchClientUseCase = fetchClientUseCase;
        popularBedroomPOs = new ArrayList<>();
        favoriteBedroomPOs = new ArrayList<>();
        popularBedroomListState = new StateLiveData<>();
        favoriteBedroomListState = new StateLiveData<>();
        hiddenBedroomState = new StateLiveData<>();
        compositeDisposable = new CompositeDisposable();
        domainToPOMapper = DomainToPOMapper.getInstance();
        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("CLIENT_MODEL", null);
        clientId = new Gson().fromJson(json, ClientPO.class).getId();

        clientState = new StateLiveData<>();
        fetchClient(clientId);

    }

    private void fetchClient(ClientId clientId) {
        clientState.postLoading();
        Disposable d = fetchClientUseCase.execute(clientId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        gottenClient -> {
                            clientPO = domainToPOMapper.map(gottenClient, ClientPO.class);
                            clientState.postSuccess(clientPO);
                        },
                        throwable -> clientState.postError(throwable)
                );
        compositeDisposable.add(d);
    }

    public StateLiveData<ClientPO> getClientState() {
        fetchClient(clientId);
        return clientState;
    }

    @Override
    public void onCleared() {
        super.onCleared();
        compositeDisposable.dispose();
    }

    /**
     * Returns the state of the bedrooms being fetched
     *
     * @return the state of the bedrooms being fetched
     */
    public StateLiveData<List<BedroomPO>> getPopularBedroomListState() {
        fetchPopularBedrooms();
        return popularBedroomListState;
    }

    public StateLiveData<List<BedroomPO>> getFavoriteBedroomListState() {
        
        Disposable d = fetchClientUseCase.execute(clientId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        gottenClient -> {
                            clientPO = domainToPOMapper.map(gottenClient, ClientPO.class);
                            fetchClientFavoriteBedrooms(clientPO.getId());
                        },
                        throwable -> clientState.postError(throwable)
                );
        compositeDisposable.add(d);

        return favoriteBedroomListState;
    }


    /**
     * Returns the state of the bedroom being hidden
     *
     * @return
     */
    public StateLiveData<Integer> getHiddenBedroomState() {
        return hiddenBedroomState;
    }

    /**
     * Fetches the bedrooms from a data store
     */


    public void fetchClientFavoriteBedrooms(ClientId clientId) {
        /*
        To inform to the activity that the bedrooms are being fetched,
        in case it wants to show a loading spinner or something.
        */
        favoriteBedroomListState.postLoading();
        Disposable d = fetchClientFavoriteBedroomsUseCase
                .execute(clientId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        gottenBedrooms -> handleFetchBedroomsCatalogSuccess(gottenBedrooms, favoriteBedroomListState, favoriteBedroomPOs),
                        throwable -> handleFetchProductsCatalogError(throwable, favoriteBedroomListState)
                );
        compositeDisposable.add(d);

    }


    public void fetchPopularBedrooms() {
        /*
        To inform to the activity that the bedrooms are being fetched,
        in case it wants to show a loading spinner or something.
        */
        popularBedroomListState.postLoading();

        /*
        Now we ask for the bedrooms to some service/respository/usecase.
        But the response is asychronous, so we ask the bedroomRepository
        to set an observable and we subscribe to it.
        */
        Disposable d = fetchPopularBedroomsUseCase.execute()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        gottenBedrooms -> handleFetchBedroomsCatalogSuccess(gottenBedrooms, popularBedroomListState, popularBedroomPOs),
                        throwable -> handleFetchProductsCatalogError(throwable, popularBedroomListState)
                );
        compositeDisposable.add(d);
    }


    public void handleFetchBedroomsCatalogSuccess(List<Bedroom> gottenProducts, StateLiveData<List<BedroomPO>> bedroomListState, List<BedroomPO> genericBedroomPOs) {
        // Presentation code
        List<BedroomPO> gottenProductPOs = gottenProducts
                .stream()
                .map(product -> domainToPOMapper.map(product, BedroomPO.class))
                .collect(Collectors.toList());

        genericBedroomPOs.clear();
        genericBedroomPOs.addAll(gottenProductPOs);
        bedroomListState.postSuccess(genericBedroomPOs);
    }

    public void handleFetchProductsCatalogError(Throwable throwable, StateLiveData<List<BedroomPO>> bedroomListState) {
        String message;
        StudenError xError = ((StudenThrowable) throwable).getError();
        if (xError == FetchPopularBedroomsUseCase.Error.BEDROOMS_DATA_ACCESS_ERROR)
            message = "Data access error";
        else
            message = "Unknown error";

        bedroomListState.postError(new Throwable(message));
    }

    /**
     * Hides a product
     *
     * @param position
     */
    public void hideProduct(int position) {
        popularBedroomPOs.remove(position);
        hiddenBedroomState.postSuccess(position);
        favoriteBedroomPOs.remove(position);
        hiddenBedroomState.postSuccess(position);

    }

    /**
     * Factory for the ViewModel to be able to pass parameters to the constructor
     */

    public static class Factory extends ViewModelProvider.NewInstanceFactory {


        private final FetchPopularBedroomsUseCase fetchPopularBedroomsUseCase;

        private final FetchClientUseCase fetchClientUseCase;
        private final FetchClientFavoriteBedroomsUseCase fetchClientFavoriteBedroomsUseCase;


        private final Application application;

        public Factory(Application application, FetchPopularBedroomsUseCase fetchPopularBedroomsUseCase, FetchClientFavoriteBedroomsUseCase fetchClientFavoriteBedroomsUseCase, FetchClientUseCase fetchClientUseCase) {
            this.application = application;
            this.fetchPopularBedroomsUseCase = fetchPopularBedroomsUseCase;
            this.fetchClientFavoriteBedroomsUseCase = fetchClientFavoriteBedroomsUseCase;
            this.fetchClientUseCase = fetchClientUseCase;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            if (modelClass.isAssignableFrom(HomeViewModel.class)) {
                return (T) new HomeViewModel(application, fetchPopularBedroomsUseCase, fetchClientFavoriteBedroomsUseCase, fetchClientUseCase);
            }
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }
}
