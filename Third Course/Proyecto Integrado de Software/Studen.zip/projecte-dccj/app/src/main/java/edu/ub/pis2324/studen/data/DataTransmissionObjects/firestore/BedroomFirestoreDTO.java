package edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore;

import com.google.firebase.firestore.DocumentId;

import java.util.ArrayList;
import java.util.List;

import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;

public class BedroomFirestoreDTO {

    @DocumentId
    private String id;
    private AddressFirestoreDTO address;
    private String description;
    private boolean popular;
    private float size;
    private float price;
    private String mainPhotoUrl;
    private List<String> photosUrl;
    private String owner;
    private BedroomType type;
    private ArrayList<BedroomFeatures> features;
    private List<RequestFirestoreDTO> requests;
    private String potentialClient;



    public BedroomFirestoreDTO() {

        this.id = "";
        this.address = new AddressFirestoreDTO();
        this.description = "";
        this.popular = false;
        this.size = 0;
        this.price = 0;
        this.mainPhotoUrl = "";
        this.photosUrl = new ArrayList<>();
        this.owner = "";
        this.type = BedroomType.BEDROOM;
        this.features = new ArrayList<>();
        this.requests = new ArrayList<>();
        this.potentialClient = "";
    }

    public String getId() {return id;}
    public AddressFirestoreDTO getAddress() {
        return address;
    }

    public float getSize() {
        return size;
    }

    public float getPrice() {
        return price;
    }

    public String getMainPhotoUrl() {
        return mainPhotoUrl;
    }

    public List<String> getPhotosUrl() {
        return photosUrl;
    }

    public String getOwner() {
        return owner;
    }

    public boolean isPopular() {
        return popular;
    }

    public String getDescription() {
        return description;
    }

    public BedroomType getType() {
        return type;
    }

    public ArrayList<BedroomFeatures> getFeatures() {
        return features;
    }

    public List<RequestFirestoreDTO> getRequests() {
        return requests;
    }
    public String getPotentialClient() {return potentialClient; }
}

