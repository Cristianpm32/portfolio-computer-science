package edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.mappers;

import org.modelmapper.AbstractConverter;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration;
import org.modelmapper.convention.MatchingStrategies;

import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.AddressFirestoreDTO;
import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.ClientFirestoreDTO;
import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.RequestFirestoreDTO;
import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.UniversitatFirestoreDTO;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.domain.model.valueobjects.Universitat;
import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;

/*
 * This class is a singleton that provides a generic ModelMapper instance.
 */
public class DTOToDomainMapper extends ModelMapper {

  public DTOToDomainMapper() {
    super();

    super.getConfiguration()
      .setFieldMatchingEnabled(true) // No need to define setters
      .setFieldAccessLevel(Configuration.AccessLevel.PRIVATE)
      .setMatchingStrategy(MatchingStrategies.LOOSE);


    // Convertim String en ClientId
    super.addConverter(new AbstractConverter<String, ClientId>() {
      @Override
      protected ClientId convert(String source) {
        return new ClientId(source);
      }
    });
    // Convertim String en BedroomId
    super.addConverter(new AbstractConverter<String, BedroomId>() {
      @Override
      protected BedroomId convert(String source) {
        return new BedroomId(source);
      }
    });
    //Convertim AddressFirestoreDTO en Address
    super.addConverter(new AbstractConverter<AddressFirestoreDTO, Address>() {
      @Override
      protected Address convert(AddressFirestoreDTO source) {
        if(source == null) {
          return null;
        }
        else {
          return new Address(source.getStreet(), source.getCity(), source.getPostalCode(), source.getCountry());
        }
      }
    });
    //Convertim UniversitatFirestoreDTO en Universitat
    super.addConverter(new AbstractConverter<UniversitatFirestoreDTO, Universitat>() {
      @Override
        protected Universitat convert(UniversitatFirestoreDTO source) {

            if(source == null) {
                return null;
            }
            else {
              return new Universitat(source.getNom(), DTOToDomainMapper.this.map(source.getAddress(), Address.class));
            }
        }
    });

    //Convertim RequestFirestoreDTO en Request
    super.addConverter(new AbstractConverter<RequestFirestoreDTO, Request>() {
      @Override
      protected Request convert(RequestFirestoreDTO source) {
        if(source == null) {
          return null;
        }
        else {
          return new Request(source.getDataPeticio(), DTOToDomainMapper.this.map(source.getNomClient(), ClientId.class));
        }
      }
    });
  }
}
