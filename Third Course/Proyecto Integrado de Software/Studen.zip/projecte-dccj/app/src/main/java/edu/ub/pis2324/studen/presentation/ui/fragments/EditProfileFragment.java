package edu.ub.pis2324.studen.presentation.ui.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentEditProfileBinding;
import edu.ub.pis2324.studen.databinding.FragmentViewProfileBinding;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.viewmodels.EditProfileViewModel;
import edu.ub.pis2324.studen.presentation.viewmodels.ViewClientProfileViewModel;
import edu.ub.pis2324.studen.utils.ImagePlacer;

public class EditProfileFragment extends Fragment {

    private EditProfileViewModel editProfileViewModel;

    /* View binding & navigation */
    private AppContainer appContainer;
    private NavController navController;
    private FragmentEditProfileBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentEditProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        initWidgetListeners();
        initViewModels();
    }


    private void initWidgetListeners() {

        // Notar que no hi ha camp per confirmar contrassenya, podria ser interessant.
        binding.btnSave.setOnClickListener(ignoredView -> {

            int telefon;
            if (String.valueOf(binding.tinputPhoneNumber.getText()).equals("-")) telefon = 0;
            else telefon = Integer.valueOf(String.valueOf(binding.tinputPhoneNumber.getText()));

            editProfileViewModel.editProfile(
                    String.valueOf(binding.tinputName.getText()),
                    String.valueOf(binding.tinputCognoms.getText()),
                    String.valueOf(binding.tinputBirthDate.getText()),
                    String.valueOf(binding.tinputMail.getText()),
                    telefon,
                    String.valueOf(binding.tinputDescription.getText()),
                    String.valueOf(binding.tinputUniversity.getText())
            );
        });
    }


    private void initViewModels() {
        editProfileViewModel = new ViewModelProvider(this,
                new EditProfileViewModel.Factory(
                        appContainer.fetchClientUseCase,
                        appContainer.editProfileUseCase,
                        getActivity().getApplication())
        ).get(EditProfileViewModel.class);

        initObservers();
    }

    private void initObservers() {
        // Observador per rebre la informació del client i poder omplir els camps.
        editProfileViewModel.getClientState().observe(getViewLifecycleOwner(), clientState -> {
            switch (clientState.getStatus()) {
                case SUCCESS:
                    ClientPO clientPO = clientState.getData();
                    // Foto perfil
                    ImagePlacer.placeImage(clientPO.getPhotoUrl(), binding.imageButton);
                    // Nom
                    binding.tinputName.setText(clientPO.getNom());
                    // Cognoms
                    binding.tinputCognoms.setText(clientPO.getCognoms());
                    // Data de naixement
                    binding.tinputBirthDate.setText(clientPO.getDataNaixement());
                    // Email
                    binding.tinputMail.setText(clientPO.getEmail());
                    // Telèfon
                    if(clientPO.getTelefon() != 0) binding.tinputPhoneNumber.setText(String.valueOf(clientPO.getTelefon()));
                    else binding.tinputPhoneNumber.setText("-");
                    binding.tinputDescription.setText(clientPO.getDescription());
                    binding.tinputUniversity.setText(clientPO.getUniversitat().getNom());
                    break;
                case ERROR:
                    Toast.makeText(getContext(), "Error loading profile info!", Toast.LENGTH_SHORT).show();
                    break;
            }
        });

        //Observador per saber el resultat de l'update com a tal.
        editProfileViewModel.getEditProfileState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    assert state.getData() != null;
                    Toast.makeText(getContext(), "Perfil actualitzat correctament!", Toast.LENGTH_SHORT).show();
                    navController.navigate(R.id.action_editProfileFragment_to_viewProfileFragment2);
                    break;
                case ERROR:
                    // Potser es podria marcar en vermell la casella del que hagi fallat.
                    Toast.makeText(getActivity(), state.getError().getMessage(), Toast.LENGTH_SHORT).show();
                    break;
            }
        });
    }

}