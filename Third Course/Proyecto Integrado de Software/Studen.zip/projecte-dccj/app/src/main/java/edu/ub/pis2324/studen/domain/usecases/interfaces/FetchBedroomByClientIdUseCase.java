package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface FetchBedroomByClientIdUseCase {
    Observable<Bedroom> execute(ClientId clientId);
    enum Error implements StudenError {
        CLIENT_NOT_FOUND,
        CLIENTS_DATA_ACCESS_ERROR,
        BEDROOM_NOT_FOUND,
        BEDROOMS_DATA_ACCESS_ERROR;
    }
}
