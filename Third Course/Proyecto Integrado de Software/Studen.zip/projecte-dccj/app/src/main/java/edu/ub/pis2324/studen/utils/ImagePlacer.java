package edu.ub.pis2324.studen.utils;

import android.widget.ImageView;
import com.squareup.picasso.Picasso;

import edu.ub.pis2324.studen.R;

public class ImagePlacer {

    public static void placeImage(String url, ImageView imageView) {
        try{
            Picasso.get().load(url).into(imageView);
        } catch (Exception e) {
            imageView.setImageResource(R.drawable.no_image);
        }

    }

}
