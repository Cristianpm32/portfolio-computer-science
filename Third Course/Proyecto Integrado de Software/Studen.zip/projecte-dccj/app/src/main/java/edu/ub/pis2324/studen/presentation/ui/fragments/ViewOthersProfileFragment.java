package edu.ub.pis2324.studen.presentation.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.squareup.picasso.Picasso;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentViewOthersProfileBinding;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.viewmodels.ViewOthersProfileViewModel;
import edu.ub.pis2324.studen.utils.ImagePlacer;

public class ViewOthersProfileFragment extends Fragment {
    private ViewOthersProfileViewModel othersProfileViewModel;

    private ClientPO clientPO;
    private AppContainer appContainer;
    private NavController navController;
    private FragmentViewOthersProfileBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentViewOthersProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        clientPO = getArguments().getParcelable("CLIENT");
        assert clientPO != null;

        initWidgetListeners();
        initViewModels(clientPO);
    }

    private void initWidgetListeners() {

        binding.linearLayoutBedroom.setOnClickListener(v -> {
            othersProfileViewModel.getBedroomPO().observe(getViewLifecycleOwner(), bedroomPOState -> {
                switch (bedroomPOState.getStatus()) {
                    case LOADING:
                        break;
                    case SUCCESS:
                        BedroomPO bedroomPO = bedroomPOState.getData();
                        viewBedroomDetails(bedroomPO);
                        break;
                    case ERROR:
                        Toast.makeText(getContext(), bedroomPOState.getError().getMessage(), Toast.LENGTH_SHORT).show();
                        break;
                }
            });
        });
    }

    private void initViewModels(ClientPO clientPO) {
        othersProfileViewModel = new ViewModelProvider(this,
                new ViewOthersProfileViewModel.Factory(getActivity().getApplication(), appContainer.fetchBedroomUseCase, clientPO)
        ).get(ViewOthersProfileViewModel.class);

        initObservers();
    }

    private void initObservers() {
        othersProfileViewModel.getPOClientState().observe(getViewLifecycleOwner(), clientPO -> {

            ImagePlacer.placeImage(clientPO.getPhotoUrl(), binding.ivProfileImage);
            binding.tvProfileId.setText(clientPO.getNom() + " " + clientPO.getCognoms());
            binding.tvProfileEmail.setText(clientPO.getEmail());
            binding.tvProfileDescription.setText(clientPO.getDescription());
            binding.tvProfileName.setText(clientPO.getNom() + " " + clientPO.getCognoms());
            if (clientPO.getUniversitat() != null) {
                binding.tvProfileUniversity.setText(clientPO.getUniversitat().getNom());
            }
            binding.tvProfilePhone.setText(String.valueOf(clientPO.getTelefon()));
            binding.tvProfileBirthdate.setText(clientPO.getDataNaixement());
            updateUI(clientPO);
        });

        othersProfileViewModel.getBedroomPO().observe(getViewLifecycleOwner(), bedroomPOState -> {
            switch (bedroomPOState.getStatus()) {
                case SUCCESS:
                    BedroomPO bedroomPO = bedroomPOState.getData();
                    binding.roomLocation.setText(bedroomPO.getAddress().getCity() + ", " + bedroomPO.getAddress().getCountry());

                    ImagePlacer.placeImage(bedroomPO.getMainPhotoUrl(), binding.roomImage);
                    break;

                case ERROR:
                    Toast.makeText(getContext(), bedroomPOState.getError().getMessage(), Toast.LENGTH_SHORT).show();
                    break;
            }
        });
    }

    private void updateUI(ClientPO clientPO) {
        updateVerificationStatus(clientPO.getVerificat());
    }

    private void viewBedroomDetails(BedroomPO bedroomPO) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("BEDROOM", bedroomPO);
        navController.navigate(R.id.action_viewOthersProfileFragment_to_viewDetailBedroomFragment, bundle);
    }

    private void updateVerificationStatus(int isVerified) {
        TextView tvVerifiedStatus = binding.tvVerifiedStatus;
        // no s'ha intentat verificar
        if (isVerified == 1) {
            tvVerifiedStatus.setText(R.string.profile_verified);
            tvVerifiedStatus.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_verified, 0, 0, 0);
        }
        // s'ha intentat verificar
        else if (isVerified == 0) {
            tvVerifiedStatus.setText(R.string.profile_pending_verified);
            tvVerifiedStatus.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_pending, 0, 0, 0);
        } else if (isVerified == -1) {
            tvVerifiedStatus.setText(R.string.profile_not_verified);
            tvVerifiedStatus.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_not_verified, 0, 0, 0);
        }
    }
}
