package edu.ub.pis2324.studen.domain.usecases.implementations;


import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.GetValidBedroomIdUseCase;
import io.reactivex.rxjava3.core.Observable;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;

public class GetValidBedroomIdUseCaseImpl implements GetValidBedroomIdUseCase {

    private final BedroomRepository bedroomRepository;
    private final StudenThrowableMapper throwableMapper = new StudenThrowableMapper();

    public GetValidBedroomIdUseCaseImpl(BedroomRepository bedroomRepository) {

        this.bedroomRepository = bedroomRepository;
        throwableMapper.add(BedroomRepository.Error.GETVALIDBEDROOMID_UNKNOWN_ERROR, Error.BEDROOMS_DATA_ACCESS_ERROR);
    }

    public Observable<BedroomId> execute(String ciutat) {
        return bedroomRepository.getValidBedroomId(ciutat)
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }

}
