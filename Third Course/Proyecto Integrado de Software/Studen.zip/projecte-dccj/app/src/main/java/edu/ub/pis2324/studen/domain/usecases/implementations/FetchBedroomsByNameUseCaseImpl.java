package edu.ub.pis2324.studen.domain.usecases.implementations;


import java.util.ArrayList;
import java.util.List;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomsByNameUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.utils.Parella;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchBedroomsByNameUseCaseImpl implements FetchBedroomsByNameUseCase {

    private BedroomRepository bedroomRepository;
    private final StudenThrowableMapper throwableMapper;

    private FetchClientUseCase fetchClientUseCase;

    public FetchBedroomsByNameUseCaseImpl(BedroomRepository bedroomRepository, FetchClientUseCase FetchClientUseCase) {
        this.bedroomRepository = bedroomRepository;
        this.fetchClientUseCase = FetchClientUseCase;

        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(BedroomRepository.Error.GETBYNAME_UNKNOWN_ERROR, Error.BEDROOMS_DATA_ACCESS_ERROR);
        throwableMapper.add(edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);
        throwableMapper.add(ClientRepository.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);



    }

    @Override

    public Observable<List<Parella<Bedroom, Client>>> execute(String input) {

        // Això ens permet fer cerques en minúscules i majúscules indistintament
        String[] words = input.split("\\s+");
        StringBuilder capitalized = new StringBuilder();

        for (String word : words) {
            if (word.length() > 0) {
                capitalized.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1).toLowerCase())
                        .append(" ");
            }
        }

        String name = capitalized.toString().trim();

        return bedroomRepository.getByName(name)
            .flatMapIterable(bedrooms -> bedrooms)
            .flatMap(bedroom -> fetchClientUseCase.execute(bedroom.getOwner())
                .map(client -> new Parella<>(bedroom, client)))
            .toList()
            .toObservable()
            .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));

    }
}
