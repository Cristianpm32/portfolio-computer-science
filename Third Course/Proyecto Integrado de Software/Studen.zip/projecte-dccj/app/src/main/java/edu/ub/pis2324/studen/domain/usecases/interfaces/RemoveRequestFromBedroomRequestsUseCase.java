package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface RemoveRequestFromBedroomRequestsUseCase {
    Observable<Bedroom> execute(BedroomId bedroomId,
                                ClientId clientId);


    enum Error implements StudenError {
        REQUEST_NOT_FOUND,
        BEDROOM_NOT_FOUND,
        BEDROOMS_DATA_ACCESS_ERROR,
        UPDATE_UNKNOWN_ERROR;
    }
}
