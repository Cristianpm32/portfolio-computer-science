package edu.ub.pis2324.studen.domain.usecases.interfaces;



import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface VerifyClientUseCase {

    public Observable<Boolean> execute(ClientId clientId);


    enum Error implements StudenError {
        ClIENT_NOT_FOUND
    }


}
