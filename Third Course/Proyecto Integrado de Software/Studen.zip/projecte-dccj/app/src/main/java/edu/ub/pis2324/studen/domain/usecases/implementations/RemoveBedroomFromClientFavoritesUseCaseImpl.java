package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemoveBedroomFromClientFavoritesUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class RemoveBedroomFromClientFavoritesUseCaseImpl implements RemoveBedroomFromClientFavoritesUseCase {


    private ClientRepository clientRepository;

    private FetchClientUseCase fetchClientUseCase;
    private StudenThrowableMapper throwableMapper;

    public RemoveBedroomFromClientFavoritesUseCaseImpl(ClientRepository clientRepository, FetchClientUseCase fetchClientUseCase) {
        this.clientRepository = clientRepository;
        this.fetchClientUseCase = fetchClientUseCase;
        this.throwableMapper = new StudenThrowableMapper();

        throwableMapper.add(ClientRepository.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);
        throwableMapper.add(ClientRepository.Error.UPDATE_UNKNOWN_ERROR, Error.UPDATE_UNKNOWN_ERROR);
    }

    @Override
    public Observable<Client> execute(ClientId clientId, BedroomId bedroomId) {
        return clientRepository.update(clientId, new ClientRepository.OnUpdateListener() {
            @Override
            public void update(Client client) {
                client.removeFavoriteBedroom(bedroomId);
            }
        }).concatMap(ignored -> fetchClientUseCase.execute(clientId))
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }
}
