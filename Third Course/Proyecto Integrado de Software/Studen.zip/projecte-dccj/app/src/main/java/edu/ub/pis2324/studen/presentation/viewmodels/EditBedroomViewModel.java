package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import java.util.ArrayList;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.AddBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.EditBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomByClientIdUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.disposables.CompositeDisposable;

public class EditBedroomViewModel extends AndroidViewModel {

    private EditBedroomUseCase editBedroomUseCase;
    private StateLiveData<Boolean> editBedroomState;
    private final StateLiveData<BedroomPO> bedroomPOState;
    private BedroomPO bedroomPO;
    private CompositeDisposable compositeDisposable;
    private FetchBedroomByClientIdUseCase fetchBedroomByClientIdUseCase;
    private ClientId clientId;
    private DomainToPOMapper domainToPOMapper;

    /* Constructor */
    public EditBedroomViewModel(EditBedroomUseCase editBedroomUseCase, FetchBedroomByClientIdUseCase fetchBedroomByClientIdUseCase, Application application) {

        super(application);
        bedroomPOState = new StateLiveData<>();
        editBedroomState = new StateLiveData<>();
        this.editBedroomUseCase = editBedroomUseCase;
        this.fetchBedroomByClientIdUseCase = fetchBedroomByClientIdUseCase;
        compositeDisposable = new CompositeDisposable();
        domainToPOMapper = DomainToPOMapper.getInstance();

        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("CLIENT_MODEL", null);
        clientId = new Gson().fromJson(json, ClientPO.class).getId();
        fetchBedroom();


    }

    private void fetchBedroom() {
        compositeDisposable.add(fetchBedroomByClientIdUseCase.execute(clientId)
                .subscribe(bedroom -> {
                            // Transformem les dades a PO per a poder-les enviar a la vista
                            bedroomPOState.postSuccess(domainToPOMapper.map(bedroom, BedroomPO.class));
                            bedroomPO = domainToPOMapper.map(bedroom, BedroomPO.class);
                        },
                        throwable -> handleError(throwable)));
    }

    public StateLiveData<BedroomPO> getBedroomPO() {
        return bedroomPOState;
    }

    public StateLiveData<Boolean> getEditBedroomState() {
        return editBedroomState;
    }

    public void editBedroom(float squaredMeters, ArrayList<BedroomFeatures> features, String description, Address address, BedroomType bedroomType) {
        compositeDisposable.add(editBedroomUseCase.execute(bedroomPO.getId(), squaredMeters, features, description, address, bedroomType)
                .subscribe(
                        success -> editBedroomState.postSuccess(success),
                        throwable -> handleError(throwable)
                ));
    }

    private void handleError(Throwable throwable) {
        if (throwable instanceof StudenThrowable) {
            handleStudenError((StudenThrowable) throwable);
        } else {
            bedroomPOState.postError(new Throwable("Unknown error"));
        }
    }

    // Fem la transformació d'errors.
    private void handleStudenError(StudenThrowable studenThrowable) {
        String message;
        StudenError xError = studenThrowable.getError();
        if (xError == EditBedroomUseCase.Error.UPDATE_UNKNOWN_ERROR)
            message = "Error updating bedroom";
        else if (xError == EditBedroomUseCase.Error.SQUARED_METERS_ERROR)
            message = "Squared meters error";
        else if (xError == EditBedroomUseCase.Error.DESCRIPTION_ERROR)
            message = "Description error";
        else if (xError == EditBedroomUseCase.Error.ADDRESS_FIELDS_ERROR)
            message = "Address fields error";
        else if (xError == EditBedroomUseCase.Error.BEDROOMS_DATA_ACCESS_ERROR)
            message = "Error accessing bedrooms data";
        else
            message = "Unknown error";

        bedroomPOState.postError(new Throwable(message));
    }

    public static class Factory extends ViewModelProvider.NewInstanceFactory {
        private final EditBedroomUseCase editBedroomUseCase;
        private final FetchBedroomByClientIdUseCase fetchBedroomByClientIdUseCase;
        private final Application application;

        public Factory(EditBedroomUseCase editBedroomUseCase, FetchBedroomByClientIdUseCase fetchBedroomByClientIdUseCase, Application application) {
            this.editBedroomUseCase = editBedroomUseCase;
            this.fetchBedroomByClientIdUseCase = fetchBedroomByClientIdUseCase;
            this.application = application;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new EditBedroomViewModel(editBedroomUseCase, fetchBedroomByClientIdUseCase, application);
        }
    }

}
