package edu.ub.pis2324.studen.presentation.PresentationObjects;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;

public class BedroomPO implements Parcelable {

    private BedroomId id;
    private Address address;
    private float size;
    private float price;
    private String mainPhotoUrl;
    private List<String> photosUrl;
    private ClientId owner;
    private boolean popular;
    private String description;
    private BedroomType type;
    private ArrayList<BedroomFeatures> features;
    private List<Request> bedroomRequests;
    private ClientId potentialClient;


    public BedroomPO(BedroomId id, BedroomType type, Address address, float size, float price, String mainPhotoUrl, List<String> photosUrl, ClientId owner, String descripcio, ClientId potentialClient) {
        this.id = id;
        this.address = address;
        this.type = type;
        this.size = size;
        this.price = price;
        this.mainPhotoUrl = mainPhotoUrl;
        this.photosUrl = photosUrl;
        this.owner = owner;
        this.description = descripcio;
        this.features = new ArrayList<>();
        this.potentialClient = potentialClient;
    }

    public BedroomPO() {
    }


    public BedroomId getId() {
        return id;
    }

    public Address getAddress() {
        return address;
    }

    public BedroomType getType() {
        return type;
    }

    public float getSize() {
        return size;
    }

    public float getPrice() {
        return price;
    }

    public String getMainPhotoUrl() {
        return mainPhotoUrl;
    }

    public List<String> getPhotosUrl() {
        return photosUrl;
    }

    public ClientId getOwner() {
        return owner;
    }
    public ClientId getPotentialClient() {
        return potentialClient;
    }

    public String getDescription() {
        return description;
    }

    public boolean isBedroomRequest(ClientId clientId) {
        for(Request request : bedroomRequests){
            if(request.getNomClient().getId().equals(clientId.getId())){
                return true;
            }
        }
        return false;
    }
    @Override
    public int describeContents() {
        return 0;
    }

    public ArrayList<BedroomFeatures> getFeatures() {
        return features;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int flags) {
        parcel.writeSerializable(this.id);
        parcel.writeSerializable(this.address);
        parcel.writeSerializable(this.type);
        parcel.writeFloat(this.size);
        parcel.writeFloat(this.price);
        parcel.writeString(this.mainPhotoUrl);
        parcel.writeStringArray(this.photosUrl.toArray(new String[0]));
        parcel.writeSerializable(this.owner);
        parcel.writeString(this.description);
        parcel.writeArray(this.features.toArray());
        parcel.writeList(this.bedroomRequests);
        parcel.writeSerializable(this.potentialClient);
    }

    public void readFromParcel(Parcel source) {
        this.id = (BedroomId) source.readSerializable();
        this.address = (Address) source.readSerializable();
        this.type = (BedroomType) source.readSerializable();
        this.size = source.readFloat();
        this.price = source.readFloat();
        this.mainPhotoUrl = source.readString();
        this.photosUrl = Arrays.asList(source.createStringArray());
        this.owner = (ClientId) source.readSerializable();
        this.description = source.readString();
        this.bedroomRequests = source.readArrayList(Request.class.getClassLoader());
        this.features = new ArrayList<>(Arrays.asList((BedroomFeatures[]) source.readArray(BedroomFeatures.class.getClassLoader())));
        this.potentialClient = (ClientId) source.readSerializable();
    }

    protected BedroomPO(Parcel in) {
        this.id = (BedroomId) in.readSerializable();
        this.address = (Address) in.readSerializable();
        this.type = (BedroomType) in.readSerializable();
        this.size = in.readFloat();
        this.price = in.readFloat();
        this.mainPhotoUrl = in.readString();
        this.photosUrl = Arrays.asList(in.createStringArray());
        this.owner = (ClientId) in.readSerializable();
        this.description = in.readString();
        this.bedroomRequests = in.readArrayList(Request.class.getClassLoader());
        this.features = new ArrayList<>(Arrays.asList((BedroomFeatures[]) in.readArray(BedroomFeatures.class.getClassLoader())));
        this.potentialClient = (ClientId) in.readSerializable();
    }

    public static final Parcelable.Creator<BedroomPO> CREATOR = new Parcelable.Creator<BedroomPO>() {
        @Override
        public BedroomPO createFromParcel(Parcel source) {
            return new BedroomPO(source);
        }
        @Override
        public BedroomPO[] newArray(int size) {
            return new BedroomPO[size];
        }
    };


}
