package edu.ub.pis2324.studen.utils.error_handling;

import java.util.HashMap;
import java.util.Map;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;

public class StudenThrowableMapper {
  private final Map<StudenError, StudenError> sErrorMap;

  public StudenThrowableMapper() {
    sErrorMap = new HashMap<>();
  }

  public void add(StudenError sError, StudenError sMappedError) {
    sErrorMap.put(sError, sMappedError);
  }

  /**
   * Applies the mapping if Throwable is a StudenThrowable, otherwise returns the Throwable as is
   * @param throwable the Throwable to map
   * @return the mapped Throwable
   */
  public Throwable map(Throwable throwable) {
    return (throwable instanceof StudenThrowable)
        ? map((StudenThrowable) throwable)
        : throwable;
  }

  /**
   * Maps the StudenThrowable to a StudenThrowable with its StudenError mapped to another StudenError
   * @param sThrowable the StudenThrowable to map
   * @return the mapped StudenThrowable
   */
  public StudenThrowable map(StudenThrowable sThrowable) {
    StudenError error = sThrowable.getError();
    return (sErrorMap.containsKey(error))
        ? new StudenThrowable(sErrorMap.get(error))
        : sThrowable;
  }
}
