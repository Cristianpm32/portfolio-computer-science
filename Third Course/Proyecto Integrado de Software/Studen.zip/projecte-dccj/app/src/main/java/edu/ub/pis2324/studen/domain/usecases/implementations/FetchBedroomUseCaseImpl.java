package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchBedroomUseCaseImpl implements FetchBedroomUseCase {

    private BedroomRepository bedroomRepository;
    private StudenThrowableMapper throwableMapper;

    public FetchBedroomUseCaseImpl(BedroomRepository bedroomRepository) {

        this.bedroomRepository = bedroomRepository;
        this.throwableMapper = new StudenThrowableMapper();
        this.throwableMapper.add(BedroomRepository.Error.BEDROOM_NOT_FOUND, Error.BEDROOM_NOT_FOUND);
        this.throwableMapper.add(BedroomRepository.Error.GETBYID_UNKNOWN_ERROR, Error.BEDROOMS_DATA_ACCESS_ERROR);
    }

    @Override
    public Observable<Bedroom> execute(BedroomId bedroomId) {
        return bedroomRepository.getById(bedroomId)
          .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }
}
