package edu.ub.pis2324.studen.domain.model.valueobjects;

import java.io.Serializable;
import java.util.Objects;

public class Request implements Serializable {
    private String dataPeticio;
    private ClientId nomClient;

    public Request(String dataPeticio, ClientId nomClient) {
        this.dataPeticio = dataPeticio;
        this.nomClient = nomClient;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Request request2 = (Request) obj;
        return Objects.equals(nomClient, request2.getNomClient());
    }

    public ClientId getNomClient() { return nomClient; }
    public String getDate() {return dataPeticio; }
    @Override
    public int hashCode() {
        return Objects.hash(toString()); // Use Objects.hash to generate hash code based on id
    }

    @Override
    public String toString() {
        return nomClient.getId();
    }
}
