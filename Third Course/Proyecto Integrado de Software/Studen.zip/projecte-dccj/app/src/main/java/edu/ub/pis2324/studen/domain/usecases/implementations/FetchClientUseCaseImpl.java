package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchClientUseCaseImpl implements FetchClientUseCase {
  /* Attributes */
  private ClientRepository clientRepository;
  private StudenThrowableMapper throwableMapper;

  /**
   * Constructor
   */
  public FetchClientUseCaseImpl(ClientRepository clientRepository) {
    this.clientRepository = clientRepository;

    throwableMapper = new StudenThrowableMapper();
    throwableMapper.add(ClientRepository.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);
    throwableMapper.add(ClientRepository.Error.GETBYID_UNKNOWN_ERROR, Error.CLIENTS_DATA_ACCESS_ERROR);
  }

  /**
   * Executes the fetch client use case.
   * @param clientId
   * @return
   */
  @Override
  public Observable<Client> execute(ClientId clientId) {
    return clientRepository.getById(clientId)
      .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
  }
}
