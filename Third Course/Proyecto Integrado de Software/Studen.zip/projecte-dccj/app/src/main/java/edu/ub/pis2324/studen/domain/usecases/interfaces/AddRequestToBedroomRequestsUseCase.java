package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface AddRequestToBedroomRequestsUseCase {
    Observable<Bedroom> execute(BedroomId bedroomId,
                                ClientId clientId);


    enum Error implements StudenError {
        BEDROOM_NOT_FOUND,
        UPDATE_BEDROOM_UNKNOWN_ERROR;
    }
}
