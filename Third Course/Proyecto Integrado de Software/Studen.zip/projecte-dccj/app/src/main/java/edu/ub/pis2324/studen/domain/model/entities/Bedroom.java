package edu.ub.pis2324.studen.domain.model.entities;

import java.util.ArrayList;
import java.util.List;

import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;

public class Bedroom {

    private BedroomId id;
    private Address address;
    private float size;
    private String mainPhotoUrl;
    private ArrayList<String> photosUrl;
    private boolean popular;
    private ClientId owner;
    private String description;
    private BedroomType type;
    private ArrayList<BedroomFeatures> features;
    private List<Request> requests;
    private ClientId potentialClient;


    public Bedroom(BedroomId id, BedroomType type, Address address, float size, String mainPhotoUrl, ArrayList<String> photosUrl,
                   ClientId owner, boolean popular, String descripcio, ArrayList<BedroomFeatures> features, List<Request> requests, ClientId potentialClient) {
        this.id = id;
        this.address = address;
        this.type = type;
        this.size = size;
        this.mainPhotoUrl = mainPhotoUrl;
        this.photosUrl = photosUrl;
        this.owner = owner;
        this.popular = popular;
        this.description = descripcio;
        this.features = features;
        this.requests = requests;
        this.potentialClient = potentialClient;

    }

    public Bedroom(Bedroom bedroom) {
        this.id = bedroom.id;
        this.address = bedroom.address;
        this.size = bedroom.size;
        this.mainPhotoUrl = bedroom.mainPhotoUrl;
        this.photosUrl = bedroom.photosUrl;
        this.owner = bedroom.owner;
        this.popular = bedroom.popular;
        this.description = bedroom.description;
        this.features = new ArrayList<>();
        this.requests = bedroom.requests;
        this.potentialClient = bedroom.potentialClient;
    }

    public Bedroom() {
        this(new BedroomId(), BedroomType.BEDROOM, new Address(), 0, "", new ArrayList<>(), new ClientId(), false, "", new ArrayList<>(), new ArrayList(), new ClientId());
    }

    public BedroomId getId() {
        return id;
    }

    public Address getAddress() {
        return address;
    }

    public float getSize() {
        return size;
    }

    public String getMainPhotoUrl() {
        return mainPhotoUrl;
    }

    public List<String> getPhotosUrl() {
        return photosUrl;
    }

    public ClientId getOwner() {
        return owner;
    }

    public String getDescription() {
        return description;
    }

    public ClientId getPotentialClient() { return potentialClient; }

    public List<Request> getRequests() {
        return requests;
    }

    public void addRequest(Request request) {
        requests.add(request);
    }

    public void removeRequest(ClientId clientId) {
        for(Request request : requests){
            if(request.getNomClient().getId().equals(clientId.getId())){
                requests.remove(request);
                break;
            }
        }
    }

    public Request getRequest(ClientId clientId) {
        for(Request request : requests){
            if(request.getNomClient().getId().equals(clientId.getId())){
                return request;
            }
        }
        return null;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public void setSize(float size) {
        this.size = size;
    }

    public void setMainPhotoUrl(String mainPhotoUrl) {
        this.mainPhotoUrl = mainPhotoUrl;
    }

    public void setPhotosUrl(ArrayList<String> photosUrl) {
        this.photosUrl = photosUrl;
    }

    public void setPopular(boolean popular) {
        this.popular = popular;
    }

    public void setOwner(ClientId owner) {
        this.owner = owner;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setType(BedroomType type) {
        this.type = type;
    }

    public void setPotentialClient(ClientId potentialClient) { this.potentialClient = potentialClient; }

    public void deletePotentialClient() { this.potentialClient = new ClientId(); }

    public void setFeatures(ArrayList<BedroomFeatures> features) {
        this.features = features;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Bedroom bedroom = (Bedroom) obj;
        return id.equals(bedroom.id);
    }

    public boolean isPopular() {
        return popular;
    }

    public String getTypeAsString() {
        switch (type) {
            case BEDROOM:
                return "Habitació";
            case APARTMENT:
                return "Pis";
            case HOUSE:
                return "Casa";
            default:
                return "";
        }
    }

    public boolean hasFeature(BedroomFeatures feature) {
        for (BedroomFeatures f : features) {
            if (f == feature) {
                return true;
            }
        }
        return false;
    }

}