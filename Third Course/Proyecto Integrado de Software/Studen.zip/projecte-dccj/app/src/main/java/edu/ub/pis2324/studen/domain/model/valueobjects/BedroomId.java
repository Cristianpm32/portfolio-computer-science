package edu.ub.pis2324.studen.domain.model.valueobjects;

import java.io.Serializable;
import java.util.Objects;

public class BedroomId implements Serializable {
    
    private String id;

    public BedroomId(String id) {
        this.id = id;
    }

    @SuppressWarnings("unused")
    public BedroomId() {
        id = "";
    }

    public String getId() {
        return id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        BedroomId bedroomID = (BedroomId) obj;
        return Objects.equals(id, bedroomID.id); // Use Objects.equals for null safety
    }

    @Override
    public int hashCode() {
        return Objects.hash(id); // Use Objects.hash to generate hash code based on id
    }

    @Override
    public String toString() {
        return id.toString();
    }
}
