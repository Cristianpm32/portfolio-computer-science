package edu.ub.pis2324.studen.data.repositories.firestore;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.ClientFirestoreDTO;
import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.mappers.DTOToDomainMapper;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import io.reactivex.rxjava3.core.Observable;

/**
 * Cloud Firestore implementation of the data store.
 */
public class ClientFirestoreRepository implements ClientRepository {
  /* Constants */
  private static final String CLIENTS_COLLECTION_NAME = "clients";
  /* Attributes */
  private final FirebaseFirestore db;
  private final DTOToDomainMapper DTOToDomainMapper;

  /**
   * Empty constructor
   */
  public ClientFirestoreRepository() {
    db = FirebaseFirestore.getInstance();

    // get all elements of collection "clients"
    CollectionReference clients = db.collection("clients");

    DTOToDomainMapper = new DTOToDomainMapper();
  }

  /**
   * Add a client to the Firebase CloudFirestore.
   *
   * @param client The client to add.
   * @return A Observable with true if the client was added
   * or an error if it already exists.
   */
  public Observable<Boolean> add(Client client) {
    return Observable.create(emitter -> {
      ClientFirestoreDTO clientDto = DTOToDomainMapper.map(client, ClientFirestoreDTO.class);

      db.collection(CLIENTS_COLLECTION_NAME)
          .document(client.getId().toString())
          .set(clientDto)
          .addOnFailureListener(exception -> {
            emitter.onError(new StudenThrowable(Error.ADD_UNKNOWN_ERROR));
          })
          .addOnSuccessListener(ignored -> {
            emitter.onNext(true);
            emitter.onComplete();
          });
    });
  }

  /**
   * Get a client by id.
   *
   * @param id The client id.
   * @return A Observable with the client or null if it doesn't exist.
   */
  public Observable<Client> getById(ClientId id) {
    return Observable.create(emitter -> {
      db.collection(CLIENTS_COLLECTION_NAME)
          .document(id.toString())
          .get()
          .addOnFailureListener(e -> {
            emitter.onError(new StudenThrowable(Error.GETBYID_UNKNOWN_ERROR));
          })
          .addOnSuccessListener(ds -> {
            if (!ds.exists()) {
              emitter.onError(new StudenThrowable(Error.CLIENT_NOT_FOUND));
            } else {
              ClientFirestoreDTO clientDto = ds.toObject(ClientFirestoreDTO.class);
              Client client = DTOToDomainMapper.map(clientDto, Client.class);
              emitter.onNext(client);
              emitter.onComplete();
            }
          });
    });
  }

  /**
   * Update a client from the Firebase CloudFirestore.
   *
   * @param id The client id.
   * @param onUpdateListener The updater to apply to the client.
   * @return A Observable with true if the client was removed
   * or an error if it doesn't exist.
   */
  public Observable<Boolean> update(ClientId id, OnUpdateListener onUpdateListener) {
    return Observable.create(emitter -> {
      db.runTransaction(transaction -> {
          try {
            DocumentReference docRef = db
                .collection(CLIENTS_COLLECTION_NAME)
                .document(id.toString());
            DocumentSnapshot ds = transaction.get(docRef);
            if (!ds.exists()) {
              // No existeix el document
              return false;
            } else {
              ClientFirestoreDTO clientDto = ds.toObject(ClientFirestoreDTO.class);
              Client client = DTOToDomainMapper.map(clientDto, Client.class);
              onUpdateListener.update(client);
              clientDto = DTOToDomainMapper.map(client, ClientFirestoreDTO.class);
              transaction.set(docRef, clientDto);
              return true;
            }
          } catch (Throwable e) {
            throw e;
          }
        })
        .addOnFailureListener(e -> {
          emitter.onError(new StudenThrowable(Error.UPDATE_UNKNOWN_ERROR));
        })
        .addOnSuccessListener(success -> {
          if (!success) {
            emitter.onError(new StudenThrowable(Error.CLIENT_NOT_FOUND));
          } else {
            emitter.onNext(success);
            emitter.onComplete();
          }
        });
    });
  }

  /**
   * Remove a client from the Firebase CloudFirestore.
   * @param id The client id.
   * @return A Observable with true if the client was removed
   *          or an error if it doesn't exist.
   */
  public Observable<Boolean> remove(ClientId id) {
    return Observable.create(emitter -> {
      db.collection(CLIENTS_COLLECTION_NAME)
          .document(id.toString())
          .delete()
          .addOnFailureListener(exception -> {
            emitter.onError(new StudenThrowable(Error.REMOVE_UNKNOWN_ERROR));
          })
          .addOnSuccessListener(ignored -> {
            emitter.onNext(true);
            emitter.onComplete();
          });
    });
  }

}
