package edu.ub.pis2324.studen.domain.usecases.implementations;


import java.util.ArrayList;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.domain.usecases.interfaces.AddBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.GetValidBedroomIdUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class AddBedroomUseCaseImpl implements AddBedroomUseCase {

    private BedroomRepository bedroomRepository;

    private ClientRepository clientRepository;
    private GetValidBedroomIdUseCase getValidBedroomIdUseCase;
    private StudenThrowableMapper throwableMapper;

    public AddBedroomUseCaseImpl(BedroomRepository bedroomRepository, ClientRepository clientRepository, GetValidBedroomIdUseCase getValidBedroomIdUseCase) {
        this.bedroomRepository = bedroomRepository;
        this.getValidBedroomIdUseCase = getValidBedroomIdUseCase;
        this.clientRepository = clientRepository;

        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(BedroomRepository.Error.ADD_UNKNOWN_ERROR, Error.ADD_UNKNOWN_ERROR);
        throwableMapper.add(BedroomRepository.Error.GETVALIDBEDROOMID_UNKNOWN_ERROR, Error.GETVALIDBEDROOMID_UNKNOWN_ERROR);
        throwableMapper.add(BedroomRepository.Error.BEDROOMS_DATA_ACCESS_ERROR, Error.BEDROOMS_DATA_ACCESS_ERROR);
    }

    @Override
    public Observable<BedroomId> execute(int squaredMeters, ArrayList<BedroomFeatures> features, String description, Address address, ClientId clientId, BedroomType bedroomType) {
        return checkSquaredMetersNotEmpty(squaredMeters).
                concatMap(ignored -> checkDescriptionNotEmpty(description)).
                concatMap(ignored -> getValidBedroomIdUseCase.execute(address.getCity())).
                concatMap(bedroomId -> {
                    Bedroom bedroom = new Bedroom(bedroomId, bedroomType, address, squaredMeters, "", new ArrayList<String>(), clientId, false, description, features, new ArrayList<Request>(), new ClientId());

                    return bedroomRepository.add(bedroom).
                            concatMap(ignored -> clientRepository.update(clientId, new ClientRepository.OnUpdateListener() {
                                        @Override
                                        public void update(Client client) {
                                            client.setBedroomId(bedroomId);
                                        }
                            })
                            ).concatMap(ignored -> Observable.just(bedroomId));
                }).onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }


    private Observable<Boolean> checkSquaredMetersNotEmpty(int squaredMeters) {


        if (squaredMeters <= 0) {
            return Observable.error(new StudenThrowable(Error.SQUARED_METERS_EMPTY));
        } else {
            return Observable.just(true);
        }


    }

    private Observable<Boolean> checkDescriptionNotEmpty(String description) {

        if (description.isEmpty()) {
            return Observable.error(new StudenThrowable(Error.DESCRIPTION_EMPTY));
        } else {
            return Observable.just(true);
        }
    }
}
