package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;





public interface GetValidBedroomIdUseCase {

    Observable<BedroomId> execute(String ciutat);


    enum Error implements StudenError {
        BEDROOMS_DATA_ACCESS_ERROR
    }
}



