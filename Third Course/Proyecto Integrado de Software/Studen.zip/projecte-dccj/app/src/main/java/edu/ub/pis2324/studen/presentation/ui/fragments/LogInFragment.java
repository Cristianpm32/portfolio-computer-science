package edu.ub.pis2324.studen.presentation.ui.fragments;


import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;


import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.gson.Gson;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentLogInBinding;
import edu.ub.pis2324.studen.presentation.viewmodels.LogInViewModel;

public class LogInFragment extends Fragment {
  /* Attributes */

  /* ViewModel */
  private LogInViewModel logInViewModel;
  /* View binding */
  private FragmentLogInBinding binding;
  private AppContainer appContainer;
  private NavController navController;

  /**
   * Called when the activity is being created.
   * @param savedInstanceState
   */
  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                           @Nullable Bundle savedInstanceState) {
    binding = edu.ub.pis2324.studen.databinding.FragmentLogInBinding.inflate(inflater, container, false);

    return binding.getRoot();
  }

  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
    navController = Navigation.findNavController(view);
    /* Initializations */
    initWidgetListeners();
    initViewModel();
  }

  /**
   * Initialize the listeners of the widgets.
   */
  private void initWidgetListeners() {
    binding.btnLogIn.setOnClickListener(ignoredView -> {
      // Delegate the log-in logic to the viewmodel
      logInViewModel.login(
        String.valueOf(binding.etLoginUsername.getText()),
        String.valueOf(binding.etLoginPassword.getText())
      );
    });

    binding.btnSignUp.setOnClickListener(ignoredView -> {
      navController.navigate(R.id.action_logInFragment_to_signUpFragment);
    });
  }

  /**
   * Initialize the viewmodel and its observers.
   */
  private void initViewModel() {
    /* Init viewmodel */

    logInViewModel = new ViewModelProvider(
            this,
            new LogInViewModel.Factory(appContainer.logInUseCase)
    ).get(LogInViewModel.class);

    initObservers();
  }

  /**
   * Initialize the observers of the viewmodel.
   */
  private void initObservers() {
    /* Observe the login state */
    logInViewModel.getLogInState().observe(this.getActivity(), logInState -> {
      // Whenever there's a change in the login state of the viewmodel
      switch (logInState.getStatus()) {
        case LOADING:
          binding.btnLogIn.setEnabled(false);
          break;
        case SUCCESS:
          SharedPreferences.Editor editor = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE).edit();
          String clientModelJsonString = new Gson().toJson(logInState.getData());
          editor.putString("CLIENT_MODEL", clientModelJsonString);
          if(logInState.getData().getBedroomId() == null){
            editor.putString("BEDROOM_ID", null);
          } else {
            String bedroomIdJsonString = new Gson().toJson(logInState.getData().getBedroomId());
            editor.putString("BEDROOM_ID", bedroomIdJsonString);
          }
          editor.commit();
          navController.navigate(R.id.action_logInFragment_to_homeFragment);
          break;
        case ERROR:
          assert logInState.getError() != null;
          String errorMessage = logInState.getError().getMessage();
          Toast.makeText(this.getActivity(), errorMessage , Toast.LENGTH_SHORT).show();
          binding.btnLogIn.setEnabled(true);
          break;
        default:
          throw new IllegalStateException("Unexpected value: " + logInState.getStatus());
      }
    });
  }
}