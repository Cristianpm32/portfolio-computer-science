package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.VerifyClientUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class VerifyClientUseCaseImpl implements VerifyClientUseCase {


    ClientRepository clientRepository;
    StudenThrowableMapper throwableMapper;
    public VerifyClientUseCaseImpl(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
        this.throwableMapper = new StudenThrowableMapper();

        throwableMapper.add(ClientRepository.Error.CLIENT_NOT_FOUND, Error.ClIENT_NOT_FOUND);

    }

    public Observable<Boolean> execute(ClientId clientId) {

        return clientRepository.update(clientId, new ClientRepository.OnUpdateListener() {
            @Override
            public void update(Client client) {
                // Pendent de verificar
                client.setVerificat(0);
            }
        }).map(ignored -> true)
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }
}
