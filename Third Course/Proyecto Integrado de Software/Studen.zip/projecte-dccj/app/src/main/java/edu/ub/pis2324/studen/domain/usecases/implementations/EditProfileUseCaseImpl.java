package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Universitat;
import edu.ub.pis2324.studen.domain.services.CheckClientExistsService;
import edu.ub.pis2324.studen.domain.usecases.interfaces.EditProfileUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.LogInUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SignUpUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

/**
 * Implementation of the log-in use case (EXERCICI 3)
 */
public class EditProfileUseCaseImpl implements EditProfileUseCase {
    /* Attributes */
    private CheckClientExistsService checkClientExistsService; // Re-usage of use cases
    private ClientRepository clientRepository;
    private StudenThrowableMapper throwableMapper;

    /**
     * Creates a log-in use case.
     */
    public EditProfileUseCaseImpl(
            CheckClientExistsService checkClientExistsService,
            ClientRepository clientRepository
    ) {
        this.checkClientExistsService = checkClientExistsService;
        this.clientRepository = clientRepository;

        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(ClientRepository.Error.UPDATE_UNKNOWN_ERROR, Error.UPDATE_UNKNOWN_ERROR);
        throwableMapper.add(FetchClientUseCase.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);
        throwableMapper.add(FetchClientUseCase.Error.CLIENTS_DATA_ACCESS_ERROR, Error.CLIENTS_DATA_ACCESS_ERROR);
    }

    /**
     * Executes the log-in use case.
     *
     * @return
     */
    @Override
    public Observable<Boolean> execute(
            ClientId clientId,
            String nom,
            String cognoms,
            String birthDate,
            String email,
            int telefon,
            String description,
            String universitat) {
        return checkEmailNotEmpty(clientId)
                .concatMap(ignored -> checkClientExistsService.execute(clientId))
                .concatMap(clientExists -> {
                    if (clientExists) {
                        return clientRepository.update(clientId, client -> {
                            client.setNom(nom);
                            client.setCognoms(cognoms);
                            client.setDataNaixement(birthDate);
                            client.setEmail(email);
                            client.setTelefon(telefon);
                            client.setDescription(description);
                            client.getUniversitat().setNom(universitat);
                        });
                    } else {
                        return Observable.error(new StudenThrowable(Error.CLIENTS_DATA_ACCESS_ERROR));
                    }
                }).onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }

    //Mètode síncron, pero que treballem amb observables per mantenir una solució compacta i
    // compatible amb l'asincronia dels altres observables.
    private Observable<Boolean> checkEmailNotEmpty(ClientId clientId) {
        return clientId.getId().isEmpty()
                ? Observable.error(new StudenThrowable(Error.EMAIL_EMPTY))
                : Observable.just(true);
    }

}
