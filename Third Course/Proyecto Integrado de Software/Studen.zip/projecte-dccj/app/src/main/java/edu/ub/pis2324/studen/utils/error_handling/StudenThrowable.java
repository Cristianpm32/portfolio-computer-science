package edu.ub.pis2324.studen.utils.error_handling;

import androidx.annotation.Nullable;

/**
 * Classe per tal de poder propagar les excepcions mitjançant els observables
 */
public class StudenThrowable extends Throwable {
    private StudenError sError;

    /**
     * Constructor.
     * @param sError the type of error.
     */
    public StudenThrowable(StudenError sError) {
        this.sError = sError;
    }

    /**
     * Gets the type of error.
     * @return the type of error.
     */
    public StudenError getError() {
        return sError;
    }

    @Nullable
    @Override
    public String getMessage() {
        return sError.toString();
    }
}
