package edu.ub.pis2324.studen.presentation.ui.fragments;

import static edu.ub.pis2324.studen.utils.livedata.StateData.DataStatus.LOADING;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentVerificarPerfilBinding;
import edu.ub.pis2324.studen.presentation.viewmodels.VerificarPerfilFragmentViewModel;
import edu.ub.pis2324.studen.presentation.viewmodels.ViewDetailBedroomViewModel;

public class VerificarPerfilFragment extends Fragment {

    private FragmentVerificarPerfilBinding binding;
    private NavController navController;
    private MyApplication application;
    private VerificarPerfilFragmentViewModel verificarPerfilFragmentViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentVerificarPerfilBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        application = (MyApplication) getActivity().getApplication();
        navController = Navigation.findNavController(view);

        /* Initializations */

        initViewModel();
        initWidgetListeners();
    }

    private void initViewModel() {

        verificarPerfilFragmentViewModel = new ViewModelProvider(this, new VerificarPerfilFragmentViewModel.Factory(
                application,
                application.getAppContainer().verifyClientUseCase
        )).get(VerificarPerfilFragmentViewModel.class);

        initObservers();
    }

    private void initObservers() {

        verificarPerfilFragmentViewModel.getVerifyClientState().observe(getViewLifecycleOwner(), isClientVerifiedState -> {
            switch(isClientVerifiedState.getStatus()) {
                case SUCCESS:

                    binding.btnVerificar.setEnabled(false);

                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setCancelable(true);
                    builder.setTitle("Inforamció");
                    builder.setMessage("Ara el perfil està pendent de verificar. En breu es verificarà");
                    builder.setPositiveButton("Tornar",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    navController.navigate(R.id.action_verifyProfileFragment_to_viewProfileFragment);
                                }
                            });


                    AlertDialog dialog = builder.create();
                    dialog.show();
                    break;
                case ERROR:
                    Toast.makeText(getContext(), isClientVerifiedState.getError().getMessage(), Toast.LENGTH_SHORT).show();
                    break;
            }
        });
    }

    private void initWidgetListeners() {

        binding.btnVerificar.setOnClickListener(v -> {
            verificarPerfilFragmentViewModel.verifyClient();
        });
    }
}