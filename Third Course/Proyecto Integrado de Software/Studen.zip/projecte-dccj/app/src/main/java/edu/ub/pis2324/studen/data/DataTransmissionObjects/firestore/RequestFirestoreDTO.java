package edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore;

public class RequestFirestoreDTO {
    private String dataPeticio;
    private String nomClient;
    
    public RequestFirestoreDTO() {
        this.dataPeticio = "";
        this.nomClient = "";
    }
    
    public RequestFirestoreDTO(String dataPeticio, String nomClient) {
        this.dataPeticio = dataPeticio;
        this.nomClient = nomClient;
    }

    public String getDataPeticio() {
        return dataPeticio;
    }

    public String getNomClient() {
        return nomClient;
    }
}
