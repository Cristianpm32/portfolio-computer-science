package edu.ub.pis2324.studen.presentation.PresentationObjects;

import android.os.Parcel;
import android.os.Parcelable;


import java.util.List;

import edu.ub.pis2324.studen.domain.model.valueobjects.Universitat;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;

public class ClientPO implements Parcelable {
    /* Attributes */
    private ClientId id;
    private String nom;
    private String cognoms;
    private Universitat universitat;
    private int telefon;

    private String dataNaixement;
    private int verificat;
    private String email;
    private String password;
    private String photoUrl;
    private String description;
    private BedroomId bedroomId;
    private List<BedroomId> favoriteBedrooms;



    /* Constructors */

    public ClientPO(ClientId id, String nom, String cognoms, Universitat universitat, int telefon, String dataNaixement, int verificat, String email, String password, String photoUrl, String description, BedroomId bedroomId, List<BedroomId> favoriteBedrooms) {
        this.id = id;
        this.nom = nom;
        this.cognoms = cognoms;
        this.universitat = universitat;
        this.telefon = telefon;
        this.dataNaixement = dataNaixement;
        this.verificat = verificat;
        this.email = email;
        this.password = password;
        this.photoUrl = photoUrl;
        this.description = description;
        this.bedroomId = bedroomId;
        this.favoriteBedrooms = favoriteBedrooms;
    }

    @SuppressWarnings("unused")
    public ClientPO() {
    }

    /* Getters */
    public ClientId getId() { return id; }
    public String getEmail() { return email; }
    public String getPhotoUrl() { return photoUrl; }

    public String getDescription() { return description; }

    public String getNom() { return nom; }

    public String getCognoms() { return cognoms; }

    public Universitat getUniversitat() { return universitat; }

    public int getTelefon() { return telefon; }

    public String getDataNaixement() { return dataNaixement; }

    public int getVerificat() { return verificat; }

    public BedroomId getBedroomId() { return bedroomId; }

    public List<BedroomId> getFavoriteBedrooms() { return favoriteBedrooms; }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeSerializable(this.id);
        dest.writeString(this.email);
        dest.writeString(this.photoUrl);
        dest.writeString(this.description);
        dest.writeString(this.nom);
        dest.writeString(this.cognoms);
        dest.writeSerializable(this.universitat);
        dest.writeInt(this.telefon);
        dest.writeString(this.dataNaixement);
        dest.writeInt(this.verificat);
        dest.writeSerializable(this.bedroomId);
        dest.writeList(this.favoriteBedrooms);
    }

    public void readFromParcel(Parcel source) {
        this.id = (ClientId) source.readSerializable();
        this.email = source.readString();
        this.photoUrl = source.readString();
        this.description = source.readString();
        this.nom = source.readString();
        this.cognoms = source.readString();
        this.universitat = (Universitat) source.readSerializable();
        this.telefon = source.readInt();
        this.dataNaixement = source.readString();
        this.verificat = source.readInt();
        this.bedroomId = (BedroomId) source.readSerializable();
        this.favoriteBedrooms = source.readArrayList(BedroomId.class.getClassLoader());

    }

    protected ClientPO(Parcel in) {
        this.id = (ClientId) in.readSerializable();
        this.email = in.readString();
        this.photoUrl = in.readString();
        this.description = in.readString();
        this.nom = in.readString();
        this.cognoms = in.readString();
        this.universitat = (Universitat) in.readSerializable();
        this.telefon = in.readInt();
        this.dataNaixement = in.readString();
        this.verificat = in.readInt();
        this.bedroomId = (BedroomId) in.readSerializable();
        this.favoriteBedrooms = in.readArrayList(BedroomId.class.getClassLoader());


    }

    public boolean isFavoriteBedroom(BedroomId bedroomId){
        return favoriteBedrooms.contains(bedroomId);
    }

    public static final Parcelable.Creator<ClientPO> CREATOR = new Parcelable.Creator<ClientPO>() {
        @Override
        public ClientPO createFromParcel(Parcel source) {
            return new ClientPO(source);
        }

        @Override
        public ClientPO[] newArray(int size) {
            return new ClientPO[size];
        }
    };
}
