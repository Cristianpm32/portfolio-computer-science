package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import edu.ub.pis2324.studen.domain.usecases.interfaces.AddBedroomToClientFavoritesUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.AddRequestToBedroomRequestsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemoveBedroomFromClientFavoritesUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemoveRequestFromBedroomRequestsUseCase;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;

public class ViewDetailBedroomViewModel extends AndroidViewModel {

    /*
    * UseCases
     */
    private final FetchClientUseCase fetchClientUseCase;
    private final AddBedroomToClientFavoritesUseCase addBedroomToClientFavoritesUseCase;
    private final RemoveBedroomFromClientFavoritesUseCase removeBedroomFromClientFavoritesUseCase;
    private final AddRequestToBedroomRequestsUseCase addRequestToBedroomRequestsUseCase;
    private final RemoveRequestFromBedroomRequestsUseCase removeRequestToBedroomRequestsUseCase;

    /*
    * LiveData
     */
    private final StateLiveData<ClientPO> clientPOState;
    private final StateLiveData<BedroomPO> bedroomPOState;

    private BedroomPO bedroomPO;
    private ClientPO clientPO; // Propietari del bedroom per mostrar la foto de perfil

    private ClientPO currentClientPO; // Usuari actual de l'app que pot donar like al bedroom

    private final StateLiveData<Void> favBedroomState;
    private final StateLiveData<Void> bedroomRequestState;
    private DomainToPOMapper domainToPOMapper;

    private CompositeDisposable compositeDisposable;
    
    
    public ViewDetailBedroomViewModel(Application application, BedroomPO bedroomPO, FetchClientUseCase fetchClientUseCase, AddBedroomToClientFavoritesUseCase addBedroomToClientFavoritesUseCase, RemoveBedroomFromClientFavoritesUseCase removeBedroomFromClientFavoritesUseCase, AddRequestToBedroomRequestsUseCase addRequestToBedroomRequestsUseCase, RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase) {
        super(application);
        this.bedroomPO = bedroomPO;
        this.fetchClientUseCase = fetchClientUseCase;
        this.addBedroomToClientFavoritesUseCase = addBedroomToClientFavoritesUseCase;
        this.removeBedroomFromClientFavoritesUseCase = removeBedroomFromClientFavoritesUseCase;
        this.addRequestToBedroomRequestsUseCase = addRequestToBedroomRequestsUseCase;
        this.removeRequestToBedroomRequestsUseCase = removeRequestFromBedroomRequestsUseCase;

        clientPOState = new StateLiveData<>();
        favBedroomState = new StateLiveData<>();
        bedroomRequestState = new StateLiveData<>();
        bedroomPOState = new StateLiveData<>();

        bedroomPOState.postSuccess(bedroomPO);

        domainToPOMapper = DomainToPOMapper.getInstance();
        compositeDisposable = new CompositeDisposable();


        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("CLIENT_MODEL", null);

        this.currentClientPO = new Gson().fromJson(json, ClientPO.class);
        fetchBedroomOwner();
    }


    public StateLiveData<BedroomPO> getBedroomPOState() {
        return bedroomPOState;
    }

    private void fetchBedroomOwner() {

        clientPOState.postLoading();
        Observable<Client> clientObservable = fetchClientUseCase.execute(bedroomPO.getOwner());
        Disposable disposable = clientObservable
                .subscribeOn(io.reactivex.rxjava3.android.schedulers.AndroidSchedulers.mainThread())
                .observeOn(io.reactivex.rxjava3.schedulers.Schedulers.io())
                .subscribe(
                        client -> {
                            clientPO = domainToPOMapper.map(client, ClientPO.class);
                            clientPOState.postSuccess(clientPO);
                        },
                        throwable -> clientPOState.postError(throwable)
                );
        compositeDisposable.add(disposable);
    }



    @Override
    protected void onCleared() {
        super.onCleared();
        compositeDisposable.dispose();
    }

    public StateLiveData<ClientPO> getClientPO () {
        return clientPOState;
    }

    public StateLiveData<Void> getFavBedroomState() {
        return favBedroomState;
    }

    public boolean isBedroomInClientFavorite() {
        return currentClientPO.isFavoriteBedroom(bedroomPO.getId());
    }
    public boolean isRequestInBedroomRequests() {
        return bedroomPO.isBedroomRequest(currentClientPO.getId());
    }


    public void removeBedroomFromClientFavorite() {
        favBedroomState.postLoading();
        Disposable disposable = removeBedroomFromClientFavoritesUseCase.execute(currentClientPO.getId(), bedroomPO.getId())
                .subscribeOn(io.reactivex.rxjava3.android.schedulers.AndroidSchedulers.mainThread())
                .observeOn(io.reactivex.rxjava3.schedulers.Schedulers.io())
                .subscribe(
                        client -> {
                            // Actualitzem currentClientPO
                            currentClientPO = domainToPOMapper.map(client, ClientPO.class);
                            // Actualitzem shared pref:
                            SharedPreferences.Editor editor = getApplication().getSharedPreferences("LOGIN", MODE_PRIVATE).edit();
                            String clientModelJsonString = new Gson().toJson(client);
                            editor.putString("CLIENT_MODEL", clientModelJsonString);
                            editor.commit();
                            favBedroomState.postSuccess(null);
                        },
                        throwable -> favBedroomState.postError(throwable)
                );
        compositeDisposable.add(disposable);
    }

    public void addBedroomToClientFavorite() {
        favBedroomState.postLoading();
        Disposable disposable = addBedroomToClientFavoritesUseCase.execute(currentClientPO.getId(), bedroomPO.getId())
                .subscribeOn(io.reactivex.rxjava3.android.schedulers.AndroidSchedulers.mainThread())
                .observeOn(io.reactivex.rxjava3.schedulers.Schedulers.io())
                .subscribe(
                        client -> {
                            // Actualitzem currentClientPO
                            currentClientPO = domainToPOMapper.map(client, ClientPO.class);
                            // Actualitzem shared pref:
                            SharedPreferences.Editor editor = getApplication().getSharedPreferences("LOGIN", MODE_PRIVATE).edit();
                            String clientModelJsonString = new Gson().toJson(client);
                            editor.putString("CLIENT_MODEL", clientModelJsonString);
                            editor.commit();
                            favBedroomState.postSuccess(null);
                        },
                        throwable -> favBedroomState.postError(throwable)
                );
        compositeDisposable.add(disposable);
    }

    public void addRequestToBedroomRequests() {
        bedroomRequestState.postLoading();
        Disposable disposable = addRequestToBedroomRequestsUseCase.execute(bedroomPO.getId(), currentClientPO.getId())
                .subscribeOn(io.reactivex.rxjava3.android.schedulers.AndroidSchedulers.mainThread())
                .observeOn(io.reactivex.rxjava3.schedulers.Schedulers.io())
                .subscribe(
                        bedroom -> {
                            // Actualitzem bedroomPO
                            bedroomPO = domainToPOMapper.map(bedroom, BedroomPO.class);
                            // Actualitzem shared pref:
                            SharedPreferences.Editor editor = getApplication().getSharedPreferences("LOGIN", MODE_PRIVATE).edit();
                            String clientModelJsonString = new Gson().toJson(bedroom);
                            editor.putString("BEDROOM_MODEL", clientModelJsonString);
                            editor.commit();
                            bedroomRequestState.postSuccess(null);
                        },
                        throwable -> bedroomRequestState.postError(throwable)
                );
        compositeDisposable.add(disposable);
    }
    public void removeRequestFromBedroomRequests() {
        bedroomRequestState.postLoading();
        Disposable disposable = removeRequestToBedroomRequestsUseCase.execute(bedroomPO.getId(), currentClientPO.getId())
                .subscribeOn(io.reactivex.rxjava3.android.schedulers.AndroidSchedulers.mainThread())
                .observeOn(io.reactivex.rxjava3.schedulers.Schedulers.io())
                .subscribe(
                        bedroom -> {
                            // Actualitzem bedroomPO
                            bedroomPO = domainToPOMapper.map(bedroom, BedroomPO.class);
                            // Actualitzem shared pref:
                            SharedPreferences.Editor editor = getApplication().getSharedPreferences("LOGIN", MODE_PRIVATE).edit();
                            String clientModelJsonString = new Gson().toJson(bedroom);
                            editor.putString("BEDROOM_MODEL", clientModelJsonString);
                            editor.commit();
                            bedroomRequestState.postSuccess(null);
                        },
                        throwable -> bedroomRequestState.postError(throwable)
                );
        compositeDisposable.add(disposable);
    }

    public static class Factory extends ViewModelProvider.NewInstanceFactory {
        private final Application application;
        private final BedroomPO bedroomPO;
        private final FetchClientUseCase fetchClientUseCase;
        private final AddBedroomToClientFavoritesUseCase addBedroomToClientFavoritesUseCase;

        private final RemoveBedroomFromClientFavoritesUseCase removeBedroomFromClientFavoritesUseCase;
        private final AddRequestToBedroomRequestsUseCase addRequestToBedroomRequestsUseCase;
        private final RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase;

        public Factory(
                Application application,
                BedroomPO bedroomPO,
                FetchClientUseCase fetchClientUseCase,
                AddBedroomToClientFavoritesUseCase addBedroomToClientFavoritesUseCase,
                RemoveBedroomFromClientFavoritesUseCase removeBedroomFromClientFavoritesUseCase,
                AddRequestToBedroomRequestsUseCase addRequestToBedroomRequestsUseCase,
                RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase

        ) {
            this.application = application;
            this.bedroomPO = bedroomPO;
            this.fetchClientUseCase = fetchClientUseCase;
            this.addBedroomToClientFavoritesUseCase = addBedroomToClientFavoritesUseCase;
            this.removeBedroomFromClientFavoritesUseCase = removeBedroomFromClientFavoritesUseCase;
            this.addRequestToBedroomRequestsUseCase = addRequestToBedroomRequestsUseCase;
            this.removeRequestFromBedroomRequestsUseCase = removeRequestFromBedroomRequestsUseCase;
        }

        @NonNull
        @Override
        @SuppressWarnings("unchecked")
        public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
            return (T) new ViewDetailBedroomViewModel(
                    application,
                    bedroomPO,
                    fetchClientUseCase,
                    addBedroomToClientFavoritesUseCase,
                    removeBedroomFromClientFavoritesUseCase,
                    addRequestToBedroomRequestsUseCase,
                    removeRequestFromBedroomRequestsUseCase
            );
        }
    }

}
