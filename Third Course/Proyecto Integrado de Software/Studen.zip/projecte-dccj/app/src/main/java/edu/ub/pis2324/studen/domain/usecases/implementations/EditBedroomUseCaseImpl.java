package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import io.reactivex.rxjava3.core.Observable;

import java.util.ArrayList;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.usecases.interfaces.EditBedroomUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;

public class EditBedroomUseCaseImpl implements EditBedroomUseCase {

    private BedroomRepository bedroomRepository;
    private StudenThrowableMapper throwableMapper;


    public EditBedroomUseCaseImpl(BedroomRepository bedroomRepository) {
        this.bedroomRepository = bedroomRepository;
        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(BedroomRepository.Error.UPDATE_UNKNOWN_ERROR, Error.UPDATE_UNKNOWN_ERROR);
    }

    public Observable<Boolean> execute(BedroomId bedroomId, float squaredMeters, ArrayList<BedroomFeatures> features, String description, Address address, BedroomType bedroomType) {
        return checkData(squaredMeters, description, address)
                .concatMap(
                        ignored -> {
                            return bedroomRepository.update(bedroomId, new BedroomRepository.OnUpdateListener() {
                                @Override
                                public void update(Bedroom bedroom) {
                                    bedroom.setSize(squaredMeters);
                                    bedroom.setFeatures(features);
                                    bedroom.setDescription(description);
                                    bedroom.setAddress(address);
                                    bedroom.setType(bedroomType);
                                }
                            });
                        })
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }

    //Mètode síncron, pero que treballem amb observables per mantenir una solució compacta i
    // compatible amb l'asincronia dels altres observables.
    private Observable<Boolean> checkData(float squaredMeters, String description, Address address) {
        if (squaredMeters <= 0) {
            return Observable.error(new StudenThrowable(Error.SQUARED_METERS_ERROR));
        }
        if (description == null || description.isEmpty()) {
            return Observable.error(new StudenThrowable(Error.DESCRIPTION_ERROR));
        }
        if (address == null) {
            return Observable.error(new StudenThrowable(Error.ADDRESS_FIELDS_ERROR));
        }
        return Observable.just(true);
    }


}
