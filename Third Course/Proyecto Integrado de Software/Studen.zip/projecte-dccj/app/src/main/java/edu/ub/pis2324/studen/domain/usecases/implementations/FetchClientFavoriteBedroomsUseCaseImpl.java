package edu.ub.pis2324.studen.domain.usecases.implementations;

import java.util.ArrayList;
import java.util.List;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientFavoriteBedroomsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchClientFavoriteBedroomsUseCaseImpl implements FetchClientFavoriteBedroomsUseCase {

    BedroomRepository bedroomRepository;
    FetchClientUseCase fetchClientUseCase;

    StudenThrowableMapper throwableMapper;

    public FetchClientFavoriteBedroomsUseCaseImpl(FetchClientUseCase fetchClientUseCase, BedroomRepository bedroomRepository) {
        this.bedroomRepository = bedroomRepository;
        this.fetchClientUseCase = fetchClientUseCase;
        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(FetchClientUseCase.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);
        throwableMapper.add(FetchClientUseCase.Error.CLIENTS_DATA_ACCESS_ERROR, Error.CLIENTS_DATA_ACCESS_ERROR);
        throwableMapper.add(BedroomRepository.Error.GETBYIDS_UNKNOWN_ERROR, Error.BEDROOMS_DATA_ACCESS_ERROR);


    }

    @Override
    public Observable<List<Bedroom>> execute(ClientId clientId) {
        return fetchClientUseCase.execute(clientId).
                concatMap(client -> getFavoriteBedrooms(client))
                .concatMap(bedroomIds -> bedroomRepository.getByIds(bedroomIds))
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }

    private Observable<List<BedroomId>> getFavoriteBedrooms(Client client) {
        if (client.getFavoriteBedrooms().isEmpty())
            return Observable.error(new StudenThrowable(Error.FAVORITES_EMPTY));
        else
            return Observable.just(client.getFavoriteBedrooms());


    }
}
