package edu.ub.pis2324.studen.domain.usecases.interfaces;


import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;


public interface FetchPotencialClientRequestUseCase {

    public Observable<Request> execute(BedroomId bedroomId);

    enum Error implements StudenError {
        CLIENT_NOT_FOUND,
        CLIENTS_DATA_ACCESS_ERROR,
    }


}
