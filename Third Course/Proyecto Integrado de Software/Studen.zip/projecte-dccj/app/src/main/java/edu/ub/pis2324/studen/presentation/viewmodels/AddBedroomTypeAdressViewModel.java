package edu.ub.pis2324.studen.presentation.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SignUpUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.disposables.CompositeDisposable;

public class AddBedroomTypeAdressViewModel extends AndroidViewModel {

    /* Constructor */
    public AddBedroomTypeAdressViewModel(Application application) {
        super(application);
    }

    public static class Factory extends ViewModelProvider.NewInstanceFactory {
        private final Application application;

        public Factory(Application application) {
            this.application = application;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new AddBedroomTypeAdressViewModel(application);
        }
    }
}
