package edu.ub.pis2324.studen.domain.usecases.interfaces;

import java.util.List;

import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.utils.Parella;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface FetchBedroomRequestsClientsUseCase {
    Observable<List<Parella<Request, Client>>> execute(BedroomId bedroomId);

    enum Error implements StudenError {
        BEDROOM_NOT_FOUND,
        BEDROOM_DATA_ACCESS_ERROR,
        REQUESTS_DATA_ACCESS_ERROR,
        REQUESTS_EMPTY;
    }
}
