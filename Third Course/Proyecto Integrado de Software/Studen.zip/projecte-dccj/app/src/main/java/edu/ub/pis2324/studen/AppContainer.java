
package edu.ub.pis2324.studen;

import edu.ub.pis2324.studen.data.repositories.firestore.FirestoreRepositoryFactory;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.AbstractRepositoryFactory;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.services.CheckClientExistsService;
import edu.ub.pis2324.studen.domain.services.implementations.CheckClientExistsServiceImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.AddBedroomToClientFavoritesUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.AddBedroomUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.AddRequestToBedroomRequestsUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.EditBedroomUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.EditProfileUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchBedroomByClientIdUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchBedroomRequestsClientsUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchBedroomUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchBedroomsByNameUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchBedroomsCatalogUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchClientFavoriteBedroomsUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchPopularBedroomsUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchClientUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.FetchPotencialClientRequestUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.GetValidBedroomIdUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.LogInUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.RemoveBedroomFromClientFavoritesUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.RemovePotentialClientUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.RemoveRequestFromBedroomRequestsUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.SetPotentialClientUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.SignUpUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.implementations.VerifyClientUseCaseImpl;
import edu.ub.pis2324.studen.domain.usecases.interfaces.AddBedroomToClientFavoritesUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.AddBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.AddRequestToBedroomRequestsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.EditBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.EditProfileUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomByClientIdUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomRequestsClientsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomsByNameUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomsCatalogUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientFavoriteBedroomsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchPopularBedroomsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchPotencialClientRequestUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.GetValidBedroomIdUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.LogInUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemoveBedroomFromClientFavoritesUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemovePotentialClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemoveRequestFromBedroomRequestsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SetPotentialClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SignUpUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.VerifyClientUseCase;

/**
 *
 * AQUESTA CLASSE SERVEIX PER A INJECTAR TOTES LES DEPENDÈNCIES. COM QUE TOT ESTÀ PROGRAMAT
 * AMB INTERFÍCIES, AQUESTES INTERFÍCIES S'HAN DE INSTANCIAR EN ALGUN MOMENT. AQUESTA CLASSE
 * S'ENCARREGA DE FER LA INJECCIÓ DE DEPENDÈNCIES.
 *
 *
 */


public class AppContainer {

    public Client client;
    /* Repositories */
    public final AbstractRepositoryFactory abstractRepositoryFactory
            = new FirestoreRepositoryFactory();
    public final ClientRepository clientRepository
            = abstractRepositoryFactory.createClientRepository();

    /* Domain-application services */
    public final CheckClientExistsService checkClientUseCase
            = new CheckClientExistsServiceImpl(clientRepository);

    /* Use cases */
    public final FetchClientUseCase fetchClientUseCase
            = new FetchClientUseCaseImpl(clientRepository);
    public final BedroomRepository bedroomRepository = abstractRepositoryFactory.createBedroomRepository();
    public final FetchBedroomUseCase fetchBedroomUseCase
            = new FetchBedroomUseCaseImpl(bedroomRepository);
    public final FetchBedroomByClientIdUseCase fetchBedroomByClientIdUseCase
            = new FetchBedroomByClientIdUseCaseImpl(clientRepository, bedroomRepository);

    public final EditBedroomUseCase editBedroomUseCase
            = new EditBedroomUseCaseImpl(bedroomRepository);
    public final FetchBedroomsByNameUseCase fetchBedroomsByNameUseCase
            = new FetchBedroomsByNameUseCaseImpl(bedroomRepository, fetchClientUseCase);

    public final FetchBedroomsCatalogUseCase fetchBedroomsCatalogUseCase
            = new FetchBedroomsCatalogUseCaseImpl(bedroomRepository);
    public final GetValidBedroomIdUseCase getValidBedroomIdUseCase
            = new GetValidBedroomIdUseCaseImpl(bedroomRepository);
    public final AddBedroomUseCase addBedroomUseCase
            = new AddBedroomUseCaseImpl(bedroomRepository, clientRepository, getValidBedroomIdUseCase);

    public final LogInUseCase logInUseCase
            = new LogInUseCaseImpl(fetchClientUseCase);
    public final SignUpUseCase signUpUseCase
            = new SignUpUseCaseImpl(checkClientUseCase, clientRepository);

    public final EditProfileUseCase editProfileUseCase
            = new EditProfileUseCaseImpl(checkClientUseCase, clientRepository);

    public final FetchPopularBedroomsUseCase fetchPopularBedroomsUseCase
            = new FetchPopularBedroomsUseCaseImpl(bedroomRepository);

    public final FetchClientFavoriteBedroomsUseCase fetchClientFavoriteBedroomsUseCase
            = new FetchClientFavoriteBedroomsUseCaseImpl(fetchClientUseCase, bedroomRepository);
    public final AddBedroomToClientFavoritesUseCase addBedroomToClientFavoritesUseCase 
            = new AddBedroomToClientFavoritesUseCaseImpl(clientRepository, fetchClientUseCase);
    public final RemoveBedroomFromClientFavoritesUseCase removeBedroomFromClientFavoritesUseCase 
            = new RemoveBedroomFromClientFavoritesUseCaseImpl(clientRepository, fetchClientUseCase);
    public final VerifyClientUseCase verifyClientUseCase 
            = new VerifyClientUseCaseImpl(clientRepository);
    public final FetchBedroomRequestsClientsUseCase fetchBedroomRequestsClientsUseCase 
            = new FetchBedroomRequestsClientsUseCaseImpl(fetchBedroomUseCase, fetchClientUseCase);
    public final AddRequestToBedroomRequestsUseCase addRequestToBedroomRequestsUseCase 
            = new AddRequestToBedroomRequestsUseCaseImpl(bedroomRepository, fetchBedroomUseCase);
    public final RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase 
            = new RemoveRequestFromBedroomRequestsUseCaseImpl(bedroomRepository, fetchBedroomUseCase);
    public final SetPotentialClientUseCase setPotentialClientUseCase 
            = new SetPotentialClientUseCaseImpl(bedroomRepository, fetchBedroomUseCase);
    public final RemovePotentialClientUseCase removePotentialClientUseCase 
            = new RemovePotentialClientUseCaseImpl(bedroomRepository, fetchBedroomUseCase);
    public final FetchPotencialClientRequestUseCase fetchPotencialClientRequestUseCase 
            = new FetchPotencialClientRequestUseCaseImpl(bedroomRepository);

    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }

}

