package edu.ub.pis2324.studen.domain.usecases.interfaces;

import java.util.List;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.utils.Parella;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface FetchBedroomsByNameUseCase {
    Observable<List<Parella<Bedroom, Client>>> execute(String name);

    enum Error implements StudenError {
        GETBYNAME_UNKNOWN_ERROR, // Produït per getByName
        CLIENT_NOT_FOUND, // Produït per fetchClientUseCase.execute
        BEDROOMS_DATA_ACCESS_ERROR;
    }
}
