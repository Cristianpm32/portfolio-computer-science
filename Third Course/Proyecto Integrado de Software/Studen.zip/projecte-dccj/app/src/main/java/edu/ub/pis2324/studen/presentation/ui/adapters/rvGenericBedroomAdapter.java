package edu.ub.pis2324.studen.presentation.ui.adapters;


import android.annotation.SuppressLint;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.utils.ImagePlacer;

public class rvGenericBedroomAdapter extends RecyclerView.Adapter<rvGenericBedroomAdapter.BedroomViewHolder> {

    // The adapter class which
    // extends RecyclerView Adapter

    // List with String type
    private List<BedroomPO> bedroomPOList;

    private OnBedroomClickListener onBedroomClickListener;
    // View Holder class which
    // extends RecyclerView.ViewHolder


    // Constructor for adapter class
    // which takes a list of String type

    public interface OnBedroomClickListener {
        void onBedroomClick(BedroomPO bedroomPO);

    }

    public rvGenericBedroomAdapter(OnBedroomClickListener onBedroomClickListener)
    {
        super();
        this.onBedroomClickListener = onBedroomClickListener;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setData(List<BedroomPO> bedroomPOList) {
        this.bedroomPOList = bedroomPOList; // Note that this is a reference, not a copy. It is
        // instead modified by the ViewModel directly
        notifyDataSetChanged(); // Reflect the changes in the UI
    }

    /**
     * Create a ViewHolder object for each data element.
     * @param parent: The parent ViewGroup. In this case, the RecyclerView.
     * @param viewType: The type of the view. In this case, it is not used.
     */
    @NonNull
    @Override
    public BedroomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        /* Create a ViewHolder object for this data element */
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.item_rv_bedroom, parent, false);

        /* Return the ViewHolder object */
        return new BedroomViewHolder(view, position -> onBedroomClickListener.onBedroomClick(bedroomPOList.get(position)));
    }

    /**
     * Bind the actual data of the ProductModel to the ViewHolder object created in
     * onCreateViewHolder.
     * @param holder The ViewHolder which should be updated to represent the contents of the
     *        item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull BedroomViewHolder holder, int position) {
        /* Get the data from the data element */
        BedroomPO p = bedroomPOList.get(position);
        String City = p.getAddress().getCity();

        /* Set the data to the ViewHolder */
        holder.tvCity.setText(City);
        String imageUrl = p.getMainPhotoUrl();
        ImagePlacer.placeImage(imageUrl, holder.ivBedroomImage);
    }

    // Override getItemCount which Returns
    // the length of the RecyclerView.
    @Override
    public int getItemCount() {
        if(bedroomPOList == null) return 0;
        return bedroomPOList.size();
    }

    public void removeBedroom(int position) {
        /* The product must have been removed from the viewmodel before this
         * this is why we need a OnProductHideIconClickListener, so we can
         * reach the ViewModel through the activity and call this method from the latter
         * when ViewModel is done removing the item */
        notifyItemRemoved(position);
    }

    public interface OnItemPositionClickListener {
        void onItemPositionClick(int position);
    }

    public class BedroomViewHolder extends RecyclerView.ViewHolder {
        TextView tvCity;
        ImageView ivBedroomImage;

        // parameterised constructor for View Holder class
        // which takes the view as a parameter
        public BedroomViewHolder(View view, OnItemPositionClickListener onItemPositionClickListener) {
            super(view);
            tvCity = view.findViewById(R.id.tvCity);
            ivBedroomImage = view.findViewById(R.id.ivBedroomImage);
            view.setOnClickListener(
                    v -> onItemPositionClickListener.onItemPositionClick(getAdapterPosition())
            );
        }
    }

}
