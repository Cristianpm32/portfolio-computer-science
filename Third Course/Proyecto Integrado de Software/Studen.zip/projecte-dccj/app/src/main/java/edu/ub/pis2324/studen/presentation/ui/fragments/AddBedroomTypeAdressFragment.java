package edu.ub.pis2324.studen.presentation.ui.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.google.gson.Gson;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentAddBedroomTypeAdressBinding;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.presentation.viewmodels.AddBedroomTypeAdressViewModel;

public class AddBedroomTypeAdressFragment extends Fragment {

    private AddBedroomTypeAdressViewModel addBedroomTypeAdressViewModel;
    /* View binding & navigation */
    private AppContainer appContainer;
    private NavController navController;
    private FragmentAddBedroomTypeAdressBinding binding;

    // View Control
    private boolean typeHouseClicked;
    private boolean typeApartmentClicked;
    private boolean typeBedroomClicked;

    private BedroomType bedroomType;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentAddBedroomTypeAdressBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        initConfig();
        initViewModels();
    }


    private void initConfig() {

        binding.btnNextABTA.setBackgroundResource(R.drawable.button_shape_gray);
        binding.btnNextABTA.setText("Omple els camps");
        binding.btnNextABTA.setEnabled(false);

        
        typeHouseClicked = false;
        typeApartmentClicked = false;
        typeBedroomClicked = false;

        binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border);
        binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border);
        binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border);

        initWidgetListeners();
    }

    private void initWidgetListeners() {
        binding.imBtnTypeBedroomABTA.setOnClickListener(ignoredView -> {
            if (!typeBedroomClicked) {

                binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border_pressed);
                typeBedroomClicked = true;
                bedroomType = BedroomType.BEDROOM;

                binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border);
                typeApartmentClicked = false;

                binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border);
                typeHouseClicked = false;

                checkSeguent();
            }
        });

        binding.imBtnTypeApartmentABTA.setOnClickListener(ignoredView -> {
            if (!typeApartmentClicked) {

                binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border);
                typeBedroomClicked = false;

                binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border_pressed);
                typeApartmentClicked = true;
                bedroomType = BedroomType.APARTMENT;

                binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border);
                typeHouseClicked = false;

                checkSeguent();
            }
        });

        binding.imBtnTypeHouseABTA.setOnClickListener(ignoredView -> {
            if (!typeHouseClicked) {

                binding.imBtnTypeBedroomABTA.setBackgroundResource(R.drawable.button_border);
                typeBedroomClicked = false;

                binding.imBtnTypeApartmentABTA.setBackgroundResource(R.drawable.button_border);
                typeApartmentClicked = false;

                binding.imBtnTypeHouseABTA.setBackgroundResource(R.drawable.button_border_pressed);
                typeHouseClicked = true;
                bedroomType = BedroomType.HOUSE;

                checkSeguent();
            }
        });

        binding.btnNextABTA.setOnClickListener(ignoredView -> {
            SharedPreferences.Editor editor = getActivity().getSharedPreferences("ADD_BEDROOM", MODE_PRIVATE).edit();
            editor.clear();

            String clientModelJsonString = new Gson().toJson(bedroomType);
            editor.putString("TYPE", clientModelJsonString);
            editor.putString("COUNTRY", String.valueOf(binding.etCountryABTA.getText()));
            editor.putString("CITY", String.valueOf(binding.etCityABTA.getText()));
            editor.putString("STREET", String.valueOf(binding.etDirectionABTA.getText()));
            editor.putInt("POSTAL_CODE", Integer.parseInt(String.valueOf(binding.etPostalCodeABTA.getText())));
            editor.commit();

            navController.navigate(R.id.action_addBedroomTypeAdressFragment_to_addBedroomFeaturesFragment);
        });

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override
            public void afterTextChanged(Editable s) {
                checkSeguent();
            }
        };

        binding.etCountryABTA.addTextChangedListener(textWatcher);
        binding.etCityABTA.addTextChangedListener(textWatcher);
        binding.etDirectionABTA.addTextChangedListener(textWatcher);
        binding.etPostalCodeABTA.addTextChangedListener(textWatcher);
    }

    private void initViewModels() {
        addBedroomTypeAdressViewModel = new ViewModelProvider(this,
                new AddBedroomTypeAdressViewModel.Factory(
                        getActivity().getApplication())
        ).get(AddBedroomTypeAdressViewModel.class);
    }

    private void checkSeguent() {
        boolean textCountry = binding.etCountryABTA.getText().length() > 0;
        boolean textCity = binding.etCityABTA.getText().length() > 0;
        boolean textDirection = binding.etDirectionABTA.getText().length() > 0;
        boolean textPostalCode = binding.etPostalCodeABTA.getText().length() > 0;
        boolean typeClicked = typeBedroomClicked || typeApartmentClicked || typeHouseClicked;
        if (textCity && textCountry && textDirection && textPostalCode && typeClicked) {
            binding.btnNextABTA.setBackgroundResource(R.drawable.button_shape_black);
            binding.btnNextABTA.setText("Següent");
            binding.btnNextABTA.setEnabled(true);
        } else {
            binding.btnNextABTA.setBackgroundResource(R.drawable.button_shape_gray);
            binding.btnNextABTA.setText("Omple tots els camps");
            binding.btnNextABTA.setEnabled(false);
        }
    }
}