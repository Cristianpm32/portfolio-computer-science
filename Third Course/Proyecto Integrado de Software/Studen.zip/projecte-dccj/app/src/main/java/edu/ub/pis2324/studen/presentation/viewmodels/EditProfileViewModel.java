package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Universitat;
import edu.ub.pis2324.studen.domain.usecases.interfaces.EditProfileUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SignUpUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class EditProfileViewModel extends AndroidViewModel {

    FetchClientUseCase fetchClientUseCase;
    EditProfileUseCase editProfileUseCase;
    ClientId clientId;
    StateLiveData<ClientPO> clientState;
    StateLiveData<Boolean> editProfileState;
    CompositeDisposable compositeDisposable;


    /* Constructor */
    public EditProfileViewModel(FetchClientUseCase fetchClientUseCase, EditProfileUseCase editProfileUseCase, Application application) {
        super(application);
        clientState = new StateLiveData<>();
        editProfileState = new StateLiveData<>();
        this.fetchClientUseCase = fetchClientUseCase;
        this.editProfileUseCase = editProfileUseCase;
        compositeDisposable = new CompositeDisposable();


        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("CLIENT_MODEL", null);
        clientId = new Gson().fromJson(json, ClientPO.class).getId();
        trobarClient();



    }

    private void trobarClient() {
        Disposable d = fetchClientUseCase.execute(clientId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        client -> {
                            // Transformem les dades a PO per a poder-les enviar a la vista
                            clientState.postSuccess(DomainToPOMapper.getInstance().map(client, ClientPO.class));
                        },
                        throwable -> handleError(throwable)
                );

        compositeDisposable.add(d);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        compositeDisposable.dispose();
    }

    public StateLiveData<ClientPO> getClientState() {
        return clientState;
    }

    public StateLiveData<Boolean> getEditProfileState() {
        return editProfileState;
    }


    public void editProfile(String nom, String cognoms, String birthDate, String email, int telefon, String description, String universitat) {
        Disposable d = editProfileUseCase.execute(clientId, nom, cognoms, birthDate, email, telefon, description, universitat)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        client -> {
                            editProfileState.postSuccess(true);
                        },
                        throwable -> handleError(throwable)
                );

        compositeDisposable.add(d);
    }

    private void handleError(Throwable throwable) {
        if (throwable instanceof StudenThrowable)
            handleStudenError((StudenThrowable) throwable);
        else
            editProfileState.postError(new Throwable("Unknown error"));
    }

    private void handleStudenError(StudenThrowable studenThrowable) {
        String message;
        StudenError sError = studenThrowable.getError();
        if (sError == EditProfileUseCase.Error.EMAIL_EMPTY)
            message = "Email empty";
        else if (sError == EditProfileUseCase.Error.UPDATE_UNKNOWN_ERROR)
            message = "Update unknown error";
        else if (sError == EditProfileUseCase.Error.CLIENT_NOT_FOUND 
                || sError == FetchClientUseCase.Error.CLIENT_NOT_FOUND)
            message = "Client not found";
        else if (sError == EditProfileUseCase.Error.CLIENTS_DATA_ACCESS_ERROR 
                || sError == FetchClientUseCase.Error.CLIENTS_DATA_ACCESS_ERROR)
            message = "Clients data access error";
        else
            message = "Unknown error";
        
        editProfileState.postError(new Throwable(message));
    }

    public static class Factory extends ViewModelProvider.NewInstanceFactory {

        private final FetchClientUseCase fetchClientUseCase;
        private final EditProfileUseCase editProfileUseCase;
        private final Application application;

        public Factory(FetchClientUseCase fetchClientUseCase, EditProfileUseCase editProfileUseCase, Application application) {
            this.fetchClientUseCase = fetchClientUseCase;
            this.editProfileUseCase = editProfileUseCase;
            this.application = application;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new EditProfileViewModel(fetchClientUseCase, editProfileUseCase, application);
        }
    }

}
