package edu.ub.pis2324.studen.presentation.PresentationObjects.mappers;

import org.modelmapper.AbstractConverter;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration;
import org.modelmapper.convention.MatchingStrategies;

import java.util.List;
import java.util.stream.Collectors;

import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;

public class DomainToPOMapper extends ModelMapper {

    // getInstance
    private static DomainToPOMapper instance;

    public static DomainToPOMapper getInstance() {
        if (instance == null) {
            instance = new DomainToPOMapper();
        }
        return instance;
    }
    
    public DomainToPOMapper() {
        super();

        super.getConfiguration()
                .setFieldMatchingEnabled(true) // No need to define setters
                .setFieldAccessLevel(Configuration.AccessLevel.PRIVATE)
                .setMatchingStrategy(MatchingStrategies.LOOSE);

        super.addConverter(new AbstractConverter<ClientId, String>() {
            @Override
            protected String convert(ClientId source) {
                return source.toString();
            }
        });
    }
    
    public <S, T> List<T> mapList(List<S> source, Class<T> targetClass) {
        return source
                .stream()
                .map(element -> super.map(element, targetClass))
                .collect(Collectors.toList());
    }
}


