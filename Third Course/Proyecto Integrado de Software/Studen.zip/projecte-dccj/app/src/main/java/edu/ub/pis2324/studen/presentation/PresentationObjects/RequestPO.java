package edu.ub.pis2324.studen.presentation.PresentationObjects;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.Arrays;

import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;

public class RequestPO implements Parcelable {

    private String dataPeticio;
    private ClientId nomClient;

    public RequestPO(String dataPeticio, ClientId nomClient) {
        this.dataPeticio = dataPeticio;
        this.nomClient = nomClient;

    }

    public RequestPO() {
    }


    public String getDataPeticio() {
        return dataPeticio;
    }
    public ClientId getNomClient() {
        return nomClient;
    }



    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int flags) {
        parcel.writeString(this.dataPeticio);
        parcel.writeSerializable(this.nomClient);
    }

    public void readFromParcel(Parcel source) {
        this.dataPeticio = source.readString();
        this.nomClient = (ClientId) source.readSerializable();
    }
    protected RequestPO(Parcel in) {
        this.dataPeticio = in.readString();
        this.nomClient = (ClientId) in.readSerializable();
    }


    public static final Parcelable.Creator<RequestPO> CREATOR = new Parcelable.Creator<RequestPO>() {
        @Override
        public RequestPO createFromParcel(Parcel source) {return new RequestPO(source);
        }
        @Override
        public RequestPO[] newArray(int size) {return new RequestPO[size];
        }
    };
}
