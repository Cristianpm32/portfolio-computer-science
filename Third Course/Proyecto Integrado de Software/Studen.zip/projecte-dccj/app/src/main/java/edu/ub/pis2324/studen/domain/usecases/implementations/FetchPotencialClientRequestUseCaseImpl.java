package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchPotencialClientRequestUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchPotencialClientRequestUseCaseImpl implements FetchPotencialClientRequestUseCase {

    private BedroomRepository bedroomRepository;
    private StudenThrowableMapper throwableMapper;


    public FetchPotencialClientRequestUseCaseImpl(BedroomRepository bedroomRepository) {
        this.bedroomRepository = bedroomRepository;
        this.throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(FetchClientUseCase.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);
    }
    @Override
    public Observable<Request> execute(BedroomId bedroomId) {

        return bedroomRepository.getRequest(bedroomId)
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }

}
