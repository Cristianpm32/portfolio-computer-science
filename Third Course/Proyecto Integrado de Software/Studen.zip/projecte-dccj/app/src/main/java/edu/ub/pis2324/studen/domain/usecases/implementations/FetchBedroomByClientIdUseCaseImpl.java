package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomByClientIdUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchBedroomByClientIdUseCaseImpl implements FetchBedroomByClientIdUseCase {

    private ClientRepository clientRepository;
    private BedroomRepository bedroomRepository;
    private StudenThrowableMapper throwableMapper;
    public FetchBedroomByClientIdUseCaseImpl(ClientRepository clientRepository, BedroomRepository bedroomRepository) {
        this.clientRepository = clientRepository;
        this.bedroomRepository = bedroomRepository;
        this.throwableMapper = new StudenThrowableMapper();
        this.throwableMapper.add(ClientRepository.Error.CLIENT_NOT_FOUND, Error.CLIENT_NOT_FOUND);
        this.throwableMapper.add(ClientRepository.Error.GETBYID_UNKNOWN_ERROR, Error.CLIENTS_DATA_ACCESS_ERROR);
        this.throwableMapper.add(BedroomRepository.Error.BEDROOM_NOT_FOUND, Error.BEDROOM_NOT_FOUND);
        this.throwableMapper.add(BedroomRepository.Error.GETBYID_UNKNOWN_ERROR, Error.BEDROOMS_DATA_ACCESS_ERROR);
    }

    public Observable<Bedroom> execute(ClientId clientId) {
        return clientRepository.getById(clientId)
          .concatMap(client -> bedroomRepository.getById(client.getBedroomId()))
          .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }
}
