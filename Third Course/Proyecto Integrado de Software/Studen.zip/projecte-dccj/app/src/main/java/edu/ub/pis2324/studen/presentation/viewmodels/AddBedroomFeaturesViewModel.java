package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import java.util.ArrayList;

import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.AddBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SignUpUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class AddBedroomFeaturesViewModel extends AndroidViewModel {

    Application application;
    StateLiveData<BedroomId> addingState;
    CompositeDisposable compositeDisposable;
    AddBedroomUseCase addBedroomUseCase;


    /* Constructor */
    public AddBedroomFeaturesViewModel(Application application, AddBedroomUseCase addBedroomUseCase) {
        super(application);
        addingState = new StateLiveData<>();
        compositeDisposable = new CompositeDisposable();
        this.application = application;
        this.addBedroomUseCase = addBedroomUseCase;
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        compositeDisposable.dispose();
    }

    public void addBedroom(int squaredMeters, ArrayList<BedroomFeatures> features, String description){

        // Treballem amb aquesta implementació perque necessitem dades de 2 fragments i poder passar
        // dades entre ells en els dos sentits. Això ho fem mitjançant SharedPreferences.

        // Obtenim el clientId
        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("CLIENT_MODEL", null);
        ClientId clientId = new Gson().fromJson(json, ClientPO.class).getId();

        // Obtenim el tipus de l'habitació
        preferences = application.getSharedPreferences("ADD_BEDROOM", MODE_PRIVATE);
        json = preferences.getString("TYPE", null);
        BedroomType type = new Gson().fromJson(json, BedroomType.class);

        String city = preferences.getString("CITY", null);
        String street = preferences.getString("STREET", null);
        String country = preferences.getString("COUNTRY", null);
        int postalCode = preferences.getInt("POSTAL_CODE", 0);

        Address address = new Address(street, city, Integer.toString(postalCode), country);

        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.commit();

        Disposable d = addBedroomUseCase.execute(squaredMeters, features, description, address, clientId, type)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        // En aquest cas com que és un bedroomId no necessita transformació
                        bedroomId -> addingState.postSuccess(bedroomId),
                        throwable -> handleError(throwable)
                );
        addingState.postComplete();
        compositeDisposable.add(d);

    }

    public StateLiveData<BedroomId> getAddingState() {
        return addingState;
    }

    private void handleError(Throwable throwable) {
        if (throwable instanceof StudenThrowable)
            handleStudenError((StudenThrowable) throwable);
        else
            addingState.postError(new Throwable("Unknown error"));
    }

    private void handleStudenError(StudenThrowable studenThrowable) {
        String message;
        StudenError xError = studenThrowable.getError();
        if (xError == AddBedroomUseCase.Error.GETVALIDBEDROOMID_UNKNOWN_ERROR)
            message = "Error getting valid bedroom id";
        else if (xError == AddBedroomUseCase.Error.ADD_UNKNOWN_ERROR)
            message = "Error adding bedroom";
        else if (xError == AddBedroomUseCase.Error.SQUARED_METERS_EMPTY)
            message = "Squared meters empty";
        else if (xError == AddBedroomUseCase.Error.DESCRIPTION_EMPTY)
            message = "Description empty";
        else if (xError == AddBedroomUseCase.Error.BEDROOMS_DATA_ACCESS_ERROR)
            message = "Error accessing bedrooms data";
        else
            message = "Unknown error";

        addingState.postError(new Throwable(message));
    }


    public static class Factory extends ViewModelProvider.NewInstanceFactory {
        private final Application application;
        private final AddBedroomUseCase addBedroomUseCase;

        public Factory(Application application, AddBedroomUseCase addBedroomUseCase) {
            this.application = application;
            this.addBedroomUseCase = addBedroomUseCase;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new AddBedroomFeaturesViewModel(application, addBedroomUseCase);
        }
    }
}
