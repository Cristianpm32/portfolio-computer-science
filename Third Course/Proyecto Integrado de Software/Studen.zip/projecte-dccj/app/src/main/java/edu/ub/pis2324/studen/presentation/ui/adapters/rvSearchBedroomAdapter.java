package edu.ub.pis2324.studen.presentation.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.ImagePlacer;
import edu.ub.pis2324.studen.utils.Parella;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Scheduler;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class rvSearchBedroomAdapter extends RecyclerView.Adapter<rvSearchBedroomAdapter.BedroomViewHolder> {

    // List with BedroomPO type
    private List<Parella<BedroomPO, ClientPO>> bedroomPOList;
    private OnBedroomClickListener onBedroomClickListener;


    /**
     * This interface is used to define the method that will be called when a bedroom is clicked.
     */
    public interface OnBedroomClickListener {
        void onBedroomClick(BedroomPO bedroomPO);
    }

    public rvSearchBedroomAdapter(OnBedroomClickListener onBedroomClickListener) {
        super();
        this.onBedroomClickListener = onBedroomClickListener;
    }

    /**
     * This method is called by the ViewModel to update the data in the RecyclerView.
     *
     * @param bedroomPOList: The list of BedroomPO objects to be displayed in the RecyclerView.
     */
    public void setData(List<Parella<BedroomPO, ClientPO>> bedroomPOList) {
        this.bedroomPOList = bedroomPOList;
        notifyDataSetChanged();
    }


    /**
     * This method is called by the RecyclerView to create a new ViewHolder object.
     *
     * @param parent:   The parent ViewGroup. In this case, the RecyclerView.
     * @param viewType: The type of view.
     * @return A new ViewHolder object.
     */
    @NonNull
    @Override
    public BedroomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        /* Inflate the layout for the item */
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rv_bedroom_search, parent, false);
        /* Create a ViewHolder object for this data element */
        return new BedroomViewHolder(view, position -> onBedroomClickListener.onBedroomClick(bedroomPOList.get(position).getFirst()));
    }

    /**
     * This method is called by the RecyclerView to display the data at the specified position.
     *
     * @param holder:   The ViewHolder object to be updated.
     * @param position: The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull BedroomViewHolder holder, int position) {
        BedroomPO bedroomPO = bedroomPOList.get(position).getFirst();
        ClientPO clientPO = bedroomPOList.get(position).getSecond();
        holder.tvOwnerName.setText(clientPO.getNom());
        holder.tvUniversityName.setText(clientPO.getUniversitat().getNom());
        holder.tvNeighborhoodName.setText(bedroomPO.getAddress().getCity());

        ImagePlacer.placeImage(bedroomPO.getMainPhotoUrl(), holder.ivBedroomImage);

    }

    /**
     * This method is called by the RecyclerView to get the number of items in the data set.
     *
     * @return The number of items in the data set.
     */
    @Override
    public int getItemCount() {
        return bedroomPOList == null ? 0 : bedroomPOList.size();
    }

    /**
     * This method is called by the ViewModel to remove a bedroom from the RecyclerView.
     *
     * @param position: The position of the bedroom to be removed.
     */
    public void removeBedroom(int position) {
        //bedroomPOList.remove(position);
        notifyItemRemoved(position);
    }

    /**
     * This interface is used to define the method that will be called when a position is clicked.
     */
    public interface OnItemPositionClickListener {
        void onItemPositionClick(int position);
    }

    /**
     * En aquesta classe interna es defineix el ViewHolder que s'utilitzarà per a la RecyclerView.
     * Aquesta classe associa els elements de la vista amb els atributs de la classe BedroomPO. En
     * aquest cas, prenem els elements de item_rv_bedroom_search.xml i els associem amb els atributs
     * de BedroomPO.
     */
    public class BedroomViewHolder extends RecyclerView.ViewHolder {

        TextView tvOwnerName;
        TextView tvNeighborhoodName;
        TextView tvUniversityName;
        ImageView ivBedroomImage;

        public BedroomViewHolder(View view, OnItemPositionClickListener onItemPositionClickListener) {
            super(view);
            tvOwnerName = view.findViewById(R.id.tvOwnerName);
            tvNeighborhoodName = view.findViewById(R.id.tvNeighborhoodName);
            tvUniversityName = view.findViewById(R.id.tvUniversityName);
            ivBedroomImage = view.findViewById(R.id.ivBedroomImage);
            view.setOnClickListener(
                    v -> onItemPositionClickListener.onItemPositionClick(getAdapterPosition())
            );
        }
    }
}
