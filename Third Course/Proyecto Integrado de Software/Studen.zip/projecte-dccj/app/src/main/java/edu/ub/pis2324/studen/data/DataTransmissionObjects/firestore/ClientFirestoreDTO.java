package edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore;

import com.google.firebase.firestore.DocumentId;

import java.util.ArrayList;
import java.util.List;

import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;

/**
 * Domain entity holding the data and the behavior of a client.
 */
public class ClientFirestoreDTO {
  /* Attributes */
  @DocumentId
  private String id;
  private String email;
  private String password;
  private String photoUrl;
  private String description;
  private String nom;
  private String cognoms;
  private UniversitatFirestoreDTO universitat;
  private int telefon;
  private String dataNaixement;
  private int verificat;
  private String bedroomId;
  private List<String> favoriteBedrooms;


  /**
   * Empty constructor.
   */
  @SuppressWarnings("unused")
  public ClientFirestoreDTO() {
    this.id = "";
    this.email = "";
    this.password = "";
    this.photoUrl = "";
    this.description = "";
    this.nom = "";
    this.cognoms = "";
    this.universitat = new UniversitatFirestoreDTO();
    this.telefon = 0;
    this.dataNaixement = "";
    this.verificat = 0;
    this.bedroomId = "";
    this.favoriteBedrooms = new ArrayList<>();
  }

  /**
   * Gets the id of the client.
   * @return The id of the client.
   */
  public String getId() {
    return id;
  }

  /**
   * Gets the username of the client.
   * @return The username of the client.
   */
  public String getEmail() {
    return email;
  }

  /**
   * Gets the password of the client.
   * @return The password of the client.
   */
  public String getPassword() {
    return password;
  }

  public String getPhotoUrl() {
    return photoUrl;
  }

  public String getDescription() {
        return description;
    }

  public String getNom() {
    return nom;
  }

  public String getCognoms() {
    return cognoms;
  }

  public UniversitatFirestoreDTO getUniversitat() {
    return universitat;
  }

  public int getTelefon() {
    return telefon;
  }

  public String getDataNaixement() {
    return dataNaixement;
  }

  public int getVerificat() {
    return verificat;
  }

  public String getBedroomId() {
    return bedroomId;
  }

  public List<String> getFavoriteBedrooms() {
    return favoriteBedrooms;
  }
}
