package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface FetchBedroomUseCase {

    Observable<Bedroom> execute(BedroomId bedroomId);

    enum Error implements StudenError {
        BEDROOM_NOT_FOUND,
        BEDROOMS_DATA_ACCESS_ERROR;

    }

}
