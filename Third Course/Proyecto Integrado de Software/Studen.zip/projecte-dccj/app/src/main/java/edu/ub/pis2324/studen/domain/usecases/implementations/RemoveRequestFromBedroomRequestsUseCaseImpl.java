package edu.ub.pis2324.studen.domain.usecases.implementations;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemoveRequestFromBedroomRequestsUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class RemoveRequestFromBedroomRequestsUseCaseImpl implements RemoveRequestFromBedroomRequestsUseCase {
    private BedroomRepository bedroomRepository;
    private FetchBedroomUseCase fetchBedroomUseCase;
    private StudenThrowableMapper throwableMapper;
    public RemoveRequestFromBedroomRequestsUseCaseImpl(BedroomRepository bedroomRepository, FetchBedroomUseCase fetchBedroomUseCase) {
        this.bedroomRepository = bedroomRepository;
        this.fetchBedroomUseCase = fetchBedroomUseCase;
        this.throwableMapper = new StudenThrowableMapper();


        throwableMapper.add(BedroomRepository.Error.BEDROOM_NOT_FOUND, RemoveRequestFromBedroomRequestsUseCase.Error.BEDROOM_NOT_FOUND);
        throwableMapper.add(ClientRepository.Error.UPDATE_UNKNOWN_ERROR, RemoveRequestFromBedroomRequestsUseCase.Error.UPDATE_UNKNOWN_ERROR);

    }
    @Override
    public Observable<Bedroom> execute(BedroomId bedroomId, ClientId clientId) {
        return bedroomRepository.update(bedroomId, new BedroomRepository.OnUpdateListener() {
                    @Override
                    public void update(Bedroom bedroom) {
                        bedroom.removeRequest(clientId);
                    }
                }).concatMap(ignored -> fetchBedroomUseCase.execute(bedroomId))
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }
}
