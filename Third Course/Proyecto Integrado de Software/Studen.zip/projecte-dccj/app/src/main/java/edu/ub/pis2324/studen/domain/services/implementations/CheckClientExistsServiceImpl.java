package edu.ub.pis2324.studen.domain.services.implementations;

import java.util.NoSuchElementException;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.services.CheckClientExistsService;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class CheckClientExistsServiceImpl implements CheckClientExistsService {
    /* Attributes */
    private ClientRepository clientRepository;
    private final StudenThrowableMapper throwableMapper;

    /**
     * Constructor
     */
    public CheckClientExistsServiceImpl(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;

        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(ClientRepository.Error.GETBYID_UNKNOWN_ERROR, Error.CLIENTS_DATA_ACCESS_ERROR);
    }

    /**
     * Executes the check client exists use case.
     * @param clientId
     * @return
     */
    @Override
    public Observable<Boolean> execute(ClientId clientId) {
        return clientRepository.getById(clientId)
                .concatMap(ignored -> {
                    // El client ja existeix
                    return Observable.just(true);
                })
                .onErrorResumeNext(throwable -> {
                    if (throwable instanceof StudenThrowable) {
                        StudenError xError = ((StudenThrowable) throwable).getError();
                        if (xError == ClientRepository.Error.CLIENT_NOT_FOUND)
                            return Observable.just(false);
                        else
                            return Observable.error(throwableMapper.map(throwable));
                    } else {
                        return Observable.error(throwable); // Error no controlat
                    }
                });
    }
}
