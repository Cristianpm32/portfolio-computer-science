package edu.ub.pis2324.studen.presentation.viewmodels;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomsByNameUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomsCatalogUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.Parella;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class SearchViewModel extends ViewModel {

    private final FetchBedroomsByNameUseCase fetchBedroomsByNameUseCase;
    private final FetchBedroomsCatalogUseCase fetchBedroomsCatalogUseCase;
    private final List<Parella<BedroomPO, ClientPO>> bedroomPOandClientPOs;
    private final List<BedroomPO> bedroomPOs;
    private final StateLiveData<List<Parella<BedroomPO, ClientPO>>> bedroomClientListState;
    private final StateLiveData<List<BedroomPO>> bedroomListState;

    private final StateLiveData<Integer> hiddenBedroomState;
    private final CompositeDisposable compositeDisposable;
    private final DomainToPOMapper domainToPOMapper;


    public SearchViewModel(FetchBedroomsByNameUseCase fetchBedroomsByNameUseCase, FetchBedroomsCatalogUseCase fetchBedroomsCatalogUseCase) {
        super();
        this.fetchBedroomsByNameUseCase = fetchBedroomsByNameUseCase;
        this.fetchBedroomsCatalogUseCase = fetchBedroomsCatalogUseCase;
        bedroomPOandClientPOs = new ArrayList<>();
        bedroomPOs = new ArrayList<>();
        bedroomClientListState = new StateLiveData<>();
        bedroomListState = new StateLiveData<>();
        hiddenBedroomState = new StateLiveData<>();
        compositeDisposable = new CompositeDisposable();
        domainToPOMapper = new DomainToPOMapper().getInstance();
    }

    /**
     * Parent class (ViewModel's) lifecycle-related method
     */
    public void onCleared() {
        super.onCleared();
        compositeDisposable.dispose();
    }
    public StateLiveData<List<Parella<BedroomPO, ClientPO>>> getBedroomClientListState() {
        return bedroomClientListState;
    }

    public StateLiveData<Integer> getHiddenBedroomState() {
        return hiddenBedroomState;
    }

    public void fetchBedroomsByName(String name) {

        bedroomClientListState.postLoading();

        Disposable d = fetchBedroomsByNameUseCase.execute(name)
          .subscribeOn(Schedulers.io())
          .observeOn(AndroidSchedulers.mainThread())
          .subscribe(
            gottenBedrooms -> handleFetchBedroomsByNameListSuccess(gottenBedrooms),
            throwable -> handleFetchBedroomsListError(throwable)
          );

        compositeDisposable.add(d);
    }

    public void fetchBedroomsCatalog() {
    /*
      To inform to the activity that the products are being fetched,
      in case it wants to show a loading spinner or something.
    */
        bedroomListState.postLoading();

    /*
      Now we ask for the products to some service/respository/usecase.
      But the response is asychronous, so we ask the productRepository
      to set an observable and we subscribe to it.
    */
        Disposable d = fetchBedroomsCatalogUseCase.execute()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        gottenProducts -> handleFetchProductsCatalogSuccess(gottenProducts),
                        throwable -> handleFetchBedroomsListError(throwable)
                );

        compositeDisposable.add(d);
    }

    public void handleFetchProductsCatalogSuccess(List<Bedroom> gottenProducts) {
        // Presentation code
        List<BedroomPO> gottenProductPOs = gottenProducts
                .stream()
                .map(bedroom -> domainToPOMapper.map(bedroom, BedroomPO.class))
                .collect(Collectors.toList());

        bedroomPOs.clear();
        bedroomPOs.addAll(gottenProductPOs);
        bedroomListState.postSuccess(bedroomPOs);
    }

    public void handleFetchBedroomsByNameListSuccess(List<Parella<Bedroom, Client>> gottenBedrooms) {
      // Presentation code

      List<Parella<BedroomPO, ClientPO>> gottenBedroomPOs = gottenBedrooms
              .stream()
              .map(parella -> new Parella<>(domainToPOMapper.map(parella.getFirst(), BedroomPO.class), domainToPOMapper.map(parella.getSecond(), ClientPO.class)))
              .collect(Collectors.toList());

      bedroomPOandClientPOs.clear();
      bedroomPOandClientPOs.addAll(gottenBedroomPOs);
      bedroomClientListState.postSuccess(bedroomPOandClientPOs);
    }

    public void handleFetchBedroomsListError(Throwable throwable) {
        String message;
        StudenError error = ((StudenThrowable) throwable).getError();
        if (error == FetchBedroomsByNameUseCase.Error.BEDROOMS_DATA_ACCESS_ERROR)
          message = "Data access error";
        else
          message = "Unknown error";

        bedroomClientListState.postError(new Throwable(message));
    }


    /**
     * Factory for the ViewModel to be able to pass parameters to the constructor
     */
    public static class Factory extends ViewModelProvider.NewInstanceFactory {
        private final FetchBedroomsByNameUseCase fetchBedroomsByNameUseCase;
        private final FetchBedroomsCatalogUseCase fetchBedroomsCatalogUseCase;

        public Factory(
                FetchBedroomsByNameUseCase fetchBedroomsByNameUseCase,
                FetchBedroomsCatalogUseCase fetchBedroomsCatalogUseCase
        ) {
            this.fetchBedroomsByNameUseCase = fetchBedroomsByNameUseCase;
            this.fetchBedroomsCatalogUseCase = fetchBedroomsCatalogUseCase;
        }

        @NonNull
        @Override
        @SuppressWarnings("unchecked")
        public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
            return (T) new SearchViewModel(
                    fetchBedroomsByNameUseCase,
                    fetchBedroomsCatalogUseCase
            );
        }
    }
}
