package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomRequestsClientsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchPotencialClientRequestUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemoveRequestFromBedroomRequestsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SetPotentialClientUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.RequestPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.Parella;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class RequestsViewModel extends ViewModel {

    private final FetchPotencialClientRequestUseCase fetchPotencialClientRequestUseCase;
    private final FetchBedroomRequestsClientsUseCase fetchBedroomRequestsClientsUseCase;
    private final RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase;
    private final SetPotentialClientUseCase setPotentialClientUseCase;

    // Presentation Objects
    private final List<Parella<RequestPO, ClientPO>> bedroomRequestClientsPOs;

    // Client actual. El necessitem per obtenir el bedroomID
    private ClientPO clientPO;

    /* LiveData */
    private final StateLiveData<List<Parella<RequestPO, ClientPO>>> bedroomRequestsClientsListState;  // requests list
    private final StateLiveData<Integer> hiddenRequestState;
    private final StateLiveData<RequestPO> potentialClientRequestPOState;
    /* RxJava */
    private final CompositeDisposable compositeDisposable;

    private final DomainToPOMapper domainToPOMapper;


    /**
     * Parent class (ViewModel's) lifecycle-related method
     * that is invoked when the activity is purposedly destroyed.
     */

    public RequestsViewModel(Application application, FetchPotencialClientRequestUseCase fetchPotencialClientRequestUseCase, FetchBedroomRequestsClientsUseCase fetchBedroomRequestsClientsUseCase, RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase, SetPotentialClientUseCase setPotentialClientUseCase) {
        super();

        this.fetchPotencialClientRequestUseCase = fetchPotencialClientRequestUseCase;
        this.removeRequestFromBedroomRequestsUseCase = removeRequestFromBedroomRequestsUseCase;
        this.fetchBedroomRequestsClientsUseCase = fetchBedroomRequestsClientsUseCase;
        this.setPotentialClientUseCase = setPotentialClientUseCase;
        bedroomRequestClientsPOs = new ArrayList<>();
        bedroomRequestsClientsListState = new StateLiveData<>();
        hiddenRequestState = new StateLiveData<>();
        potentialClientRequestPOState = new StateLiveData<>();

        compositeDisposable = new CompositeDisposable();
        domainToPOMapper = DomainToPOMapper.getInstance();
        // Obtenim el id del bedroom del client actual del sharedPref
        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("BEDROOM_ID", null);
        String json2 = preferences.getString("CLIENT_MODEL", null);
        clientPO = new Gson().fromJson(json2, ClientPO.class);
        BedroomId bedroomId = new Gson().fromJson(json, BedroomId.class);

        fetchBedroomRequests(bedroomId);
    }


    @Override
    public void onCleared() {
        super.onCleared();
        compositeDisposable.dispose();
    }

    /**
     * Returns the state of the bedrooms being fetched
     *
     * @return the state of the bedrooms being fetched
     */

    public StateLiveData<List<Parella<RequestPO, ClientPO>>> getBedroomRequestsClientsListState() {
        return bedroomRequestsClientsListState;
    }

    public StateLiveData<RequestPO> getPotentialClientPOState() {
        fetchPotentialDealView();
        return potentialClientRequestPOState;
    }

    public StateLiveData<Integer> getHiddenRequestState() {
        return hiddenRequestState;
    }

    /**
     * Fetches the bedrooms from a data store
     */


    public void fetchBedroomRequests(BedroomId bedroomId) {

        /*
      To inform to the activity that the bedrooms are being fetched,
      in case it wants to show a loading spinner or something.
    */
        bedroomRequestsClientsListState.postLoading();
        Disposable d = fetchBedroomRequestsClientsUseCase
                .execute(bedroomId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        gottenRequests -> handleFetchBedroomRequestsSuccess(gottenRequests),
                        throwable -> handleFetchBedroomRequestsError(throwable)
                );
        compositeDisposable.add(d);

    }


    // Aqui es fa la conversio Plain Old Java Object -> Presentation Object
    public void handleFetchBedroomRequestsSuccess(List<Parella<Request, Client>> gottenRequests) {
        // Presentation code
        List<Parella<RequestPO, ClientPO>> gottenRequestPOs = gottenRequests
                .stream()
                .map(parella -> new Parella<>(domainToPOMapper.map(parella.getFirst(), RequestPO.class), domainToPOMapper.map(parella.getSecond(), ClientPO.class)))
                .collect(Collectors.toList());

        bedroomRequestClientsPOs.clear();
        bedroomRequestClientsPOs.addAll(gottenRequestPOs);
        bedroomRequestsClientsListState.postSuccess(bedroomRequestClientsPOs);
    }

    public void handleFetchBedroomRequestsError(Throwable throwable) {
        if(throwable instanceof Exception) {
            bedroomRequestsClientsListState.postError((Exception) throwable);
        }
        else{
            String message;
            StudenError xError = ((StudenThrowable) throwable).getError();
            if (xError == FetchBedroomRequestsClientsUseCase.Error.BEDROOM_NOT_FOUND)
                message = "Data access error";
            else
                message = "Unknown error";
            bedroomRequestsClientsListState.postError(new Throwable(message));
        }
    }

    // Eliminem el request de la llista de requests del bedroom
    public void removeRequestFromBedroomRequests(RequestPO requestPO) {
        bedroomRequestsClientsListState.postLoading();
        Disposable d = removeRequestFromBedroomRequestsUseCase
                .execute(clientPO.getBedroomId(), requestPO.getNomClient())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        // Tornem a carregar les dades del bedroom
                        bedroom -> fetchBedroomRequests(bedroom.getId()),
                        throwable -> handleFetchBedroomRequestsError(throwable)
                );
        compositeDisposable.add(d);
    }

    public void setPotentialClient(RequestPO requestPO) {
        bedroomRequestsClientsListState.postLoading();
        Disposable d = setPotentialClientUseCase
                .execute(clientPO.getBedroomId(), requestPO.getNomClient())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        bedroom -> {},
                        throwable -> handleFetchBedroomRequestsError(throwable)
                );
        compositeDisposable.add(d);
    }
    public void fetchPotentialDealView() {
        potentialClientRequestPOState.postLoading();
        Disposable d = fetchPotencialClientRequestUseCase
                .execute(clientPO.getBedroomId())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        requestPotentialPO -> potentialClientRequestPOState.postSuccess(domainToPOMapper.map(requestPotentialPO, RequestPO.class)),
                        throwable -> potentialClientRequestPOState.postError(throwable)
                );
        compositeDisposable.add(d);
        potentialClientRequestPOState.postComplete();
    }

    /**
     * Hides a product
     *
     * @param position
     */
    public void hideProduct(int position) {

        bedroomRequestClientsPOs.remove(position);
        hiddenRequestState.postSuccess(position);

    }
    /**
     * Factory for the ViewModel to be able to pass parameters to the constructor
     */

    public static class Factory extends ViewModelProvider.NewInstanceFactory {

        private final FetchPotencialClientRequestUseCase fetchPotencialClientRequestUseCase;
        private final FetchBedroomRequestsClientsUseCase fetchBedroomRequestsClientsUseCase;
        private final Application application;
        private final RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase;
        private final SetPotentialClientUseCase setPotentialClientUseCase;

        public Factory(Application application, FetchPotencialClientRequestUseCase fetchPotencialClientRequestUseCase, FetchBedroomRequestsClientsUseCase fetchBedroomRequestsClientsUseCase, RemoveRequestFromBedroomRequestsUseCase removeRequestFromBedroomRequestsUseCase, SetPotentialClientUseCase setPotentialClientUseCase) {
            this.application = application;
            this.fetchPotencialClientRequestUseCase = fetchPotencialClientRequestUseCase;
            this.fetchBedroomRequestsClientsUseCase = fetchBedroomRequestsClientsUseCase;
            this.removeRequestFromBedroomRequestsUseCase = removeRequestFromBedroomRequestsUseCase;
            this.setPotentialClientUseCase = setPotentialClientUseCase;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            if (modelClass.isAssignableFrom(RequestsViewModel.class)) {
                    return (T) new RequestsViewModel(application, fetchPotencialClientRequestUseCase, fetchBedroomRequestsClientsUseCase, removeRequestFromBedroomRequestsUseCase, setPotentialClientUseCase);
            }
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }
}
