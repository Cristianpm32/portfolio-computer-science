package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;


import com.google.gson.Gson;

import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.VerifyClientUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class VerificarPerfilFragmentViewModel extends AndroidViewModel{

    private final VerifyClientUseCase verifyClientUseCase;

    private final StateLiveData<Void> verifyClientState;

    private final ClientId clientId;

    private final CompositeDisposable compositeDisposable;


    public VerificarPerfilFragmentViewModel(Application application, VerifyClientUseCase verifyClientUseCase){
        super(application);
        this.verifyClientUseCase = verifyClientUseCase;

        verifyClientState = new StateLiveData<>();
        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("CLIENT_MODEL", null);
        this.clientId = new Gson().fromJson(json, ClientPO.class).getId();
        compositeDisposable = new CompositeDisposable();

    }

    public StateLiveData<Void> getVerifyClientState() {
        return verifyClientState;
    }

    public void verifyClient(){
        verifyClientState.postLoading();

        Disposable disposable = verifyClientUseCase.execute(clientId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        aVoid -> verifyClientState.postSuccess(null),
                        throwable -> verifyClientState.postError(throwable)
                );

        compositeDisposable.add(disposable);
    }

    public static class Factory extends ViewModelProvider.NewInstanceFactory {
        private final Application application;
        private final VerifyClientUseCase verifyClientUseCase;

        public Factory(Application application, VerifyClientUseCase verifyClientUseCase) {
            this.application = application;
            this.verifyClientUseCase = verifyClientUseCase;
        }

        @Override
        public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
            return (T) new VerificarPerfilFragmentViewModel(application, verifyClientUseCase);
        }
    }
}
