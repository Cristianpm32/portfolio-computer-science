package edu.ub.pis2324.studen.domain.usecases.implementations;

import java.util.List;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;

import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomsCatalogUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;

public class FetchBedroomsCatalogUseCaseImpl implements FetchBedroomsCatalogUseCase {

    private BedroomRepository bedroomRepository;
    private StudenThrowableMapper throwableMapper;

    public FetchBedroomsCatalogUseCaseImpl(BedroomRepository bedroomRepository) {

        this.bedroomRepository = bedroomRepository;
        this.throwableMapper = new StudenThrowableMapper();
        this.throwableMapper.add(BedroomRepository.Error.GETBYID_UNKNOWN_ERROR, FetchBedroomUseCase.Error.BEDROOMS_DATA_ACCESS_ERROR);
    }
    public @NonNull Observable<List<Bedroom>> execute() {
        return bedroomRepository.getAll()
          .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }
}
