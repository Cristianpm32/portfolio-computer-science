package edu.ub.pis2324.studen.domain.usecases.interfaces;

import java.util.List;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface FetchPopularBedroomsUseCase {

        Observable<List<Bedroom>> execute();

        enum Error implements StudenError {
            DATA_ACCESS_ERROR,
            BEDROOMS_DATA_ACCESS_ERROR;
        }

}
