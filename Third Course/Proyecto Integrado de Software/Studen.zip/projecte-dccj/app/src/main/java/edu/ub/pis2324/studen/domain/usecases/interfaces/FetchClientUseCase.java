package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import io.reactivex.rxjava3.core.Observable;

public interface FetchClientUseCase {
  Observable<Client> execute(ClientId clientId);

  enum Error implements StudenError {
    CLIENT_NOT_FOUND,
    CLIENTS_DATA_ACCESS_ERROR;
  }
}
