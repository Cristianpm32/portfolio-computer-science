package edu.ub.pis2324.studen.domain.usecases.interfaces;

import org.checkerframework.checker.units.qual.C;

import java.util.ArrayList;

import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface AddBedroomUseCase {
    Observable<BedroomId> execute(int squaredMeters, ArrayList<BedroomFeatures> features, String description, Address address,
                                ClientId clientId, BedroomType bedroomType);
    enum Error implements StudenError {
        GETVALIDBEDROOMID_UNKNOWN_ERROR,
        ADD_UNKNOWN_ERROR,
        SQUARED_METERS_EMPTY,
        DESCRIPTION_EMPTY,
        BEDROOMS_DATA_ACCESS_ERROR;
    }
}
