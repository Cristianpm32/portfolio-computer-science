package edu.ub.pis2324.studen.domain.model.valueobjects;

import java.io.Serializable;

import edu.ub.pis2324.studen.domain.model.valueobjects.Address;

public class Universitat implements Serializable {
    
    private String nom;
    private Address address;

    public Universitat(String nom, Address address) {
        this.nom = nom;
        this.address = address;
    }

    public Universitat() {
        this("", new Address());
    }

    public String getNom() {
        return nom;
    }

    public Address getAddress() {
        return address;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

}
