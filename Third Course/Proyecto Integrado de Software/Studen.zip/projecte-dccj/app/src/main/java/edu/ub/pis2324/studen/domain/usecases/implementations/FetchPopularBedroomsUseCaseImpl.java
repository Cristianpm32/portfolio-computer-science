package edu.ub.pis2324.studen.domain.usecases.implementations;

import java.util.List;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchPopularBedroomsUseCase;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchPopularBedroomsUseCaseImpl implements FetchPopularBedroomsUseCase {

    private BedroomRepository bedroomRepository;

    private StudenThrowableMapper throwableMapper;
    public FetchPopularBedroomsUseCaseImpl(BedroomRepository
                                     bedroomRepository) {

        this.bedroomRepository = bedroomRepository;
        this.throwableMapper = new StudenThrowableMapper();
        this.throwableMapper.add(BedroomRepository.Error.GETPOPULAR_UNKNOWN_ERROR, Error.BEDROOMS_DATA_ACCESS_ERROR);



    }

    @Override
    public Observable<List<Bedroom>> execute() {
        return bedroomRepository.getPopular().
                onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }


}
