package edu.ub.pis2324.studen.data.repositories.firestore;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.BedroomFirestoreDTO;
import edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore.mappers.DTOToDomainMapper;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import io.reactivex.rxjava3.core.Observable;

public class BedroomFirestoreRepository implements BedroomRepository {

    private static final String BEDROOMS_COLLECTION_NAME = "bedrooms";
    /* Attributes */
    private final FirebaseFirestore db;
    private final DTOToDomainMapper DTOToDomainMapper;

    /**
     * Empty constructor
     */
    public BedroomFirestoreRepository() {
        db = FirebaseFirestore.getInstance();
        DTOToDomainMapper = new DTOToDomainMapper();
    }

    @Override
    public Observable<List<Bedroom>> getAll() {
        return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME)
                    .get()
                    .addOnFailureListener(exception -> {
                        emitter.onError(new StudenThrowable(BedroomRepository.Error.GETALL_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(queryDocumentSnapshots ->{
                        List<Bedroom> bedrooms = new ArrayList<>();
                        for (DocumentSnapshot ds : queryDocumentSnapshots) {
                            BedroomFirestoreDTO bedroomDto = ds.toObject(BedroomFirestoreDTO.class);
                            Bedroom bedroom = DTOToDomainMapper.map(bedroomDto, Bedroom.class);
                            bedrooms.add(bedroom);
                        }
                        emitter.onNext(bedrooms);
                        emitter.onComplete();
                    });
        });
    }

    @Override
    public Observable<List<Bedroom>> getPopular() {
        return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME)
                    .get()
                    .addOnFailureListener(exception -> {
                        emitter.onError(new StudenThrowable(BedroomRepository.Error.GETPOPULAR_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(queryDocumentSnapshots ->{
                        List<Bedroom> bedrooms = new ArrayList<>();
                        for (DocumentSnapshot ds : queryDocumentSnapshots) {
                            BedroomFirestoreDTO bedroomDto = ds.toObject(BedroomFirestoreDTO.class);
                            Bedroom bedroom = DTOToDomainMapper.map(bedroomDto, Bedroom.class);
                            if(bedroom.isPopular()) {
                                bedrooms.add(bedroom);
                            }
                        }
                        emitter.onNext(bedrooms);
                        emitter.onComplete();
                    });
        });
    }

    public Observable<Request> getRequest(BedroomId bedroomId) {
        return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME)
                    .document(bedroomId.toString())
                    .get()
                    .addOnFailureListener(exception -> {
                        emitter.onError(new StudenThrowable(BedroomRepository.Error.GETREQUEST_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(ds -> {
                        if (!ds.exists()) {
                            emitter.onError(new StudenThrowable(BedroomRepository.Error.BEDROOM_NOT_FOUND));
                        } else {
                            BedroomFirestoreDTO bedroomDto = ds.toObject(BedroomFirestoreDTO.class);
                            Bedroom bedroom = DTOToDomainMapper.map(bedroomDto, Bedroom.class);
                            Request request = bedroom.getRequest(bedroom.getPotentialClient());
                            emitter.onNext(request);
                            emitter.onComplete();
                        }
                    });
        });
    }


    public Observable<List<Bedroom>> getByIds(List<BedroomId> ids) {
        /* UUIDs not supported by Firestore, so we need to convert them to strings */
        List<String> idsStr = ids
                .stream()
                .map(BedroomId::toString)
                .collect(Collectors.toList());

        return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME)
                    .whereIn(FieldPath.documentId(), idsStr) // idStr: converted UUIDs to Strings
                    .get()
                    .addOnFailureListener(exception -> {
                        emitter.onError(new StudenThrowable(Error.GETBYIDS_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        List<Bedroom> bedrooms = new ArrayList<>();
                        for (DocumentSnapshot ds : queryDocumentSnapshots.getDocuments()) {
                            if (ds.exists()) {
                                BedroomFirestoreDTO bedroomFirestoreDTO = ds.toObject(BedroomFirestoreDTO.class);
                                Bedroom bedroom = DTOToDomainMapper.map(bedroomFirestoreDTO, Bedroom.class);
                                bedrooms.add(bedroom);
                            }
                        }
                        emitter.onNext(bedrooms);
                        emitter.onComplete();
                    });
        });
    }

    /**
     * Add a bedroom to the Firebase CloudFirestore.
     *
     * @param bedroom The bedroom to add.
     * @return A Observable with true if the bedroom was added
     * or an error if it already exists.
     */
    public Observable<Boolean> add(Bedroom bedroom) {
        return Observable.create(emitter -> {
            BedroomFirestoreDTO bedroomDto = DTOToDomainMapper.map(bedroom, BedroomFirestoreDTO.class);

            db.collection(BEDROOMS_COLLECTION_NAME)
                    .document(bedroom.getId().toString())
                    .set(bedroomDto)
                    .addOnFailureListener(exception -> {
                        emitter.onError(new StudenThrowable(BedroomRepository.Error.ADD_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(ignored -> {
                        emitter.onNext(true);
                        emitter.onComplete();
                    });
        });
    }



    /**
     * Get a bedroom by id.
     *
     * @param id The bedroom id.
     * @return A Observable with the bedroom or null if it doesn't exist.
     */
    public Observable<Bedroom> getById(BedroomId id) {
        return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME)
                    .document(id.toString())
                    .get()
                    .addOnFailureListener(e -> {
                        emitter.onError(new StudenThrowable(BedroomRepository.Error.GETBYID_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(ds -> {
                        if (!ds.exists()) {
                            emitter.onError(new StudenThrowable(BedroomRepository.Error.BEDROOM_NOT_FOUND));
                        } else {
                            BedroomFirestoreDTO bedroomDto = ds.toObject(BedroomFirestoreDTO.class);
                            Bedroom bedroom = DTOToDomainMapper.map(bedroomDto, Bedroom.class);
                            emitter.onNext(bedroom);
                            emitter.onComplete();
                        }
                    });
        });
    }

    /**
     * Update a bedroom from the Firebase CloudFirestore.
     *
     * @param id The bedroom id.
     * @param onUpdateListener The updater to apply to the bedroom.
     * @return A Observable with true if the bedroom was removed
     * or an error if it doesn't exist.
     */
    public Observable<Boolean> update(BedroomId id, BedroomRepository.OnUpdateListener onUpdateListener) {
        return Observable.create(emitter -> {
            db.runTransaction(transaction -> {
                        try {
                            DocumentReference docRef = db
                                    .collection(BEDROOMS_COLLECTION_NAME)
                                    .document(id.toString());
                            DocumentSnapshot ds = transaction.get(docRef);
                            if (!ds.exists()) {
//              throw new NoSuchElementException("Document does not exist");
                                return false;
                            } else {
                                BedroomFirestoreDTO bedroomDto = ds.toObject(BedroomFirestoreDTO.class);
                                Bedroom bedroom = DTOToDomainMapper.map(bedroomDto, Bedroom.class);
                                onUpdateListener.update(bedroom);
                                bedroomDto = DTOToDomainMapper.map(bedroom, BedroomFirestoreDTO.class);
                                transaction.set(docRef, bedroomDto);
                                return true;
                            }
                        } catch (Throwable e) {
                            throw e;
                        }
                    })
                    .addOnFailureListener(e -> {
                        emitter.onError(new StudenThrowable(Error.UPDATE_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(success -> {
                        if (!success) {
                            emitter.onError(new StudenThrowable(BedroomRepository.Error.BEDROOM_NOT_FOUND));
                        } else {
                            emitter.onNext(success);
                            emitter.onComplete();
                        }
                    });
        });
    }

    /**
     * Remove a bedroom from the Firebase CloudFirestore.
     * @param id The bedroom id.
     * @return A Observable with true if the bedroom was removed
     *          or an error if it doesn't exist.
     */
    public Observable<Boolean> remove(BedroomId id) {
        return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME)
                    .document(id.toString())
                    .delete()
                    .addOnFailureListener(exception -> {
                        emitter.onError(new StudenThrowable(BedroomRepository.Error.REMOVE_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(ignored -> {
                        emitter.onNext(true);
                        emitter.onComplete();
                    });
        });
    }

    public Observable<List<Bedroom>> getByName(String name) {

           return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME).
                    orderBy("address.city", Query.Direction.ASCENDING)
                .startAt(name)
                .endAt(name + '\uf8ff')
                .get()
                .addOnFailureListener(exception -> {
                    emitter.onError(new StudenThrowable(BedroomRepository.Error.GETBYNAME_UNKNOWN_ERROR));
                })
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Bedroom> bedrooms = new ArrayList<>();
                    for (DocumentSnapshot ds : queryDocumentSnapshots) {
                        BedroomFirestoreDTO bedroomDto = ds.toObject(BedroomFirestoreDTO.class);
                        Bedroom bedroom = DTOToDomainMapper.map(bedroomDto, Bedroom.class);
                        bedrooms.add(bedroom);
                    }
                    emitter.onNext(bedrooms);
                    emitter.onComplete();
                });
        });
    }




    @Override
    public Observable<BedroomId> getValidBedroomId(String ciutat) {
        return Observable.create(emitter -> {
            db.collection(BEDROOMS_COLLECTION_NAME)
                    .whereEqualTo("address.city", ciutat)
                    .get()
                    .addOnFailureListener(exception -> {
                        emitter.onError(new StudenThrowable(BedroomRepository.Error.GETVALIDBEDROOMID_UNKNOWN_ERROR));
                    })
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        List<BedroomId> ids = new ArrayList<>();
                        int max = 0;
                        for (DocumentSnapshot ds : queryDocumentSnapshots) {
                            if (ds.exists()) {
                                int i = Integer.parseInt(ds.toObject(BedroomFirestoreDTO.class).getId().toString().replaceAll("[^0-9]", "")); // Obtenim els numeros
                                if(i > max) {
                                    max = i;
                                }
                            }
                        }
                        emitter.onNext(new BedroomId(ciutat + (max + 1)));
                        emitter.onComplete();
                    });
        });
    }
}
