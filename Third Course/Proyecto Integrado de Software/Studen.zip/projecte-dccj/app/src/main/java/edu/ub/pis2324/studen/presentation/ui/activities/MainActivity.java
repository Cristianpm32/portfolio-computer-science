package edu.ub.pis2324.studen.presentation.ui.activities;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import edu.ub.pis2324.studen.R;

import edu.ub.pis2324.studen.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    NavController navController;
    ActivityMainBinding binding;
    AppBarConfiguration appBarConfiguration;

    /*
    * Main activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);

        initNavigation();
    }

    private void initNavigation() {

        navController = ( (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment_main) )
                .getNavController();

        appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.homeFragment,
                R.id.requestsFragment,
                R.id.searchFragment,
                R.id.bedroomFragment,
                R.id.viewProfileFragment,
                R.id.viewRequestClientProfileFragment,
                R.id.signUpFragment
        ).build();

        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.bottomNavigationView, navController);


        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {

            setBottomNavigationViewVisibility(destination);
            setToolbarVisibility(destination);
        });

    }

    private void setBottomNavigationViewVisibility(NavDestination destination) {
        /* If the destination is the log in or sign up fragment, hide the bottom navigation view */
        if (destination.getId() == R.id.logInFragment || destination.getId() == R.id.signUpFragment || destination.getId() == R.id.viewOthersProfileFragment ||
                destination.getId() == R.id.viewDetailBedroomFragment || destination.getId() == R.id.editProfileFragment) {
            binding.bottomNavigationView.setVisibility(View.GONE);
        } else {
            binding.bottomNavigationView.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Set the visibility of the toolbar.
     * @param destination
     */
    private void setToolbarVisibility(NavDestination destination) {
        /* If the destination is the log in or sign up fragment, hide the top navigation view */
        if (destination.getId() == R.id.signUpFragment || destination.getId() == R.id.logInFragment) {
            binding.toolbar.setVisibility(View.GONE);
        } else {
            binding.toolbar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Handle the up navigation.
     * @return
     */
    @Override
    public boolean onSupportNavigateUp() {
        /* Enable the up navigation: the button shown in the left of the action bar */
        return NavigationUI.navigateUp(navController, appBarConfiguration) 
                || super.onSupportNavigateUp();
    }
}
