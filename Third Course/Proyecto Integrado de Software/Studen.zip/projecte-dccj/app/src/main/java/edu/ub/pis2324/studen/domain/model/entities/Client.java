package edu.ub.pis2324.studen.domain.model.entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Universitat;


/**
 * Domain entity holding the data and the behavior of a client.
 */
public class Client {
  /* Attributes */
  private ClientId id;
  private String nom;
  private String cognoms;
  private Universitat universitat;
  private int telefon;

  private String dataNaixement;

  // -1 no hi ha intent de verificació, 0 pendent de validació, 1 verificat
  private int verificat;
  private String email;
  private String password;
  private String photoUrl;
  private String description;
  private BedroomId bedroomId;
  private List<BedroomId> favoriteBedrooms;


  public Client(ClientId id, String nom, String cognoms, Universitat universitat, int telefon, String dataNaixement, int verificat, String email, String password, String photoUrl, String description, BedroomId bedroomId, List<BedroomId> favoriteBedrooms) {
    this.id = id;
    this.nom = nom;
    this.cognoms = cognoms;
    this.universitat = universitat;
    this.telefon = telefon;
    this.dataNaixement = dataNaixement;
    this.verificat = verificat;
    this.email = email;
    this.password = password;
    this.photoUrl = photoUrl;
    this.description = description;
    this.bedroomId = bedroomId;
    this.favoriteBedrooms = favoriteBedrooms;
  }

  public Client(ClientId id, String email, String password){
    this(id, "-", "-", new Universitat(), 0, "-", -1, email, password, "", "-", new BedroomId(""), new ArrayList<>());
  }

  @SuppressWarnings("unused")
  public Client(Client client) {
    this.id = client.id;
    this.nom = client.nom;
    this.cognoms = client.cognoms;
    this.universitat = client.universitat;
    this.telefon = client.telefon;
    this.dataNaixement = client.dataNaixement;
    this.verificat = client.verificat;
    this.email = client.email;
    this.password = client.password;
    this.photoUrl = client.photoUrl;
    this.description = client.description;
    this.bedroomId = client.bedroomId;
    this.favoriteBedrooms = client.favoriteBedrooms;
  }

  /**
   * Empty constructor.
   */
  @SuppressWarnings("unused")
  public Client() {
    this(new ClientId(), "", "", new Universitat(), 0, "", -1, "", "", "", "", new BedroomId(), new ArrayList<>());
  }

  /**
   * Gets the id of the client.
   * @return The id of the client.
   */
  public ClientId getId() {
    return id;
  }

  /**
   * Gets the username of the client.
   * @return The username of the client.
   */
  public String getEmail() {
    return email;
  }

  public void setEmail(String email){
    this.email = email;
  }

  /**
   * Gets the password of the client.
   * @return The password of the client.
   */
  public String getPassword() {
    return password;
  }

  public void setPassword(String password){
    this.password = password;
  }

  public String getPhotoUrl() {
    return photoUrl;
  }

  public void setPhotoUrl(String photoUrl){
    this.photoUrl = photoUrl;
  }

  public void setId(ClientId id) {
    this.id = id;
  }

  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  public String getCognoms() {
    return cognoms;
  }

  public void setCognoms(String cognoms) {
    this.cognoms = cognoms;
  }

  public Universitat getUniversitat() {
    return universitat;
  }

  public void setUniversitat(Universitat universitat) {
    this.universitat = universitat;
  }

  public int getTelefon() {
    return telefon;
  }

  public void setTelefon(int telefon) {
    this.telefon = telefon;
  }

  public String getDataNaixement() {
    return dataNaixement;
  }

  public void setDataNaixement(String dataNaixement) {
    this.dataNaixement = dataNaixement;
  }

  public int getVerificat() {
    return verificat;
  }

  public void setVerificat(int verificat) {
    this.verificat = verificat;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public BedroomId getBedroomId() {
    return bedroomId;
  }

  public void setBedroomId(BedroomId bedroomId) {
    this.bedroomId = bedroomId;
  }

  public List<BedroomId> getFavoriteBedrooms() {
    return favoriteBedrooms;
  }

  public void setFavoriteBedrooms(List<BedroomId> favoriteBedrooms) {
    this.favoriteBedrooms = favoriteBedrooms;
  }

  public void addFavoriteBedroom(BedroomId bedroomId){
    favoriteBedrooms.add(bedroomId);
  }

  public void removeFavoriteBedroom(BedroomId bedroomId){
    favoriteBedrooms.remove(bedroomId);
  }
  public boolean isFavoriteBedroom(BedroomId bedroomId){
    return favoriteBedrooms.contains(bedroomId);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
      return false;
    }
    Client client = (Client) obj;
    return id.equals(client.id);
  }
  
}
