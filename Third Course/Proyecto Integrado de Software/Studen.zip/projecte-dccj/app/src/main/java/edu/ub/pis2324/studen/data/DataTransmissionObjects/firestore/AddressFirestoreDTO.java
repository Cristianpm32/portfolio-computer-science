package edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore;

public class AddressFirestoreDTO {

    private String street;
    private String city;
    private String postalCode;
    private String country;

    public AddressFirestoreDTO() {

        this.street = "";
        this.city = "";
        this.postalCode = "";
        this.country = "";

    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getCountry() {
        return country;
    }
}
