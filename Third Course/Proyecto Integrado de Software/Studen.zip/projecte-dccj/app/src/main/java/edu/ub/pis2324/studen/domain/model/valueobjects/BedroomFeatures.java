package edu.ub.pis2324.studen.domain.model.valueobjects;

import java.io.Serializable;

public enum BedroomFeatures implements Serializable {
    BATHROOM,
    BALCONY,
    EXTERIOR,
    FURNISHED,
    KITCHEN,
    TERRACE
}
