package edu.ub.pis2324.studen.presentation.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.squareup.picasso.Picasso;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;

import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentViewProfileBinding;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.viewmodels.ViewClientProfileViewModel;
import edu.ub.pis2324.studen.utils.ImagePlacer;

public class ViewClientProfileFragment extends Fragment {

    private ViewClientProfileViewModel profileViewModel;

    /* View binding & navigation */
    private AppContainer appContainer;
    private NavController navController;
    private FragmentViewProfileBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentViewProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        initWidgetListeners();
        initViewModels();
    }

    private void initWidgetListeners() {
        binding.editProfileIcon.setOnClickListener(v -> {
            navController.navigate(R.id.action_viewProfileFragment_to_editProfileFragment2);
        });

        binding.btnVerify.setOnClickListener(v -> {
            navController.navigate(R.id.action_viewProfileFragment_to_verifyProfileFragment);
        });
    }

    private void initViewModels() {
        profileViewModel = new ViewModelProvider(this,
                new ViewClientProfileViewModel.Factory(
                        appContainer.fetchClientUseCase
                        , getActivity().getApplication())
        ).get(ViewClientProfileViewModel.class);

        initObservers();
    }

    private void initObservers() {
        profileViewModel.getClientState().observe(getViewLifecycleOwner(), clientState -> {
            switch (clientState.getStatus()) {
                case SUCCESS:
                    ClientPO clientPO = clientState.getData();
                    ImagePlacer.placeImage(clientPO.getPhotoUrl(), binding.ivProfileImage);
                    binding.tvProfileId.setText(clientPO.getId().toString());
                    binding.tvProfileEmail.setText(clientPO.getEmail());
                    if(clientPO.getDescription() != null){
                        binding.tvProfileDescription.setText(clientPO.getDescription());
                    }
                    if (clientPO.getNom() != null && clientPO.getCognoms() != null) {
                        binding.tvProfileName.setText(clientPO.getNom() + " " + clientPO.getCognoms());
                    }
                    if (clientPO.getUniversitat() != null) {
                        binding.tvProfileUniversity.setText(clientPO.getUniversitat().getNom());
                    }
                    if (clientPO.getTelefon() != 0) {
                        binding.tvProfilePhone.setText(String.valueOf(clientPO.getTelefon()));
                    }
                    if (clientPO.getDataNaixement() != null) {
                        binding.tvProfileBirthdate.setText(clientPO.getDataNaixement());
                    }
                    updateUI(clientPO);
                    break;
                case ERROR:
                    Toast.makeText(getContext(), clientState.getError().getMessage(), Toast.LENGTH_SHORT).show();
                    break;
            }
        });
    }

    private void updateUI(ClientPO clientPO){
        updateVerificationStatus(clientPO.getVerificat());
    }

    private void updateVerificationStatus(int isVerified){
        TextView tvVerifiedStatus = binding.tvVerifiedStatus;

        if(isVerified == 1){
            tvVerifiedStatus.setText(R.string.profile_verified);
            binding.btnVerify.setVisibility(View.GONE);
            tvVerifiedStatus.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_verified, 0, 0, 0);
        }
        else if (isVerified == 0) {
            tvVerifiedStatus.setText(R.string.profile_pending_verified);
            binding.btnVerify.setVisibility(View.GONE);
            tvVerifiedStatus.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_pending, 0, 0, 0);
        }
        else if (isVerified == -1) {
            tvVerifiedStatus.setText(R.string.profile_not_verified);
            tvVerifiedStatus.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_not_verified, 0, 0, 0);
        }
    }
}
