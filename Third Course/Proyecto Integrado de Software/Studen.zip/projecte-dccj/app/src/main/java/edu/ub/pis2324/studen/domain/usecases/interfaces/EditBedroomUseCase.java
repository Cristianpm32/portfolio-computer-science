package edu.ub.pis2324.studen.domain.usecases.interfaces;

import java.util.ArrayList;

import edu.ub.pis2324.studen.domain.model.valueobjects.Address;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomType;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface EditBedroomUseCase {

    Observable<Boolean> execute(
            BedroomId bedroomId,
            float squaredMeters,
            ArrayList<BedroomFeatures> features,
            String description, Address address,
            BedroomType bedroomType);

    enum Error implements StudenError {
        UPDATE_UNKNOWN_ERROR,
        SQUARED_METERS_ERROR,
        DESCRIPTION_ERROR,
        ADDRESS_FIELDS_ERROR,
        BEDROOMS_DATA_ACCESS_ERROR;
    }
}
