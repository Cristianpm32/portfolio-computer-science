package edu.ub.pis2324.studen.presentation.ui.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.RequestPO;
import edu.ub.pis2324.studen.utils.ImagePlacer;
import edu.ub.pis2324.studen.utils.Parella;

public class rvBedroomRequestAdapter extends RecyclerView.Adapter<rvBedroomRequestAdapter.BedroomRequestViewHolder>{
    private List<Parella<RequestPO, ClientPO>> requestPOList;
    private OnAcceptRequestClientListener onAcceptRequestClientListener;
    private OnClientRequestListener onClientRequestListener;
    private OnRemoveRequestClickListener onRemoveRequestClickListener;
    
    public interface OnClientRequestListener {
        void onClientRequest(ClientPO clientPO);
    }

    public interface OnAcceptRequestClientListener {
        void onAcceptRequestClick(RequestPO requestPO);
    }

    public interface OnRemoveRequestClickListener {
        void onRemoveRequestClick(RequestPO requestPO);
    }

    public rvBedroomRequestAdapter(OnRemoveRequestClickListener onRemoveRequestClickListener, OnClientRequestListener onClientRequestListener, OnAcceptRequestClientListener onAcceptRequestClientListener) {
        super();
        this.onAcceptRequestClientListener = onAcceptRequestClientListener;
        this.onRemoveRequestClickListener = onRemoveRequestClickListener;
        this.onClientRequestListener = onClientRequestListener;
    }
    
    @SuppressLint("NotifyDataSetChanged")
    public void setData(List<Parella<RequestPO, ClientPO>> requestPOList) {
        this.requestPOList = requestPOList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BedroomRequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rv_bedroom_request, parent, false);
        return new BedroomRequestViewHolder(view, position -> onRemoveRequestClickListener.onRemoveRequestClick(requestPOList.get(position).getFirst()), position -> onClientRequestListener.onClientRequest(requestPOList.get(position).getSecond()), position -> onAcceptRequestClientListener.onAcceptRequestClick(requestPOList.get(position).getFirst()));
    }

    @Override
    public void onBindViewHolder(@NonNull BedroomRequestViewHolder holder, int position) {
        // check if empty
        ClientPO clientPO = requestPOList.get(position).getSecond();
        holder.tvClientName.setText(clientPO.getNom()+" "+clientPO.getCognoms());
        if(clientPO.getUniversitat() != null) {
            holder.tvUniversitat.setText(clientPO.getUniversitat().getNom());
        }

        ImagePlacer.placeImage(clientPO.getPhotoUrl(), holder.ivRequestClientImage);
    }

    @Override
    public int getItemCount() {
        if(requestPOList == null) return 0;
        return requestPOList.size();
    }
    
    public void removeRequest(Integer data) {
        notifyItemRemoved(data);
    }

    public static class BedroomRequestViewHolder extends RecyclerView.ViewHolder {
        public TextView tvClientName;
        public TextView tvUniversitat;
        public ImageView ivRequestClientImage;
        public ImageView decline_request_icon;
        public ImageView accept_request_icon;

        public interface OnRemoveRequestClickListener {
            void onRemoveRequestClick(int position);
        }
        public interface OnClientRequestClickListener {
            void onClientRequestClick(int position);
        }
        public interface OnAcceptRequestClickListener {
            void onAcceptRequestClick(int position);
        }
        public BedroomRequestViewHolder(@NonNull View itemView, OnRemoveRequestClickListener onRemoveRequestClickListener, OnClientRequestClickListener onClientRequestClickListener, OnAcceptRequestClickListener onAcceptRequestClickListener) {
            super(itemView);
            tvClientName = itemView.findViewById(R.id.tvClientName);
            tvUniversitat = itemView.findViewById(R.id.tvUniversitat);
            ivRequestClientImage = itemView.findViewById(R.id.ivRequestClientImage);
            decline_request_icon = itemView.findViewById(R.id.decline_request_icon);
            accept_request_icon = itemView.findViewById(R.id.accept_request_icon);
            accept_request_icon.setOnClickListener(v -> onAcceptRequestClickListener.onAcceptRequestClick(getAdapterPosition()));
            decline_request_icon.setOnClickListener(v -> onRemoveRequestClickListener.onRemoveRequestClick(getAdapterPosition()));
            ivRequestClientImage.setOnClickListener(v -> onClientRequestClickListener.onClientRequestClick(getAdapterPosition()));
        }
    }
}
