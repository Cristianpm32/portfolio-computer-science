package edu.ub.pis2324.studen.domain.usecases.interfaces;



import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface AddBedroomToClientFavoritesUseCase {


    Observable<Client> execute(ClientId clientId,
                               BedroomId bedroomId);


    enum Error implements StudenError{
        CLIENT_NOT_FOUND,
        BEDROOM_NOT_FOUND,
        BEDROOMS_DATA_ACCESS_ERROR,
        UPDATE_UNKNOWN_ERROR;
    }
}
