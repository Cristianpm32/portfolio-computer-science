package edu.ub.pis2324.studen.utils.error_handling;

public interface StudenError {
    // Interfície que implementen tots els enumeradors d'errors de les diferents abstraccions
    // * L'única raó de ser és la d'habilitar el polimorfisme entre els diferents tipus d'errors
}
