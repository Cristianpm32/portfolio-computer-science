package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Universitat;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface EditProfileUseCase {
    Observable<Boolean> execute(
            ClientId clientId,
            String nom,
            String cognoms,
            String birthDate,
            String email,
            int telefon,
            String description,
            String universitat);

    enum Error implements StudenError {
        EMAIL_EMPTY,
        UPDATE_UNKNOWN_ERROR,
        CLIENT_NOT_FOUND,
        CLIENTS_DATA_ACCESS_ERROR;
    }
}
