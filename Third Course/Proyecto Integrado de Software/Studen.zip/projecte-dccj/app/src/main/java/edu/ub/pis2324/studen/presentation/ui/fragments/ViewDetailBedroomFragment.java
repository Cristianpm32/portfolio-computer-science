package edu.ub.pis2324.studen.presentation.ui.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentViewDetailBedroomBinding;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.RequestPO;
import edu.ub.pis2324.studen.presentation.viewmodels.ViewDetailBedroomViewModel;
import edu.ub.pis2324.studen.utils.ImagePlacer;


public class ViewDetailBedroomFragment extends Fragment {

    private ViewDetailBedroomViewModel viewDetailBedroomViewModel;
    private AppContainer appContainer;
    private NavController navController;
    private FragmentViewDetailBedroomBinding binding;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentViewDetailBedroomBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        /* Get bedroom model from arguments */
        BedroomPO bedroomPO = getArguments().getParcelable("BEDROOM");
        assert bedroomPO != null;

        /* Initializations */
        initViewModel(bedroomPO);
        initWidgetListeners();
    }

    private void navigateToViewOthersProfileFragment(ClientPO clientPO) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("CLIENT", clientPO);
        navController.navigate(R.id.action_viewDetailBedroomFragment_to_viewOthersProfileFragment, bundle);
    }

    private void initWidgetListeners() {

        // Configurem les features de la bedroom
        binding.profileImage.setOnClickListener(v -> {
            viewDetailBedroomViewModel.getClientPO().observe(getViewLifecycleOwner(), clientPOState -> {
                switch (clientPOState.getStatus()) {
                    case LOADING:
                        break;
                    case SUCCESS:
                        navigateToViewOthersProfileFragment(clientPOState.getData());
                        break;
                    case ERROR:
                        Toast.makeText(getContext(), clientPOState.getError().getMessage(), Toast.LENGTH_SHORT).show();
                        break;
                }
            });
        });

        if(viewDetailBedroomViewModel.isBedroomInClientFavorite()) {
            binding.favButton.setImageResource(R.drawable.fav_fill);
        }
        else{
            binding.favButton.setImageResource(R.drawable.baseline_heart);
        }
        if(viewDetailBedroomViewModel.isRequestInBedroomRequests()){
            binding.botoPeticio.setText("Cancel·lar la petició");
        }
        else{
            binding.botoPeticio.setText("Fer una petició");
        }

        binding.favButton.setOnClickListener(v -> {
            if(viewDetailBedroomViewModel.isBedroomInClientFavorite()) {
                binding.favButton.setImageResource(R.drawable.baseline_heart);
                viewDetailBedroomViewModel.removeBedroomFromClientFavorite();
            }
            else{
                viewDetailBedroomViewModel.addBedroomToClientFavorite();
                binding.favButton.setImageResource(R.drawable.fav_fill);
            }});

        binding.botoPeticio.setOnClickListener(v -> {
            if(viewDetailBedroomViewModel.isRequestInBedroomRequests()){
                binding.botoPeticio.setText("Fer una petició");
                viewDetailBedroomViewModel.removeRequestFromBedroomRequests();
                Toast.makeText(getContext(), "S'ha cancel·lat la petició", Toast.LENGTH_SHORT).show();
            }
            else{
                viewDetailBedroomViewModel.addRequestToBedroomRequests();
                binding.botoPeticio.setText("Cancel·lar la petició");
                Toast.makeText(getContext(), "S'ha enviat la petició", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initViewModel(BedroomPO bedroomPO) {
        viewDetailBedroomViewModel = new ViewModelProvider(this, new ViewDetailBedroomViewModel.Factory(
            getActivity().getApplication(),
            bedroomPO,
            appContainer.fetchClientUseCase,
            appContainer.addBedroomToClientFavoritesUseCase,
            appContainer.removeBedroomFromClientFavoritesUseCase,
            appContainer.addRequestToBedroomRequestsUseCase,
            appContainer.removeRequestFromBedroomRequestsUseCase
        )).get(ViewDetailBedroomViewModel.class);

        initObservers();
    }

    private void initObservers() {

        viewDetailBedroomViewModel.getClientPO().observe(getViewLifecycleOwner(), clientPOState -> {
            switch (clientPOState.getStatus()) {
                case LOADING:
                    break;
                case SUCCESS:
                    ImagePlacer.placeImage(clientPOState.getData().getPhotoUrl(), binding.profileImage);
                    break;
                case ERROR:
                    Toast.makeText(getContext(), clientPOState.getError().getMessage(), Toast.LENGTH_SHORT).show();
                    break;
            }
        });

        viewDetailBedroomViewModel.getBedroomPOState().observe(getViewLifecycleOwner(), bedroomPO -> {
            binding.DescripcioApartament.setText(bedroomPO.getData().getDescription());
            binding.textAdreca.setText(bedroomPO.getData().getAddress().toString());
            binding.TextPrincipal.setText("Habitació a " + bedroomPO.getData().getAddress().getCity());
            ImagePlacer.placeImage(bedroomPO.getData().getMainPhotoUrl(), binding.ivmainPhotoBedroom);
        });

        viewDetailBedroomViewModel.getBedroomPOState().observe(getViewLifecycleOwner(), bedroomPO -> {

            binding.SquaredM.setText(bedroomPO.getData().getSize() + " sq. m");
            // Configurem les features de la bedroom
            ArrayList<BedroomFeatures> features = bedroomPO.getData().getFeatures();
            for (BedroomFeatures feature : features) {
                switch (feature) {
                    case KITCHEN:
                        binding.Kitchen.setVisibility(View.VISIBLE);
                        binding.kitchenIV.setVisibility(View.VISIBLE);
                        break;

                    case TERRACE:
                        binding.Terrace.setVisibility(View.VISIBLE);
                        binding.terraceIV.setVisibility(View.VISIBLE);
                        break;

                    case BALCONY:
                        binding.Balcony.setVisibility(View.VISIBLE);
                        binding.balconyIV.setVisibility(View.VISIBLE);
                        break;

                    case BATHROOM:
                        binding.Bathroom.setVisibility(View.VISIBLE);
                        binding.bathroomIV.setVisibility(View.VISIBLE);
                        break;

                    case EXTERIOR:
                        binding.Exterior.setVisibility(View.VISIBLE);
                        binding.exteriorIV.setVisibility(View.VISIBLE);
                        break;

                    case FURNISHED:
                        binding.Furnished.setVisibility(View.VISIBLE);
                        binding.furnishedIV.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });
    }
}