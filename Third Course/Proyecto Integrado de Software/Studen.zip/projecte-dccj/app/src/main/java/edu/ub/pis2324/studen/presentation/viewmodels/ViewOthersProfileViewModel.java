package edu.ub.pis2324.studen.presentation.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;

public class ViewOthersProfileViewModel extends AndroidViewModel {

    private DomainToPOMapper domainToPOMapper;
    private final FetchBedroomUseCase fetchBedroomUseCase;
    private BedroomPO bedroomPO;
    private final MutableLiveData<ClientPO> clientPOState;
    private final StateLiveData<BedroomPO> bedroomPOState;
    private final ClientPO clientPO;
    private CompositeDisposable compositeDisposable;

    /* Constructor */
    public ViewOthersProfileViewModel(Application application, FetchBedroomUseCase fetchBedroomUseCase, ClientPO clientPO) {
        super(application);
        this.fetchBedroomUseCase = fetchBedroomUseCase;
        this.clientPO = clientPO;
        domainToPOMapper = DomainToPOMapper.getInstance();
        clientPOState = new MutableLiveData<>(this.clientPO);
        bedroomPOState = new StateLiveData<>();
        compositeDisposable = new CompositeDisposable();
        fetchBedroom();
    }

    public MutableLiveData<ClientPO> getPOClientState() {
        return clientPOState;
    }

    private void fetchBedroom() {
        bedroomPOState.postLoading();
        Observable<Bedroom> bedroomObservable = fetchBedroomUseCase.execute(clientPO.getBedroomId());
        Disposable disposable = bedroomObservable.subscribeOn(io.reactivex.rxjava3.android.schedulers.AndroidSchedulers.mainThread())
                .subscribe(bedroom -> {
                    bedroomPO = domainToPOMapper.map(bedroom, BedroomPO.class);
                    bedroomPOState.postSuccess(bedroomPO);
                }, throwable -> bedroomPOState.postError(throwable));
        compositeDisposable.add(disposable);
    }

    public StateLiveData<BedroomPO> getBedroomPO () {
        return bedroomPOState;
    }

    public static class Factory extends ViewModelProvider.NewInstanceFactory {

        private final Application application;
        private final ClientPO clientPO;
        private final FetchBedroomUseCase fetchBedroomUseCase;

        public Factory(Application application, FetchBedroomUseCase fetchBedroomUseCase, ClientPO clientPO) {
            this.application = application;
            this.fetchBedroomUseCase = fetchBedroomUseCase;
            this.clientPO = clientPO;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new ViewOthersProfileViewModel(application, fetchBedroomUseCase, clientPO);
        }
    }
}
