package edu.ub.pis2324.studen.presentation.ui.fragments;

import android.app.Application;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentHomeBinding;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.ui.adapters.rvGenericBedroomAdapter;
import edu.ub.pis2324.studen.presentation.viewmodels.HomeViewModel;

public class HomeFragment extends Fragment {

    private static final String RECYCLER_POPULAR_VIEW_STATE = "RECYCLER_POPULAR_VIEW_STATE";
    private static final String RECYCLER_FAVORITE_VIEW_STATE = "RECYCLER_FAVORITE_VIEW_STATE";
    private HomeViewModel homeViewModel;

    private rvGenericBedroomAdapter rvPopularBedroomAdapter;
    private RecyclerView.LayoutManager rvPopularLayoutManager;
    private rvGenericBedroomAdapter rvFavoriteBedroomAdapter;
    private RecyclerView.LayoutManager rvFavoriteLayoutManager;

    private Parcelable rvPopularStateParcelable;
    private Parcelable rvFavoriteStateParcelable;

    private FragmentHomeBinding binding;

    private MyApplication application;
    private AppContainer appContainer;

    private NavController navController;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        application = (MyApplication) getActivity().getApplication();
        appContainer = application.getAppContainer();
        navController = Navigation.findNavController(view);

        /* Initializations */
        initViewModel();
        initWidgetListeners();
        initRecyclerView();

    }

    @Override
    public void onResume() {
        super.onResume();
        if (rvPopularStateParcelable != null) {
            rvPopularLayoutManager.onRestoreInstanceState(rvPopularStateParcelable);
        }
        if(rvFavoriteStateParcelable != null) {
            rvFavoriteLayoutManager.onRestoreInstanceState(rvFavoriteStateParcelable);
        }
    }

    /**
     * Lifecycle method called when the activity is being paused.
     * @param state the bundle to save the state of the activity
     */
    @Override
    public void onSaveInstanceState(@NonNull Bundle state) {
        super.onSaveInstanceState(state);
        rvFavoriteStateParcelable = rvFavoriteLayoutManager.onSaveInstanceState();
        state.putParcelable(RECYCLER_FAVORITE_VIEW_STATE, rvFavoriteStateParcelable);
        rvPopularStateParcelable = rvPopularLayoutManager.onSaveInstanceState();
        state.putParcelable(RECYCLER_POPULAR_VIEW_STATE, rvPopularStateParcelable);
    }

    private void initWidgetListeners() {

        binding.btnPublicarApartament.setOnClickListener(v -> {
            navController.navigate(R.id.action_homeFragment_to_addBedroomTypeAdressFragment);
        });


        binding.btnCercarApartament.setOnClickListener(v -> {
            navController.navigate(R.id.action_homeFragment_to_searchFragment);
        });



        binding.logOutButton.setOnClickListener(v -> {
            SharedPreferences preferences = application.getSharedPreferences("LOGIN", application.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.clear();
            editor.apply();
            navController.navigate(R.id.action_homeFragment_to_logInFragment);

        });

    }
    private void initRecyclerView() {
        rvPopularLayoutManager = new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false);
        rvFavoriteLayoutManager = new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false);
        binding.rvPopularBedrooms.setLayoutManager(rvPopularLayoutManager);
        binding.rvFavoriteBedrooms.setLayoutManager(rvFavoriteLayoutManager);

        initRecyclerViewAdapter();

    }

    private void initRecyclerViewAdapter() {
        rvFavoriteBedroomAdapter = new rvGenericBedroomAdapter(
                bedroomPO -> navigateToBedroomDetail(bedroomPO)
        );
        rvPopularBedroomAdapter = new rvGenericBedroomAdapter(
                bedroomPO -> navigateToBedroomDetail(bedroomPO)
        );

        binding.rvPopularBedrooms.setAdapter(rvPopularBedroomAdapter);
        binding.rvFavoriteBedrooms.setAdapter(rvFavoriteBedroomAdapter);

    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void navigateToBedroomDetail(BedroomPO bedroomPO) {

        Bundle bundle = new Bundle();
        bundle.putParcelable("BEDROOM", bedroomPO);
        navController.navigate(R.id.action_homeFragment_to_bedroomDetailFragment, bundle);
    }

    private void initViewModel() {
        /* Init viewmodel */
        homeViewModel = new ViewModelProvider(
                this,
                new HomeViewModel.Factory(application, appContainer.fetchPopularBedroomsUseCase, appContainer.fetchClientFavoriteBedroomsUseCase, appContainer.fetchClientUseCase)
        ).get(HomeViewModel.class);


        initObservers();

    }

    private void initObservers() {
        
        homeViewModel.getClientState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    assert state.getData() != null;
                    BedroomId bedroomId = state.getData().getBedroomId();
                    if (bedroomId != null) {
                        String bedroomIdString = bedroomId.getId();
                        if (bedroomIdString != null && !bedroomIdString.isEmpty()) {
                            binding.btnPublicarApartament.setVisibility(View.GONE);
                        }
                    }
                    break;
                default:
                    break;
            }
        });
        

        homeViewModel.getPopularBedroomListState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    assert state.getData() != null;
                    showNoProductsAvailable(state.getData().isEmpty());
                    rvPopularBedroomAdapter.setData(state.getData());
                    break;
                case ERROR:
                    showNoProductsAvailable(true);
                    break;
                default:
                    break;
            }
        });

        homeViewModel.getFavoriteBedroomListState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    assert state.getData() != null;
                    showNoProductsAvailable(state.getData().isEmpty());
                    rvFavoriteBedroomAdapter.setData(state.getData());
                    break;
                case ERROR:
                    showNoProductsAvailable(true);
                    break;
                default:
                    break;
            }
        });


     homeViewModel.getHiddenBedroomState().observe(getViewLifecycleOwner(), position -> {
        switch (position.getStatus()) {
            case SUCCESS:
                assert position.getData() != null;
                rvPopularBedroomAdapter.removeBedroom(position.getData());
                rvFavoriteBedroomAdapter.removeBedroom(position.getData());
                break;
            default:
                break;
        }
    });
}

    /**
     * Shows or hides the "No products available" message.
     * @param mustShow true if the message must be shown, false otherwise
     */
    private void showNoProductsAvailable(boolean mustShow) {
        if(mustShow) {
            System.out.println("No bedrooms available");
        }
    }
    
}
