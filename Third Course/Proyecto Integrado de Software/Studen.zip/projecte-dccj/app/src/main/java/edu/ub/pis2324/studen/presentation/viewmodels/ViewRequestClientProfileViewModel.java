package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.RemovePotentialClientUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.RequestPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;

public class ViewRequestClientProfileViewModel extends ViewModel {

    private DomainToPOMapper domainToPOMapper;
    private FetchBedroomUseCase fetchBedroomUseCase;

    private RemovePotentialClientUseCase removePotentialClientUseCase;
    private FetchClientUseCase fetchClientUseCase;
    private StateLiveData<ClientPO> clientState;
    private StateLiveData<BedroomPO> bedroomState;
    private StateLiveData<Boolean> removePotentialClientState;
    private RequestPO requestPO;

    private ClientPO currentClient;
    private CompositeDisposable compositeDisposable;


    public ViewRequestClientProfileViewModel(Application application, FetchClientUseCase fetchClientUseCase, FetchBedroomUseCase fetchBedroomUseCase, RemovePotentialClientUseCase removePotentialClientUseCase, RequestPO requestPO) {

        clientState = new StateLiveData<>();
        bedroomState = new StateLiveData<>();
        removePotentialClientState = new StateLiveData<>();
        this.fetchClientUseCase = fetchClientUseCase;
        this.fetchBedroomUseCase = fetchBedroomUseCase;
        this.removePotentialClientUseCase = removePotentialClientUseCase;
        domainToPOMapper = DomainToPOMapper.getInstance();
        compositeDisposable = new CompositeDisposable();

        this.requestPO = requestPO;

        SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
        String json = preferences.getString("CLIENT_MODEL", null);
        currentClient = new Gson().fromJson(json, ClientPO.class);
        fetchPotentialClient();
    }


    public StateLiveData<ClientPO> getClientState() {
        return clientState;
    }

    public StateLiveData<BedroomPO> getBedroomState() {
        return bedroomState;
    }
    public StateLiveData<Boolean> getRemovePotentialClientState() {
        eliminarPotentialClient();
        return removePotentialClientState;
    }


    private void fetchPotentialClient() {
        clientState.postLoading();
        compositeDisposable.add(fetchClientUseCase.execute(requestPO.getNomClient())
                .subscribe(client -> {
                    clientState.postSuccess(domainToPOMapper.map(client, ClientPO.class));
                    fetchBedroom(client.getBedroomId());
                }, throwable -> clientState.postError(throwable)));
    }

    private void fetchBedroom(BedroomId bedroomId) {
        bedroomState.postLoading();
        compositeDisposable.add(fetchBedroomUseCase.execute(bedroomId)
                .subscribe(bedroom -> bedroomState.postSuccess(domainToPOMapper.map(bedroom, BedroomPO.class)),
                        throwable -> bedroomState.postError(throwable)));
    }

    public void eliminarPotentialClient() {
        removePotentialClientState.postLoading();

        Disposable disposable = removePotentialClientUseCase.execute(currentClient.getBedroomId())
                .subscribe(bedroom -> removePotentialClientState.postSuccess(true),
                        throwable -> removePotentialClientState.postError(throwable));

        compositeDisposable.add(disposable);
    }


    public static class Factory extends ViewModelProvider.NewInstanceFactory {

        private final Application application;
        private final FetchClientUseCase fetchClientUseCase;
        private final FetchBedroomUseCase fetchBedroomUseCase;
        private final RemovePotentialClientUseCase removePotentialClientUseCase;

        private final RequestPO requestPO;

        public Factory(Application application, FetchClientUseCase fetchClientUseCase, FetchBedroomUseCase fetchBedroomUseCase, RemovePotentialClientUseCase removePotentialClientUseCase, RequestPO requestPO) {
            this.application = application;
            this.fetchClientUseCase = fetchClientUseCase;
            this.fetchBedroomUseCase = fetchBedroomUseCase;
            this.removePotentialClientUseCase = removePotentialClientUseCase;
            this.requestPO = requestPO;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new ViewRequestClientProfileViewModel(application, fetchClientUseCase, fetchBedroomUseCase, removePotentialClientUseCase, requestPO);
        }
    }
}
