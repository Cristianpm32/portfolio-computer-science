package edu.ub.pis2324.studen.domain.model.valueobjects;

import java.io.Serializable;

public enum BedroomType implements Serializable {
    BEDROOM,
    APARTMENT,
    HOUSE,
}
