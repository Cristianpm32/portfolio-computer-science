package edu.ub.pis2324.studen.presentation.ui.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.gson.Gson;

import java.util.ArrayList;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentAddBedroomFeaturesBinding;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomFeatures;
import edu.ub.pis2324.studen.presentation.viewmodels.AddBedroomFeaturesViewModel;

/** @noinspection ALL*/
public class AddBedroomFeaturesFragment extends Fragment {

    private AddBedroomFeaturesViewModel addBedroomFeaturesViewModel;
    /* View binding & navigation */
    private AppContainer appContainer;
    private NavController navController;
    private FragmentAddBedroomFeaturesBinding binding;

    // View Control
    boolean balconyClicked;
    boolean terraceClicked;
    boolean bathroomClicked;
    boolean kitchenClicked;
    boolean exteriorClicked;
    boolean furnishedClicked;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentAddBedroomFeaturesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        initConfig();
        initViewModels();
    }

    private void initConfig() {

        binding.btnFinishABF.setBackgroundResource(R.drawable.button_shape_gray);
        binding.btnFinishABF.setText("Omple els camps de text");
        binding.btnFinishABF.setEnabled(false);

        balconyClicked = false;
        terraceClicked = false;
        bathroomClicked = false;
        kitchenClicked = false;
        exteriorClicked = false;
        furnishedClicked = false;

        // Inicialitzem els botons amb l'aparença de no clicats
        binding.btnBalcony.setBackgroundResource(R.drawable.button_border);
        binding.btnTerrace.setBackgroundResource(R.drawable.button_border);
        binding.btnBathroom.setBackgroundResource(R.drawable.button_border);
        binding.btnKitchen.setBackgroundResource(R.drawable.button_border);
        binding.btnExterior.setBackgroundResource(R.drawable.button_border);
        binding.btnFurnished.setBackgroundResource(R.drawable.button_border);

        initWidgetListeners();
    }

    private void initWidgetListeners() {

        binding.btnBackABF.setOnClickListener(ignoredView -> navController.navigateUp());

        binding.btnBalcony.setOnClickListener(ignoredView -> {
            if (!balconyClicked) {
                binding.btnBalcony.setBackgroundResource(R.drawable.button_border_pressed);
                balconyClicked = true;
            } else {
                binding.btnBalcony.setBackgroundResource(R.drawable.button_border);
                balconyClicked = false;
            }
        });

        binding.btnTerrace.setOnClickListener(ignoredView -> {
            if (!terraceClicked) {
                binding.btnTerrace.setBackgroundResource(R.drawable.button_border_pressed);
                terraceClicked = true;
            } else {
                binding.btnTerrace.setBackgroundResource(R.drawable.button_border);
                terraceClicked = false;
            }
        });

        binding.btnBathroom.setOnClickListener(ignoredView -> {
            if (!bathroomClicked) {
                binding.btnBathroom.setBackgroundResource(R.drawable.button_border_pressed);
                bathroomClicked = true;
            } else {
                binding.btnBathroom.setBackgroundResource(R.drawable.button_border);
                bathroomClicked = false;
            }
        });

        binding.btnKitchen.setOnClickListener(ignoredView -> {
            if (!kitchenClicked) {
                binding.btnKitchen.setBackgroundResource(R.drawable.button_border_pressed);
                kitchenClicked = true;
            } else {
                binding.btnKitchen.setBackgroundResource(R.drawable.button_border);
                kitchenClicked = false;
            }
        });

        binding.btnExterior.setOnClickListener(ignoredView -> {
            if (!exteriorClicked) {
                binding.btnExterior.setBackgroundResource(R.drawable.button_border_pressed);
                exteriorClicked = true;
            } else {
                binding.btnExterior.setBackgroundResource(R.drawable.button_border);
                exteriorClicked = false;
            }
        });

        binding.btnFurnished.setOnClickListener(ignoredView -> {
            if (!furnishedClicked) {
                binding.btnFurnished.setBackgroundResource(R.drawable.button_border_pressed);
                furnishedClicked = true;
            } else {
                binding.btnFurnished.setBackgroundResource(R.drawable.button_border);
                furnishedClicked = false;
            }
        });

        binding.btnFinishABF.setOnClickListener(ignoredView -> {
            int squaredMeters = Integer.parseInt(String.valueOf(binding.etSquaredMetersABF.getText()));
            ArrayList<BedroomFeatures> features = gatherFeatures();
            String description = String.valueOf(binding.etDescriptionABF.getText());
            addBedroomFeaturesViewModel.addBedroom(squaredMeters, features, description);
        });

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override
            public void afterTextChanged(Editable s) {
                checkFinalitzar();
            }
        };

        binding.etSquaredMetersABF.addTextChangedListener(textWatcher);
        binding.etDescriptionABF.addTextChangedListener(textWatcher);
    }

    private ArrayList<BedroomFeatures> gatherFeatures() {
        ArrayList<BedroomFeatures> features = new ArrayList<>();

        if (balconyClicked) features.add(BedroomFeatures.BALCONY);

        if (terraceClicked) features.add(BedroomFeatures.TERRACE);

        if (bathroomClicked) features.add(BedroomFeatures.BATHROOM);

        if (kitchenClicked) features.add(BedroomFeatures.KITCHEN);

        if (exteriorClicked) features.add(BedroomFeatures.EXTERIOR);

        if (furnishedClicked) features.add(BedroomFeatures.FURNISHED);

        return features;
    }

    private void initViewModels() {
        addBedroomFeaturesViewModel = new ViewModelProvider(this,
                new AddBedroomFeaturesViewModel.Factory(
                        getActivity().getApplication(), appContainer.addBedroomUseCase)
        ).get(AddBedroomFeaturesViewModel.class);

        initObservers();
    }

    private void initObservers() {
        addBedroomFeaturesViewModel.getAddingState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE).edit();
                    String JsonString = new Gson().toJson(state.getData());
                    editor.putString("BEDROOM_ID", JsonString);
                    editor.commit();
                    System.out.println(state.getData());
                    Toast.makeText(getContext(), "Habitatge afegit correctament", Toast.LENGTH_SHORT).show();
                    navController.navigate(R.id.action_addBedroomFeaturesFragment_to_homeFragment);
                    break;
                case COMPLETE:
                    break;
                case ERROR:
                    Toast.makeText(getActivity(), state.getError().getMessage(), Toast.LENGTH_SHORT).show();
                    break;
            }
        });
    }

    void checkFinalitzar() {
        boolean textSquaredMeters = binding.etSquaredMetersABF.getText().length() > 0;
        boolean textDescription = binding.etDescriptionABF.getText().length() > 0;

        if (textSquaredMeters && textDescription) {
            binding.btnFinishABF.setBackgroundResource(R.drawable.button_shape_black);
            binding.btnFinishABF.setText("Publicar");
            binding.btnFinishABF.setEnabled(true);
        } else {
            binding.btnFinishABF.setBackgroundResource(R.drawable.button_shape_gray);
            binding.btnFinishABF.setText("Omple els camps de text");
            binding.btnFinishABF.setEnabled(false);
        }
    }
}