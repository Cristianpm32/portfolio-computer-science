
package edu.ub.pis2324.studen.domain.dependency_inversion_repositories;

public interface AbstractRepositoryFactory {
  ClientRepository createClientRepository();
  BedroomRepository createBedroomRepository();
}
