package edu.ub.pis2324.studen.presentation.ui.fragments;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentRequestsBinding;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.RequestPO;
import edu.ub.pis2324.studen.presentation.ui.adapters.rvBedroomRequestAdapter;
import edu.ub.pis2324.studen.presentation.viewmodels.RequestsViewModel;

public class RequestsFragment extends Fragment {
    
    private static final String RECYCLER_REQUESTS_VIEW_STATE = "RECYCLER_REQUESTS_VIEW_STATE";
    private RequestsViewModel requestsViewModel;

    private rvBedroomRequestAdapter rvBedroomRequestAdapter;
    private RecyclerView.LayoutManager rvBedroomRequestLayoutManager;

    private Parcelable rvBedroomRequestStateParcelable;

    private FragmentRequestsBinding binding;
    private MyApplication application;
    private AppContainer appContainer;

    private NavController navController;
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate an initial layout (e.g., a loading screen)
        binding = FragmentRequestsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        application = (MyApplication) getActivity().getApplication();
        appContainer = application.getAppContainer();

        initViewModel();
        initRecyclerView();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (rvBedroomRequestStateParcelable != null) {
            rvBedroomRequestLayoutManager.onRestoreInstanceState(rvBedroomRequestStateParcelable);
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle state) {
        super.onSaveInstanceState(state);
        rvBedroomRequestStateParcelable = rvBedroomRequestLayoutManager.onSaveInstanceState();
        state.putParcelable(RECYCLER_REQUESTS_VIEW_STATE, rvBedroomRequestStateParcelable);

    }


    private void initRecyclerView() {
        rvBedroomRequestLayoutManager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        binding.rvBedroomRequests.setLayoutManager(rvBedroomRequestLayoutManager);
        initRecyclerViewAdapter();

    }

    private void initRecyclerViewAdapter() {
        rvBedroomRequestAdapter = new rvBedroomRequestAdapter(requestPO -> requestsViewModel.removeRequestFromBedroomRequests(requestPO)
                , clientPO -> navigateToRequestClient(clientPO), requestPO -> potentialClientHandler(requestPO));
        binding.rvBedroomRequests.setAdapter(rvBedroomRequestAdapter);

    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void potentialClientHandler(RequestPO requestPO) {
        requestsViewModel.setPotentialClient(requestPO);
        Bundle bundle = new Bundle();
        bundle.putParcelable("REQUEST", requestPO);
        navController.navigate(R.id.action_requestsFragment_to_RequestClientProfileFragment, bundle);
    }

    private void navigateToRequestClient(ClientPO clientPO) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("CLIENT", clientPO);
        navController.navigate(R.id.action_requestsFragment_to_viewOthersProfileFragment, bundle);
    }


    private void initViewModel() {
        /* Init viewmodel */
        requestsViewModel = new ViewModelProvider(
                this,
                new RequestsViewModel.Factory(application, appContainer.fetchPotencialClientRequestUseCase, appContainer.fetchBedroomRequestsClientsUseCase, appContainer.removeRequestFromBedroomRequestsUseCase, appContainer.setPotentialClientUseCase)
        ).get(RequestsViewModel.class);
        initObservers();
    }

    private void initObservers() {
        
        requestsViewModel.getPotentialClientPOState().observe(getViewLifecycleOwner(), potentialClientRequestPOState -> {
            switch (potentialClientRequestPOState.getStatus()) {
                case SUCCESS:

                    Bundle bundle = new Bundle();
                    bundle.putParcelable("REQUEST", potentialClientRequestPOState.getData());
                    navController.navigate(R.id.action_requestsFragment_to_RequestClientProfileFragment, bundle);
                    break;
                case ERROR:
                    break;
            }
        });

        requestsViewModel.getBedroomRequestsClientsListState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    assert state.getData() != null;
                    showNoBedroomAvailable(state.getData().isEmpty(), true);
                    rvBedroomRequestAdapter.setData(state.getData());
                    break;
                case ERROR:
                    showNoBedroomAvailable(true, false);
                    break;
                default:
                    break;
            }
        });


        requestsViewModel.getHiddenRequestState().observe(getViewLifecycleOwner(), position -> {
            switch (position.getStatus()) {
                case SUCCESS:
                    assert position.getData() != null;
                    rvBedroomRequestAdapter.removeRequest(position.getData());
                    break;
                default:
                    break;
            }
        });
    }

    /**
     * Shows or hides the "No products available" message.
     *
     * @param mustShow true if the message must be shown, false otherwise
     */
    private void showNoBedroomAvailable(boolean mustShow, boolean bedroom) {

        if (mustShow) {
            if (bedroom) {
                binding.clNoRequestsAvailable.setVisibility(View.VISIBLE);
                // No requests available
            } else {
                binding.clNoBedroomAvailable.setVisibility(View.VISIBLE);
                // No bedroom available
            }
        }
    }
}
