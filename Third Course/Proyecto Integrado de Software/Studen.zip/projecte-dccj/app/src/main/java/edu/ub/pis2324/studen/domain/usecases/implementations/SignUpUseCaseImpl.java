package edu.ub.pis2324.studen.domain.usecases.implementations;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;
import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.services.CheckClientExistsService;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SignUpUseCase;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

/**
 * Implementation of the log-in use case (EXERCICI 3)
 */
public class SignUpUseCaseImpl implements SignUpUseCase {
    /* Attributes */
    private CheckClientExistsService checkClientExistsService; // Re-usage of use cases
    private ClientRepository clientRepository;
    private StudenThrowableMapper throwableMapper;

    /**
     * Creates a log-in use case.
     */
    public SignUpUseCaseImpl(
            CheckClientExistsService checkClientExistsService,
            ClientRepository clientRepository
    ) {
        this.checkClientExistsService = checkClientExistsService;
        this.clientRepository = clientRepository;

        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(ClientRepository.Error.ADD_UNKNOWN_ERROR, Error.CLIENTS_DATA_ACCESS_ERROR);
    }

    /**
     * Executes the log-in use case.
     *
     * @return
     */
    @Override
    public Observable<Boolean> execute(
            ClientId clientId,
            String email,
            String password,
            String passwordConfirmation) {
        return checkEmailNotEmpty(clientId)
                .concatMap(ignored -> checkPasswordNotEmpty(password))
                .concatMap(ignored -> checkPasswordConfirmationNotEmpty(passwordConfirmation))
                .concatMap(ignored -> checkPasswordAndConfirmationMatch(password, passwordConfirmation))
                .concatMap(ignored -> checkClientExistsService.execute(clientId))
                .concatMap(clientExists -> {
                    if (clientExists) {
                        return Observable.error(new StudenThrowable(Error.CLIENT_ALREADY_EXISTS));
                    } else {
                        Client client = new Client(clientId, email, password);
                        return clientRepository.add(client);
                    }
                })
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }

    private Observable<Boolean> checkEmailNotEmpty(ClientId clientId) {
        return clientId.getId().isEmpty()
                ? Observable.error(new StudenThrowable(Error.EMAIL_EMPTY))
                : Observable.just(true);
    }

    private Observable<Boolean> checkPasswordNotEmpty(String password) {
        return password.isEmpty()
                ? Observable.error(new StudenThrowable(Error.PASSWORD_EMPTY))
                : Observable.just(true);
    }

    private Observable<Boolean> checkPasswordConfirmationNotEmpty(String passwordConfirmation) {
        return passwordConfirmation.isEmpty()
                ? Observable.error(new StudenThrowable(Error.PASSWORD_CONFIRMATION_EMPTY))
                : Observable.just(true);
    }

    private Observable<Boolean> checkPasswordAndConfirmationMatch(
            String password,
            String passwordConfirmation
    ) {
        return !password.equals(passwordConfirmation)
                ? Observable.error(new StudenThrowable(Error.PASSWORD_AND_CONFIRMATION_MISMATCH))
                : Observable.just(true);
    }
}
