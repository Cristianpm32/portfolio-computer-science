package edu.ub.pis2324.studen.data.repositories.firestore;

import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.AbstractRepositoryFactory;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.BedroomRepository;
import edu.ub.pis2324.studen.domain.dependency_inversion_repositories.ClientRepository;

public class FirestoreRepositoryFactory implements AbstractRepositoryFactory {
  @Override
  public ClientRepository createClientRepository() {
    return new ClientFirestoreRepository();
  }
  public BedroomRepository createBedroomRepository() { return new BedroomFirestoreRepository(); }

}
