package edu.ub.pis2324.studen.presentation.ui.fragments;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.SearchView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import edu.ub.pis2324.studen.AppContainer;
import edu.ub.pis2324.studen.MyApplication;
import edu.ub.pis2324.studen.R;
import edu.ub.pis2324.studen.databinding.FragmentSearchBinding;
import edu.ub.pis2324.studen.presentation.PresentationObjects.BedroomPO;
import edu.ub.pis2324.studen.presentation.ui.adapters.rvSearchBedroomAdapter;
import edu.ub.pis2324.studen.presentation.viewmodels.SearchViewModel;

public class SearchFragment extends Fragment {

    private static final String RECYCLER_SEARCH_VIEW_STATE = "RECYCLER_SEARCH_VIEW_STATE";
    private SearchViewModel searchViewModel;

    private AppContainer appContainer;
    private FragmentSearchBinding binding;
    private rvSearchBedroomAdapter rvSearchAdapter;
    private Parcelable rvSearchStateParcelable;
    private RecyclerView.LayoutManager layoutManager;
    private SearchView searchView;
    private NavController navController;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentSearchBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appContainer = ((MyApplication) getActivity().getApplication()).getAppContainer();
        navController = Navigation.findNavController(view);

        /* Initializations */
        initWidgetListeners();
        initRecyclerView();
        initViewModel();


    }

    /**
     * This method is called when the fragment is resumed.
     */
    public void onResume() {
        super.onResume();
        if (rvSearchStateParcelable != null) {
            layoutManager.onRestoreInstanceState(rvSearchStateParcelable);
        }
    }

    /**
     * Lifecycle method called when the activity is being paused.
     * @param state the bundle to save the state of the activity
     */
    public void onSaveInstanceState(@NonNull Bundle state) {
        super.onSaveInstanceState(state);
        rvSearchStateParcelable = layoutManager.onSaveInstanceState();
        state.putParcelable(RECYCLER_SEARCH_VIEW_STATE, rvSearchStateParcelable);
    }

    private void initWidgetListeners(){
        getActivity().addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                menuInflater.inflate(R.menu.search_menu, menu);
                MenuItem menuItem = menu.findItem(R.id.searchView);
                searchView = (SearchView) menuItem.getActionView();
                searchView.setQueryHint(getString(R.string.search_hint));
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        binding.clIniciSearch.setVisibility(View.GONE);
                        searchViewModel.fetchBedroomsByName(newText);
                        return true;
                    }
                });
            }

            @Override
            public boolean onMenuItemSelected(MenuItem item) {
                if (item.getItemId() == R.id.searchView) {
                    return true;
                }
                return false;
            }
        }, getViewLifecycleOwner(), Lifecycle.State.RESUMED);
    }


    /**
     * Initializes the RecyclerView and its adapter
     */
    private void initRecyclerView() {
        layoutManager = new LinearLayoutManager(getContext());
        binding.rvSearchedBedrooms.setLayoutManager(layoutManager);
        initRecyclerViewAdapter();
    }

    /**
     * Initializes the RecyclerView adapter which will be used to display the bedrooms
     */
    private void initRecyclerViewAdapter() {
        rvSearchAdapter = new rvSearchBedroomAdapter(bedroomPO ->{
                navigateToBedroomDetail(bedroomPO);}
        );
        binding.rvSearchedBedrooms.setAdapter(rvSearchAdapter);
    }

    /**
     * Navigates to the BedroomDetailFragment
     * @param bedroomPO The bedroom to be displayed
     */
    private void navigateToBedroomDetail(BedroomPO bedroomPO) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("BEDROOM", bedroomPO);
        navController.navigate(R.id.action_searchFragment_to_bedroomDetailFragment, bundle);
    }

    /**
     * Initializes the ViewModel
     */
    private void initViewModel() {
        /* Init viewmodel */
        searchViewModel = new ViewModelProvider(
                this,
                new SearchViewModel.Factory(
                        appContainer.fetchBedroomsByNameUseCase,
                        appContainer.fetchBedroomsCatalogUseCase
                )
        ).get(SearchViewModel.class);

        /* Initialize the observers */
        initObservers();


        searchViewModel.fetchBedroomsCatalog();
    }


    /**
     * FORMAL METHOD
     * This method is called when the device configuration changes.
     * @param newConfig The new device configuration.
     */
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }


    void initObservers() {
        searchViewModel.getBedroomClientListState().observe(getViewLifecycleOwner(), state -> {
            switch (state.getStatus()) {
                case SUCCESS:
                    assert state.getData() != null;
                    if(!state.getData().isEmpty()){
                        binding.clIniciSearch.setVisibility(android.view.View.GONE);
                    }
                    if(state.getData().isEmpty()) binding.clNoProductsAvailable.setVisibility(android.view.View.VISIBLE);
                    else binding.clNoProductsAvailable.setVisibility(android.view.View.GONE);
                    rvSearchAdapter.setData(state.getData());
                    break;

                case ERROR:
                    showNoProductsAvailable(true);
                    break;
                default:
                    break;
            }
        });

        searchViewModel.getHiddenBedroomState().observe(getViewLifecycleOwner(), position -> {
            switch (position.getStatus()) {
                case SUCCESS:
                    assert position.getData() != null;
                    rvSearchAdapter.removeBedroom(position.getData());
                    break;
                default:
                    break;
            }
        });
    }


    /**
     * Shows a message indicating that there are no products available
     *
     * @param show true if the message should be shown, false otherwise
     */
    private void showNoProductsAvailable(boolean show) {

        if (layoutManager.getItemCount() == 0) {
            binding.clNoProductsAvailable.setVisibility(
                    show ? android.view.View.VISIBLE : android.view.View.GONE
            );
        }

            if (binding.clNoProductsAvailable.getVisibility() != android.view.View.VISIBLE && show) {
                if(layoutManager.getItemCount() == 0) {
                    binding.clIniciSearch.setVisibility(android.view.View.VISIBLE);
                }
            } else {
                binding.clIniciSearch.setVisibility(android.view.View.GONE);
            }

    }
}
