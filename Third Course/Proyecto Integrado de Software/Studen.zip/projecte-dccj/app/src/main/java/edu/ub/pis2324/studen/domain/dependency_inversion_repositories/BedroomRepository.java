package edu.ub.pis2324.studen.domain.dependency_inversion_repositories;

import java.util.List;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface BedroomRepository {

    Observable<List<Bedroom>> getAll();
    Observable<List<Bedroom>> getPopular();
    Observable<List<Bedroom>> getByIds(List<BedroomId> favoriteBedrooms);
    Observable<List<Bedroom>> getByName(String name);
    //Observable<List<Bedroom>> getByPrice(int maxPrice, int minPrice);
    interface OnUpdateListener {
        void update(Bedroom bedroom);
    }

    Observable<Boolean> add(Bedroom bedroom);
    Observable<Bedroom> getById(BedroomId id);
    Observable<Boolean> update(BedroomId id, BedroomRepository.OnUpdateListener onUpdateListener);
    Observable<Boolean> remove(BedroomId id);
    Observable<BedroomId> getValidBedroomId(String ciutat);
    Observable<Request> getRequest(BedroomId bedroomId);

    enum Error implements StudenError {
        BEDROOM_NOT_FOUND, // Produït per getById, update o remove
        ADD_UNKNOWN_ERROR, // Produït per add
        GETBYID_UNKNOWN_ERROR, // Produït per getById
        GETBYIDS_UNKNOWN_ERROR, // Produït per getByIds
        UPDATE_UNKNOWN_ERROR, // Produït per update
        REMOVE_UNKNOWN_ERROR, // Produït per getById
        BEDROOMS_DATA_ACCESS_ERROR, // Produït per getAll
        GETBYNAME_UNKNOWN_ERROR, // Produït per getByName
        GETALL_UNKNOWN_ERROR, // Produït per getAll
        GETPOPULAR_UNKNOWN_ERROR, // Produït per getPopular
        GETREQUEST_UNKNOWN_ERROR, // Produït per getRequest
        GETVALIDBEDROOMID_UNKNOWN_ERROR; // Produït per getValidBedroomId

    }
}
