package edu.ub.pis2324.studen.presentation.viewmodels;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.LogInUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class LogInViewModel extends ViewModel {
  
  /* Attributes */
  private final LogInUseCase logInUseCase;
  /* LiveData */
  private final StateLiveData<ClientPO> logInState;
  /* RxJava */
  private final CompositeDisposable compositeDisposable;

  private final DomainToPOMapper domainToPOMapper;

  /* Constructor */
  public LogInViewModel(LogInUseCase logInUseCase) {
    this.logInUseCase = logInUseCase;
    logInState = new StateLiveData<ClientPO>();
    compositeDisposable = new CompositeDisposable();
    domainToPOMapper = new DomainToPOMapper();
  }

  /**
   * Parent class (ViewModel's) lifecycle-related method
   * that is invoked when the activity is purposedly destroyed.
   */
  @Override
  public void onCleared() {
    compositeDisposable.dispose();
  }

  /**
   * Returns the state of the log-in
   * @return the state of the log-in
   */
  public StateLiveData<ClientPO> getLogInState() {
    return logInState;
  }

  /**
   * Logs in the user
   * @param username the username
   * @param password the password
   */
  public void login(String username, String password) {
    logInState.postLoading();

    ClientId clientId = new ClientId(username);

    /* Invoca cas d'ús */
    Disposable d = logInUseCase.execute(clientId, password)
      .subscribeOn(Schedulers.io())
      .observeOn(AndroidSchedulers.mainThread())
      .subscribe(
        // Transformem les dades a PO per a poder-les enviar a la vista
        client -> logInState.postSuccess(domainToPOMapper.map(client, ClientPO.class)),  // Si no hi ha error, s'executa aquesta funció
        throwable -> logInState.postError(throwable) // Sinó hi ha error, s'executa aquesta
      );

    compositeDisposable.add(d);
  }


  public static class Factory extends ViewModelProvider.NewInstanceFactory {
    private final LogInUseCase logInUseCase;

    public Factory(LogInUseCase logInUseCase) {
      this.logInUseCase = logInUseCase;
    }

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
      return (T) new LogInViewModel(logInUseCase);
    }
  }
}
