package edu.ub.pis2324.studen.domain.usecases.interfaces;

import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import io.reactivex.rxjava3.core.Observable;

public interface SignUpUseCase {
    Observable<Boolean> execute(
            ClientId clientId,
            String email,
            String password,
            String passwordConfirmation);

    enum Error implements StudenError {
        EMAIL_EMPTY,
        PASSWORD_EMPTY,
        PASSWORD_CONFIRMATION_EMPTY,
        PASSWORD_AND_CONFIRMATION_MISMATCH,
        CLIENT_ALREADY_EXISTS,
        CLIENTS_DATA_ACCESS_ERROR;
    }
}
