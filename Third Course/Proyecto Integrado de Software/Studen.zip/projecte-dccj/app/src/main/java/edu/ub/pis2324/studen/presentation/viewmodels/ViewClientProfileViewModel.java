package edu.ub.pis2324.studen.presentation.viewmodels;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.gson.Gson;

import edu.ub.pis2324.studen.domain.model.valueobjects.ClientId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.SignUpUseCase;
import edu.ub.pis2324.studen.presentation.PresentationObjects.ClientPO;
import edu.ub.pis2324.studen.presentation.PresentationObjects.mappers.DomainToPOMapper;
import edu.ub.pis2324.studen.utils.error_handling.StudenError;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.livedata.StateLiveData;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class ViewClientProfileViewModel extends ViewModel {

    private final FetchClientUseCase fetchClientUseCase;
    private StateLiveData<ClientPO> clientState;
    private CompositeDisposable compositeDisposable;
    private ClientId clientId;

    /* Constructor */
    public ViewClientProfileViewModel(FetchClientUseCase fetchClientUseCase, Application application) {
        this.fetchClientUseCase = fetchClientUseCase;
        clientState = new StateLiveData<>();
        compositeDisposable = new CompositeDisposable();
        try {
            SharedPreferences preferences = application.getSharedPreferences("LOGIN", MODE_PRIVATE);
            String json = preferences.getString("CLIENT_MODEL", null);
            clientId = new Gson().fromJson(json, ClientPO.class).getId();
            trobarClient();
        } catch (Exception e) {
            clientState.postError(e);
        }
    }

    private void trobarClient() {
        Disposable d = fetchClientUseCase.execute(clientId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        client -> {
                            clientState.postSuccess(DomainToPOMapper.getInstance().map(client, ClientPO.class));
                        },
                        throwable -> handleError(throwable)
                );

        compositeDisposable.add(d);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        compositeDisposable.dispose();
    }

    public StateLiveData<ClientPO> getClientState() {
        return clientState;
    }

    private void handleError(Throwable throwable) {
        if (throwable instanceof StudenThrowable)
            handleStudenError((StudenThrowable) throwable);
        else
            clientState.postError(new Throwable("Unknown error"));
    }

    private void handleStudenError(StudenThrowable studenThrowable) {
        String message;
        StudenError sError = studenThrowable.getError();
        if (sError == FetchClientUseCase.Error.CLIENT_NOT_FOUND) {
            message = "Client not found";
        } else if (sError == FetchClientUseCase.Error.CLIENTS_DATA_ACCESS_ERROR) {
            message = "Clients' data access error";
        } else {
            message = "Unknown error";
        }

        clientState.postError(new Throwable(message));
    }

    public static class Factory extends ViewModelProvider.NewInstanceFactory {

        private final FetchClientUseCase fetchClientUseCase;
        private final Application application;

        public Factory(FetchClientUseCase fetchClientUseCase, Application application) {
            this.fetchClientUseCase = fetchClientUseCase;
            this.application = application;
        }
        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new ViewClientProfileViewModel(fetchClientUseCase, application);
        }
    }
}
