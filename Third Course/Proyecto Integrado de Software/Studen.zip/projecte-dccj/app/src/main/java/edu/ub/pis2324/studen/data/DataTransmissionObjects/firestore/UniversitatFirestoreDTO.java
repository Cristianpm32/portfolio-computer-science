package edu.ub.pis2324.studen.data.DataTransmissionObjects.firestore;

public class UniversitatFirestoreDTO {

    private String nom;
    private AddressFirestoreDTO address;
    
    @SuppressWarnings("unused")
    public UniversitatFirestoreDTO() {
        this.nom = "";
        this.address = new AddressFirestoreDTO();
    }
    
    public UniversitatFirestoreDTO(String nom, AddressFirestoreDTO address) {
        this.nom = nom;
        this.address = address;
    }

    public String getNom() {
        return nom;
    }

    public AddressFirestoreDTO getAddress() {
        return address;
    }
}
