package edu.ub.pis2324.studen.domain.usecases.implementations;

import java.util.List;

import edu.ub.pis2324.studen.domain.model.entities.Bedroom;
import edu.ub.pis2324.studen.domain.model.entities.Client;
import edu.ub.pis2324.studen.domain.model.valueobjects.Request;
import edu.ub.pis2324.studen.domain.model.valueobjects.BedroomId;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomRequestsClientsUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchBedroomUseCase;
import edu.ub.pis2324.studen.domain.usecases.interfaces.FetchClientUseCase;
import edu.ub.pis2324.studen.utils.Parella;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowable;
import edu.ub.pis2324.studen.utils.error_handling.StudenThrowableMapper;
import io.reactivex.rxjava3.core.Observable;

public class FetchBedroomRequestsClientsUseCaseImpl implements FetchBedroomRequestsClientsUseCase {
    FetchBedroomUseCase fetchBedroomUseCase;
    FetchClientUseCase fetchClientUseCase;

    StudenThrowableMapper throwableMapper;

    public FetchBedroomRequestsClientsUseCaseImpl(FetchBedroomUseCase fetchBedroomUseCase, FetchClientUseCase fetchClientUseCase) {
        this.fetchBedroomUseCase = fetchBedroomUseCase;
        this.fetchClientUseCase = fetchClientUseCase;
        throwableMapper = new StudenThrowableMapper();
        throwableMapper.add(FetchBedroomUseCase.Error.BEDROOM_NOT_FOUND, Error.BEDROOM_NOT_FOUND);
        throwableMapper.add(FetchBedroomUseCase.Error.BEDROOMS_DATA_ACCESS_ERROR, Error.BEDROOM_DATA_ACCESS_ERROR);


    }


    // Hem creat una estructura de dades auxiliar "parella", per tal de poder encadenar Requests i
    // clients en un sol observable i així poder treballar amb asincronia de manera més còmoda.
    // El que fem és obtenir les peticions d'una habitació i per cada petició obtenir el client corresponent.
    // Tractem l'encadenament amb l'operació fromIterable, que ens permet iterar sobre una llista i
    // per cada element de la llista obtenir un nou observable.
    @Override
    public Observable<List<Parella<Request, Client>>> execute(BedroomId bedroomId) {
        return fetchBedroomUseCase.execute(bedroomId).
                concatMap(bedroom -> getBedroomRequests(bedroom))
                .onErrorResumeNext(throwable -> Observable.error(throwableMapper.map(throwable)));
    }

    private Observable<List<Parella<Request, Client>>> getBedroomRequests(Bedroom bedroom) {
        return Observable.fromIterable(bedroom.getRequests())
                .concatMap(request -> fetchClientUseCase.execute(request.getNomClient())
                        .map(client -> new Parella<>(request, client)))
                .toList()
                .toObservable();
    }
}
