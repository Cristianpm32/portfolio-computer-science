#include <ESP8266WiFi.h>
#include <PubSubClient.h>

// --- Constants ---
const char* WIFI_SSID = "e.Telecom_2XDX";
const char* WIFI_PASSWORD = "*********";

const char* MQTT_BROKER_HOST = "192.168.1.114"; 
const int   MQTT_BROKER_PORT = 1883;
// Actualitzem el tòpic segons la teva petició
const char* MQTT_TOPIC = "board/led";
const char* MQTT_CLIENT_ID = "ESP8266_Client_LED";

// Rangs per al número aleatori
#define MIN 20
#define MAX 35

// Variables per al temporitzador (substitut del delay)
unsigned long lastMsgTime = 0;
const long interval = 5000; // 5000ms = 5 segons

WiFiClient wifi_client;
PubSubClient client(wifi_client);

void reconnect() {
  while (!client.connected()) {
    Serial.print("Connectant a MQTT...");
    if (client.connect(MQTT_CLIENT_ID)) {
      Serial.println("connectat!");
      client.subscribe(MQTT_TOPIC); // Ens subscrivim a 'board/led'
    } else {
      Serial.print("error, rc=");
      Serial.print(client.state());
      Serial.println(" reintentant en 5 segons");
      delay(5000);
    }
  }
}


void setup() {
  Serial.begin(115200);
  
  delay(10);
  randomSeed(micros()); // Inicialitzar la llavor aleatòria perquè els números variïn

  Serial.println();
  Serial.print("Connectant WiFi a ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connectat");
  Serial.println(WiFi.localIP());

  client.setServer(MQTT_BROKER_HOST, MQTT_BROKER_PORT);
}

void loop() {
  // 1. Assegurar connexió
  if (!client.connected()) {
    reconnect();
  }
  client.loop(); // IMPORTANT: Això manté l'MQTT viu

  // 2. Temporitzador no bloquejant (cada 5 segons)
  unsigned long now = millis();
  if (now - lastMsgTime > interval) {
    lastMsgTime = now; // Actualitzem el temps

    // Generar dada simulada
    int r = random(MIN, MAX);

    // Convertir int a String i després a char array (c_str)
    // Aquesta és la forma correcta de fer-ho:
    String payload = String(r); 
    
    Serial.print("Publicant al tòpic ");
    Serial.print(MQTT_TOPIC);
    Serial.print(": ");
    Serial.println(payload);

    // Enviar missatge
    client.publish(MQTT_TOPIC, payload.c_str());
  }

}