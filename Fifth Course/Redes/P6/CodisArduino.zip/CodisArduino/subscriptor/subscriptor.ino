#include <ESP8266WiFi.h>
#include <PubSubClient.h>

// --- Constants Definition ---
const char* WIFI_SSID = "McDonalds";
const char* WIFI_PASSWORD = "******* ";

// Defines must be strings (in quotes)
const char* MQTT_BROKER_HOST = "172.20.10.12"; 
const int   MQTT_BROKER_PORT = 1883;
const char* MQTT_SUBSCRIBE_TOPIC = "test/topic";
const char* MQTT_CLIENT_ID = "ESP8266_Client_008"; // ID must be a string

WiFiClient wifi_client;
PubSubClient client(wifi_client);

// Callback function for when a message arrives
void OnMessageReceived(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]);
  }
  Serial.println();
}

// Function to connect and reconnect to MQTT
void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    
    // Attempt to connect using the Client ID
    if (client.connect(MQTT_CLIENT_ID)) {
      Serial.println("connected");
      // Once connected, resubscribe
      client.subscribe(MQTT_SUBSCRIBE_TOPIC);
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(10);

  // Connect to WiFi
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());

  // Setup MQTT
  client.setServer(MQTT_BROKER_HOST, MQTT_BROKER_PORT);
  client.setCallback(OnMessageReceived);
}

void loop() {
  // If MQTT is not connected, run the reconnect function
  if (!client.connected()) {
    reconnect();
  }
  // This must be called regularly to process incoming messages and maintain the connection
  client.loop();
}
