#include <ESP8266WiFi.h>
#include <PubSubClient.h>

// --- Constants ---
const char* WIFI_SSID = "e.Telecom_2XDX";
const char* WIFI_PASSWORD = "*******";

const char* MQTT_BROKER_HOST = "192.168.1.114"; 
const int   MQTT_BROKER_PORT = 1883;
// Actualitzem el tòpic segons la teva petició
const char* MQTT_SUBSCRIBE_TOPIC = "board/led";
const char* MQTT_CLIENT_ID = "ESP8266_Client_LED";

WiFiClient wifi_client;
PubSubClient client(wifi_client);

// Funció que s'executa quan arriba un missatge
void OnMessageReceived(char* topic, byte* payload, unsigned int length) {
  Serial.print("Rebut al tòpic [");
  Serial.print(topic);
  Serial.print("]: ");

  // 1. Convertir el payload (bytes) a un String o char array per poder llegir-lo com a número
  char messageBuffer[length + 1];
  memcpy(messageBuffer, payload, length);
  messageBuffer[length] = '\0'; // Afegim el caràcter nul final per tancar l'string

  String message = String(messageBuffer);
  Serial.println(message);

  // 2. Convertir l'String a un número enter (int)
  int valorRebut = message.toInt(); 

  // 3. Aplicar la lògica: Encendre si és < 28
  if (valorRebut < 28) {
    Serial.println("Valor < 28. ENCENENT LED.");
    digitalWrite(BUILTIN_LED, LOW); // LOW encén el LED a l'ESP8266
  } else {
    Serial.println("Valor >= 28. APAGANT LED.");
    digitalWrite(BUILTIN_LED, HIGH); // HIGH apaga el LED a l'ESP8266
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Connectant a MQTT...");
    if (client.connect(MQTT_CLIENT_ID)) {
      Serial.println("connectat!");
      client.subscribe(MQTT_SUBSCRIBE_TOPIC); // Ens subscrivim a 'board/led'
    } else {
      Serial.print("error, rc=");
      Serial.print(client.state());
      Serial.println(" reintentant en 5 segons");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  // --- CONFIGURACIÓ LED ---
  pinMode(BUILTIN_LED, OUTPUT);     // Inicialitzem el pin del LED
  digitalWrite(BUILTIN_LED, HIGH);  // Assegurem que comenci apagat (HIGH = OFF)
  // ------------------------

  delay(10);
  Serial.println();
  Serial.print("Connectant WiFi a ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connectat");
  Serial.println(WiFi.localIP());

  client.setServer(MQTT_BROKER_HOST, MQTT_BROKER_PORT);
  client.setCallback(OnMessageReceived);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
}