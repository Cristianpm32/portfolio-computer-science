package prog2.model;

import java.io.Serializable;

public class Article implements Serializable {
    private String id;
    private String nom;
    private float preu;
    private int temps;
    private boolean urgent;

    public Article(String id, String nom, float preu, int temps, boolean urgent) {
        this.id = id;
        this.nom = nom;
        this.preu = preu;
        this.temps = temps;
        this.urgent = urgent;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public float getPreu() {
        return preu;
    }

    public void setPreu(float preu) {
        this.preu = preu;
    }

    public int getTemps() {
        return temps;
    }

    public void setTemps(int temps) {
        this.temps = temps;
    }

    public boolean isUrgent() {
        return urgent;
    }

    public void setUrgent(boolean urgent) {
        this.urgent = urgent;
    }

    public boolean equals(Object externo) {
        String myId = this.getId();
        String externoId = ((Article) externo).getId();
        return myId.equals(externoId);
    }

    public String toString() {
        String informacio = "Id = " + getId() + ", Nom = " + getNom() + ", Preu = " + getPreu()
                + ", Temps fins enviament = " + temps +
                ", Enviament Urgent = " + isUrgent();
        return informacio;
    }
}