package prog2.model;

import java.io.Serializable;
import java.util.Date;

public abstract class Comanda implements Serializable {
    protected Article article;
    protected Client client;
    protected int quantitat;
    protected Date data;

    public Comanda(Article article, Client client, int quantitat) {
        this.article = article;
        this.client = client;
        this.quantitat = quantitat;
        data = new Date();
    }

    public Article getArticle() {
        return article;
    }

    public void setArticle(Article article) {
        this.article = article;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public int getQuantitat() {
        return quantitat;
    }

    public void setQuantitat(int quantitat) {
        this.quantitat = quantitat;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public float calcPreu() {
        return article.getPreu() * quantitat;
    }

    public abstract String tipusComanda();

    public abstract boolean comandaEnviada();

    public abstract boolean comandaRebuda();

    public abstract float preuEnviament();

    public String toString() {
        String informacio = ", Article = " + article.getNom() + ", Client = " + client.getNom() + ", Data de creacio = "
                + getData();
        return informacio;
    }
}
