package prog2.model;

public class ClientEstandard extends Client {
    private String tipus = "Estandard";

    public ClientEstandard(String correu, String nom, String adreca) {
        super(correu, nom, adreca);
    }

    public String tipusClient() {
        return tipus;
    }

    public float calcMensual() {
        return 0;
    }

    public float descompteEnv() {
        return 0;
    }

    public String toString() {
        String informacio = "Tipus = " + tipusClient() + super.toString() + ", Descompte Enviament = " + descompteEnv()
                +
                ", Mensualitat = " + calcMensual();
        return informacio;
    }
}
