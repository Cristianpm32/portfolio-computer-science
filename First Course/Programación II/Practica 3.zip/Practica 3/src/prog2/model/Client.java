package prog2.model;

import java.io.Serializable;

public abstract class Client implements Serializable {
    protected String correu;
    protected String nom;
    protected String adreca;

    public Client(String correu, String nom, String adreca) {
        this.correu = correu;
        this.nom = nom;
        this.adreca = adreca;
    }

    public String getCorreu() {
        return correu;
    }

    public void setCorreu(String correu) {
        this.correu = correu;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdreca() {
        return adreca;
    }

    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    public boolean equals(Object externo) {
        String myCorreu = this.getCorreu();
        String externoCorreu = ((Client) externo).getCorreu();
        return myCorreu.equals(externoCorreu);
    }

    public abstract String tipusClient();

    public abstract float calcMensual();

    public abstract float descompteEnv();

    public String toString() {
        String informacio = ", Email = " + getCorreu() + ", Nom = " + getNom() + ", Adreça = " + getAdreca();
        return informacio;
    }

}
