package prog2.model;

import java.util.Date;

public class ComandaNormal extends Comanda {
    private String tipus = "Normal";

    public ComandaNormal(Article article, Client client, int quantitat) {
        super(article, client, quantitat);
    }

    public String tipusComanda() {
        return tipus;
    }

    public boolean comandaEnviada() {
        Date dataActual = new Date();
        return dataActual.getTime() - data.getTime() >= article.getTemps() * 60000;

    }

    public boolean comandaRebuda() {
        Date dataActual = new Date();
        return dataActual.getTime() - data.getTime() >= article.getTemps() * 60000 + 2 * 24 * 3600 * 1000;
    }

    public float preuEnviament() {
        return 1;
    }

    public String toString() {
        String informacio = "Tipus = " + tipusComanda() + super.toString() + ", Enviat = " + comandaEnviada()
                + ", Rebuda = "
                + comandaRebuda() + ", PreuArticles = " + article.getPreu() + ", Preu Enviament = " + preuEnviament();
        return informacio;

    }

}
