package prog2.model;

import java.util.Date;

public class ComandaUrgent extends Comanda {
    private String tipus = "Urgent";

    public ComandaUrgent(Article article, Client client, int quantitat) {
        super(article, client, quantitat);
    }

    public String tipusComanda() {
        return tipus;
    }

    public boolean comandaEnviada() {
        Date dataActual = new Date();
        return dataActual.getTime() - data.getTime() >= (article.getTemps() * 60000) / 2;
    }

    public boolean comandaRebuda() {
        Date dataActual = new Date();
        return dataActual.getTime() - data.getTime() >= (article.getTemps() * 60000) / 2 + 24 * 3600 * 1000;
    }

    public float preuEnviament() {
        return 4;
    }

    public String toString() {
        String informacio = "Tipus = " + tipusComanda() + super.toString() + ", Enviat = " + comandaEnviada()
                + ", Rebuda = "
                + comandaRebuda() + ", PreuArticles = " + article.getPreu() + ", Preu Enviament = " + preuEnviament();
        return informacio;
    }
}
