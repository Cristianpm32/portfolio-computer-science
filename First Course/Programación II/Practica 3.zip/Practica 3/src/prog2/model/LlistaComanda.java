package prog2.model;

import prog2.vista.MercatException;

public class LlistaComanda extends Llista<Comanda> {

    public LlistaComanda() {
        super();
    }

    public void afegir(Comanda t) throws MercatException {
        if (t instanceof ComandaUrgent && !t.getArticle().isUrgent()) {
            throw new MercatException("L'article no és compatible amb Comanda urgent ");
        }
        else if (t instanceof ComandaNormal && t.getArticle().isUrgent()){
            throw new MercatException("L'article no és compatible amb Comanda Normal ");
        }
        else {
            super.afegir(t);
        }
    }
}
