/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import prog2.vista.MercatException;

/**
 *
 * @author acano
 */
public class Dades implements InDades, Serializable {

    private LlistaArticles llistaArticles;
    private LlistaClient llistaClients;
    private LlistaComanda llistaComandes;
    private final float DESCOMPTE_DESPESES_ENVIAMENT = 0.2f;
    private final int MENSUALITAT_PREMIUM = 4;
    private String nom = "Mercat UB";

    public Dades() {
        llistaArticles = new LlistaArticles();
        llistaClients = new LlistaClient();
        llistaComandes = new LlistaComanda();

    }

    public String getNom() {
        return nom;
    }

    public void afegirArticle(String id, String nom, float preu, int temps, boolean admetUrgent)
            throws MercatException {
        Article article = new Article(id, nom, preu, temps, admetUrgent);
        llistaArticles.afegir(article);
    }

    public ArrayList<Article> recuperaArticles() {

        return llistaArticles.getArrayList();
    }

    public void afegirClient(String email, String nom, String adreca, boolean esPremium) throws MercatException {
        if (esPremium) {
            Client client = new ClientPremium(email, nom, adreca, DESCOMPTE_DESPESES_ENVIAMENT, MENSUALITAT_PREMIUM);
            llistaClients.afegir(client);
        } else {
            Client client = new ClientEstandard(email, nom, adreca);
            llistaClients.afegir(client);
        }
    }

    public ArrayList<Client> recuperaClients() {
        return llistaClients.getArrayList();
    }

    public void afegirComanda(int articlePos, int clientPos, int quantitat, boolean esUrgent) throws MercatException {
        if(articlePos > llistaArticles.getSize() - 1 || clientPos > llistaClients.getSize()){
            throw new MercatException("La posició indicada no existeix.");
        }
        if (esUrgent == true) {
            Comanda comanda = new ComandaUrgent(llistaArticles.getAt(articlePos), llistaClients.getAt(clientPos),
                    quantitat);
            llistaComandes.afegir(comanda);
        } else {
            Comanda comanda = new ComandaNormal(llistaArticles.getAt(articlePos), llistaClients.getAt(clientPos),
                    quantitat);
            llistaComandes.afegir(comanda);
        }

    }

    public void esborrarComanda(int position) throws MercatException {
        if(position > llistaComandes.getSize() - 1){
            throw new MercatException("La posició indicada no existeix.");
        }
        else if (llistaComandes.getAt(position).comandaEnviada()) {
            throw new MercatException("La comanda ja ha estat enviada, no es pot cancel·lar");
        } else {
            llistaComandes.esborrar(llistaComandes.getAt(position));
        }

    }
    
    

    public ArrayList<Comanda> recuperaComandes() {
        return llistaComandes.getArrayList();
    }

    public ArrayList<Comanda> recuperaComandesUrgents() {
        ArrayList<Comanda> comandesUrgents = new ArrayList<Comanda>();
        Iterator<Comanda> it = llistaComandes.getArrayList().iterator();
        while (it.hasNext()) {
            Comanda c = it.next();
            if (c instanceof ComandaUrgent) {
                comandesUrgents.add(c);
            }
        }
        return comandesUrgents;
    }

}