package prog2.model;

import prog2.vista.MercatException;

public class LlistaArticles extends Llista<Article> {
    public LlistaArticles() {
        super();
    }

    public void afegir(Article t) throws MercatException {
        if (llista.contains(t)) {
            throw new MercatException("L'article ja està a la llista.");
        } else {
            super.afegir(t);
        }
    }
}
