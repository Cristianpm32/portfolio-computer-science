package prog2.model;

import prog2.vista.MercatException;

public class LlistaClient extends Llista<Client> {
    public LlistaClient() {
        super();
    }

    public void afegir(Client t) throws MercatException {
        if (llista.contains(t)) {
            throw new MercatException("El client ja està a la llista.");
        } else {
            super.afegir(t);
        }
    }
}