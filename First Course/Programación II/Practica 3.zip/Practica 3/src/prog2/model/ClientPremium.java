package prog2.model;

public class ClientPremium extends Client {
    private float descompteEnv;
    private float mensualitat;
    private String tipus = "Premium";

    public ClientPremium(String correu, String nom, String adreca, float descompteEnv, float mensualitat) {
        super(correu, nom, adreca);
        this.descompteEnv = descompteEnv;
        this.mensualitat = mensualitat;

    }

    public float getDescompteEnv() {
        return this.descompteEnv;
    }

    public void setDescompteEnv(float descompteEnv) {
        this.descompteEnv = descompteEnv;
    }

    public float getMensualitat() {
        return this.mensualitat;
    }

    public void setMensualitat(float mensualitat) {
        this.mensualitat = mensualitat;
    }

    public String tipusClient() {
        return tipus;
    }

    public float calcMensual() {
        return mensualitat;
    }

    public float descompteEnv() {
        return descompteEnv;
    }

    public String toString() {
        String informacio = "Tipus = " + tipusClient() + super.toString() + ", Descompte Enviament = " + descompteEnv()
                +
                ", Mensualitat = " + calcMensual();
        return informacio;
    }
}
