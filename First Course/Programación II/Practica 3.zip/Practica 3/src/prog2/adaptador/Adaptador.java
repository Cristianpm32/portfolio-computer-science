/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.adaptador;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.*;

import prog2.model.*;
import prog2.vista.MercatException;

/**
 *
 * @author acano
 */
public class Adaptador implements Serializable {
    private Dades dades;

    public Adaptador() {
        dades = new Dades();
    }

    public String getNom() {
        return dades.getNom();
    }

    public void afegirArticle(String id, String nom, float preu, int temps, boolean admetUrgent)
            throws MercatException {
        dades.afegirArticle(id, nom, preu, temps, admetUrgent);
    }

    public void afegirClient(String email, String nom, String adreca, boolean esPremium) throws MercatException {
        dades.afegirClient(email, nom, adreca, esPremium);
    }

    public void afegirComanda(int articlePos, int clientPos, int quantitat, boolean esUrgent) throws MercatException {
        dades.afegirComanda(articlePos, clientPos, quantitat, esUrgent);

    }

    public void esborrarComanda(int position) throws MercatException {
        dades.esborrarComanda(position);
    }

    public void esborrarComandaUrgent(int position) throws MercatException {
        ArrayList<Comanda> comandes = dades.recuperaComandes();
        int count = 0;
        for (int i = 0; i < comandes.size()-1; i++){
            if (comandes.get(i) instanceof ComandaUrgent){
                count++;
                System.out.println(count);
            }
            if (count == position){
                dades.esborrarComanda(i+1);
            }
        }
    }
    public ArrayList<String> infoArticles() {
        ArrayList<String> infoArticles = new ArrayList();
        Iterator<Article> it = dades.recuperaArticles().iterator();
        while (it.hasNext()) {
            Article article = it.next();
            infoArticles.add(article.toString());
        }
        return infoArticles;
    }

    public ArrayList<String> infoClients() {
        ArrayList<String> infoClients = new ArrayList();
        Iterator<Client> it = dades.recuperaClients().iterator();
        while (it.hasNext()) {
            Client client = it.next();
            infoClients.add(client.toString());
        }
        return infoClients;
    }

    public ArrayList<String> infoComandes() {
        ArrayList<String> infoComandes = new ArrayList();
        Iterator<Comanda> it = dades.recuperaComandes().iterator();
        while (it.hasNext()) {
            infoComandes.add(it.next().toString());
        }
        return infoComandes;
    }

    public ArrayList<String> infoComandesUrgents() {
        ArrayList<String> infoComandesUrgents = new ArrayList();
        Iterator<Comanda> it = dades.recuperaComandesUrgents().iterator();
        while (it.hasNext()) {
            infoComandesUrgents.add(it.next().toString());
        }
        return infoComandesUrgents;
    }

    /**
     * Permet guardar les dades introduides (respecte els socis) per teclat en un
     * fitxer.
     * 
     * @param camiDesti
     * @throws ExcepcioClub
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void guardarDades(String camiDesti) throws MercatException {
        File file = new File(camiDesti);
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            oos.writeObject(dades);
            oos.close();
        } catch (FileNotFoundException e) {
            throw new MercatException(e.getMessage());
        } catch (IOException e) {
            throw new MercatException(e.getMessage());
        } finally {
            try {
                fout.close();
            } catch (IOException e) {
                throw new MercatException(e.getMessage());
            } catch (Exception e) {
                throw new MercatException(e.getMessage());
            }
        }
    }

    /**
     * Permet recuperar les dades dels socis guardades en un fitxer previament en
     * una altre sessió.
     * 
     * @param camiOrigen
     * @return Dades
     * @throws ExcepcioClub
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void carregarDades(String camiOrigen) throws MercatException {
        File fitxer = new File(camiOrigen);
        FileInputStream fin = null;
        try {
            fin = new FileInputStream(fitxer);
            ObjectInputStream ois = new ObjectInputStream(fin);
            dades = (Dades) ois.readObject();
            ois.close();
            // fin.close();
        } catch (IOException e) {
            throw new MercatException(e.getMessage());
        } catch (ClassNotFoundException e) {
            throw new MercatException(e.getMessage());
        } finally {
            try {
                fin.close();
            } catch (IOException e) {
                throw new MercatException(e.getMessage());
            }
            catch (Exception e) {
                throw new MercatException(e.getMessage());
            }
        }

    }

    public void clear() {
        dades.recuperaArticles().clear();
        dades.recuperaClients().clear();
        dades.recuperaComandes().clear();
        dades.recuperaComandesUrgents().clear();
    }
}
