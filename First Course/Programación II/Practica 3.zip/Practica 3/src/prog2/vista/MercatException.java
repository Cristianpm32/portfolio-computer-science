package prog2.vista;

public class MercatException extends Exception {
    /**
     * 
     */
    public MercatException(){
        super();
    }
    
    /**
     * Constructor de MercatException.
     * 
     * @param missatgeError
     */
    public MercatException(String missatgeError) {
        super(missatgeError);
        
    }
}
