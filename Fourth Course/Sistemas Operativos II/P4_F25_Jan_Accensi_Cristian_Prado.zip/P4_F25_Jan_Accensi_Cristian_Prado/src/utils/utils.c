#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int read_country_ids(FILE *arxiuCiutats)
{
    int numCountries = 0;
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), arxiuCiutats) != NULL)
    {
        numCountries++;
    }
    return numCountries;
}

void*** top10Temperatures(void*** matriu, int files){

    
    // Creem una matriu per a emmagatzemar el top10
    void*** top10 = (void***)malloc(10 * sizeof(void**));
    
    // Per cada fila de la matriu reservem 6 espais de memòria (id, nom, dataRegistreTempMax, temperaturaMax, dataRegistreTempMin, temperaturaMin)
    for (int i = 0; i < 10; i++) {
        top10[i] = (void**)malloc(6 * sizeof(void*));
    }


    // Inicialitzem matriu top10 buida
    for (int i = 0; i < 10; i++) {                    
        int* id = malloc(sizeof(int));
        *id = i+1; // Inicialitzar amb el valor de i+1
        top10[i][0] = id;

        char* pais = malloc(21 * sizeof(char)); // Nom\u00e9s espai per 20 car\u00e0cters + '\0'
        strcpy(pais, ""); // Inicialitzar amb cadena buida
        top10[i][1] = pais;

        float* temp = malloc(sizeof(float));
        *temp = -1000.0f; // Inicialitzar amb -1000.0
        top10[i][2] = temp;            
    }
    
    int indices[files];     
    for(int i = 0; i < files; i++){
        indices[i] = i;
    }
    
    // Aqui el que fem és ordenar la matriu segons la columna 5 (temperatura màxima)    
    for(int i = 0; i < files; i++){
        for(int j = i+1; j < files; j++){                    
            float temp_i = *(float*)matriu[indices[i]][5]; // Convertir el valor a float
            float temp_j = *(float*)matriu[indices[j]][5]; // Convertir el valor a float
            if (temp_i < temp_j) {
                // Intercanviar els \u00edndexs si el valor de la posici\u00f3 i \u00e9s m\u00e9s petit que el de la posici\u00f3 j
                int temp = indices[i];
                indices[i] = indices[j];
                indices[j] = temp;
            }
        }
    }
    
    
    
    for(int i = 0; i < 10; i++){
        *(int*)top10[i][0] = indices[i]+1;
        *(char**)top10[i][1] = (char*)matriu[indices[i]][1];        
        *(float*)top10[i][2] = *(float*)matriu[indices[i]][5];                        
    }
    return top10;
}   

void printTop10(void *** top10){
    // Print table headers
    printf("-------------------------------------------------------------\n");
	printf("%-10s %-10s %-20s %-20s\n", "Posici\u00f3", "ID", "Ciutat", "Temperatura m\u00e0xima");
	printf("-------------------------------------------------------------\n");

	// Print table rows
	for (int i = 0; i < 10; i++) {
	    printf("%-10d %-10d %-20s %-20.2f\n",
		i + 1,
		*((int*)top10[i][0]),
		*((char**)top10[i][1]),
		*((float*)top10[i][2]));
	}	
	printf("-------------------------------------------------------------\n");
	    
}

void ***crear_matriu_buida(int files,int columnes)
{

    // Crear la matriu buida
    void ***matriu = (void ***)malloc(files * sizeof(void **));
    if (matriu == NULL)
    {
        perror("Error en malloc matriu");
        return NULL;
    }

    for (int i = 0; i < files; i++)
    {
        matriu[i] = (void **)malloc(columnes * sizeof(void *));
        if (matriu[i] == NULL)
        {
            perror("Error en malloc matriu[i]");
            // Liberar mem\u00f2ria pr\u00e8viament assignada
            for (int k = 0; k < i; k++)
            {
                free(matriu[k]);
            }
            free(matriu);
            return NULL;
        }
    }

    // Inicializar la matriz
    for (int i = 0; i < files; i++)
    {
        for (int j = 0; j < columnes; j++)
        {
            if (j == 0)
            { // Columna 0: int
                int *value = malloc(sizeof(int));
                if (value == NULL)
                {
                    perror("Error en malloc int");
                    // Gestionar l'error de manera adequada
                }
                *value = i + 1; // Inicialitzar amb el valor de i+1
                matriu[i][j] = value;
            }
            else if (j == 1)
            {
                char *value = malloc(50 * sizeof(char)); // Espai per 49 car\u00e0cters + '\0'
                if (value == NULL)
                {
                    perror("Error en malloc char");
                    // Gestionar l'error de manera adequada
                }
                strcpy(value, ""); // Inicialitzar amb cadena buida
                matriu[i][j] = value;
            }
            else if (j == 3 || j == 5)
            { // Columnes 3 i 5: float
                float *value = malloc(sizeof(float));
                if (value == NULL)
                {
                    perror("Error en malloc float");
                    // Gestionar l'error de manera adequada
                }
                if (j == 3)
                {
                    *value = 1000.0f; // Inicialitzar amb 1000.0
                }
                else
                {
                    *value = -1000.0f; // Inicialitzar amb -1000.0
                }
                matriu[i][j] = value;
            }
            else if (j == 2 || j == 4)
            {                                            // Columnes 2 i 4: char[11]
                char *value = malloc(11 * sizeof(char)); // Espai per 10 car\u00e0cters + '\0'
                if (value == NULL)
                {
                    perror("Error en malloc char[11]");
                    // Gestionar l'error de manera adequada
                }
                strcpy(value, ""); // Inicialitzar amb cadena buida
                matriu[i][j] = value;
            }
            else
            {
                matriu[i][j] = NULL; // Assignar NULL per columnes no gestionades
            }
        }
    }

    return matriu;
}

void free_matriu(void ***matriu, int files, int columnes) {
    for (int i = 0; i < files; i++) {
        for (int j = 0; j < columnes; j++) {
            free(matriu[i][j]);
        }
        free(matriu[i]);
    }
    free(matriu);
}
