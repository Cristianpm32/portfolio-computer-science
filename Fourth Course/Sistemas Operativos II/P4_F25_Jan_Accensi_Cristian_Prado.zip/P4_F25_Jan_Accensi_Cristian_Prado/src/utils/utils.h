#ifndef UTILS_H
#define UTILS_H


#include <stdio.h>

int read_country_ids(FILE *arxiuCiutats);
void ***crear_matriu_buida(int files,int columnes);
void printTop10(void *** top10);
void*** top10Temperatures(void*** matriu, int files);

void free_matriu(void ***matriu, int files, int columnes);

#endif // UTILS_H
