#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <sys/time.h>

#include "../utils/utils.h"


#define MIDA_LINIA 256

// Definicions de constants
#define H 6  // Nombre de fils (consumidors)
#define B 50 // Nombre de blocs del buffer
#define N 100000 // Número de línies per bloc

typedef struct cell
{
    int nelems;
    char **lines;
} cell;

// Estructura de paràmetres per a compartir dades entre fils
typedef struct Parametres
{
    cell *buffer; // Aquest és el buffer compartit del paradigma

    // Variables per a controlar l'estat del buffer
    int comptador; 
    int insercio;
    int extraccio;

    // Variable per saber si s'ha acabat de llegir el fitxer
    bool done;

    // Mutex i variables condicionals per a la concurrència utilitzant monitors
    pthread_mutex_t mutexBuffer;
    pthread_mutex_t mutexMatriu; 
    pthread_cond_t buit;
    pthread_cond_t ple;

    // Matriu de dades
    void ***matriu;

    // Nombre de països
    int files;

} Parametres;

// Funció per processar dades pel consumidor
void *consumir_dades(void *arg)
{
    // Recuperem les dades per paràmetre
    Parametres *params = (Parametres *)arg;
    void ***matriu = params->matriu;
    int files = params->files;
    pthread_mutex_t *mutexMatriu = &params->mutexMatriu;
    pthread_mutex_t *mutexBuffer = &params->mutexBuffer;
    pthread_cond_t *buit = &params->buit;
    pthread_cond_t *ple = &params->ple;
    

    // Creem dues cel·les (locals) per intercanviar dades
    cell cell_consumidor, tmp; 
    cell_consumidor.lines = (char **)malloc(sizeof(char *) * N);
    
    while (1)
    {
        // Inici Regió crítica del buffer
        pthread_mutex_lock(mutexBuffer);
        while (params->comptador == 0 && !params->done)
        {
            // Buffer buit, esperem a que el productor posi dades
            pthread_cond_wait(buit, mutexBuffer);
        }

        if (params->done && params->comptador == 0)
        {
            pthread_mutex_unlock(mutexBuffer);
            break;
        }
        // Intercanvi de cel·les eficient
        tmp = cell_consumidor;
        cell_consumidor = params->buffer[params->extraccio];
        params->buffer[params->extraccio] = tmp;
        
        // Actualització dels estats del buffer
        params->buffer[params->extraccio].nelems = 0;
        params->extraccio = (params->extraccio + 1) % B;
        params->comptador--;

        // Avisar al productor que hi ha espai
        pthread_cond_signal(ple);
        pthread_mutex_unlock(mutexBuffer);
        // Final de la regió crítica del buffer

        if(cell_consumidor.nelems == 0){
            continue;
        }

        // Ara processem les dades
        for (int j = 0; j < cell_consumidor.nelems; j++)
        {
        

            char *rest = NULL;
            char *token = strtok_r(cell_consumidor.lines[j], ",", &rest);

            char *data = NULL;
            float temperatura_ciutat_float = 0.0f;
            int id_pais = 0;
            char *nom_pais = NULL;
            int comptador = 1;

            while (comptador <= 7)
            {
                if (token == NULL)
                {
                    break;
                }
                switch (comptador)
                {
                case 1: // Fecha
                    data = token;
                    break;
                case 2: // Temperatura
                    temperatura_ciutat_float = atof(token);
                    break;
                case 5: // Nom País
                    nom_pais = token;
                    break;
                case 6: // ID País
                    id_pais = atoi(token);
                    break;
                default:
                    break;
                }

                comptador++;
                token = strtok_r(NULL, ",", &rest);
            }
        


            if (comptador > 7 && id_pais >= 1 && id_pais <= files)
            {
                // Inici Regió crítica de la matriu
                pthread_mutex_lock(mutexMatriu);

                // Actualitzar nom del país
                strncpy((char *)matriu[id_pais - 1][1], nom_pais, 49);
                ((char *)matriu[id_pais - 1][1])[49] = '\0';

                // Actualitzar temperatura mínima
                if (temperatura_ciutat_float < *((float *)matriu[id_pais - 1][3]))
                {
                    *((float *)matriu[id_pais - 1][3]) = temperatura_ciutat_float;
                    strncpy((char *)matriu[id_pais - 1][2], data, 9);
                    ((char *)matriu[id_pais - 1][2])[9] = '\0';
                }

                // Actualitzar temperatura màxima
                if (temperatura_ciutat_float > *((float *)matriu[id_pais - 1][5]))
                {
                    *((float *)matriu[id_pais - 1][5]) = temperatura_ciutat_float;
                    strncpy((char *)matriu[id_pais - 1][4], data, 9);
                    ((char *)matriu[id_pais - 1][4])[9] = '\0';
                    
                }
                pthread_mutex_unlock(mutexMatriu);
                // Final Regió crítica de la matriu
            }                                   
        }        
    }

    free(cell_consumidor.lines);        
    return NULL;
}

// Funció per llegir les dades de temperatura i inserir-les al buffer (fil principal)
int read_temperature_data(FILE *arxiuDades, void ***matriu, int numCountries)
{
   // Crear el buffer de B blocs
    cell *buffer = (cell *)malloc(sizeof(cell) * B);
    if (buffer == NULL)
    {
        fprintf(stderr, "Error: No s'ha pogut reservar memòria per al buffer.\n");
        return EXIT_FAILURE;
    }
    
    // Per a cada bloc reservem memòria
    for (int i = 0; i < B; i++)
    {
        buffer[i].lines = (char **)malloc(sizeof(char *) * N);       
        buffer[i].nelems = 0;
    }

    // Crear els paràmetres pels consumidors
    Parametres params;
    params.buffer = buffer;
    params.comptador = 0;
    params.insercio = 0;
    params.extraccio = 0;
    params.done = false;
    pthread_mutex_init(&params.mutexBuffer, NULL);
    pthread_mutex_init(&params.mutexMatriu, NULL);
    pthread_cond_init(&params.buit, NULL);
    pthread_cond_init(&params.ple, NULL);
    params.matriu = matriu;
    params.files = numCountries;    

    // Crear els consumidors
    pthread_t fils[H];
    for (int i = 0; i < H; i++)
    {
        if (pthread_create(&fils[i], NULL, consumir_dades, &params) != 0)
        {
            fprintf(stderr, "Error al crear el fil %d\n", i + 1);
            // Alliberar recursos
            params.done = true;
            pthread_cond_broadcast(&params.buit);
            for (int j = 0; j < i; j++)
            {
                pthread_join(fils[j], NULL);
            }
            // Alliberar memòria del buffer
            for (int j = 0; j < B; j++)
            {
                free(buffer[j].lines);
            }
            free(buffer);
            pthread_mutex_destroy(&params.mutexBuffer);
            pthread_mutex_destroy(&params.mutexMatriu);
            pthread_cond_destroy(&params.buit);
            pthread_cond_destroy(&params.ple);
            return EXIT_FAILURE;
        }
    }

    // Utilitzem una variable local per llegir les dades
    char linia[MIDA_LINIA];

    // Creem les cel·les locals per a transferir les dades al buffer
    cell cell_producer, tmp;
    cell_producer.lines = (char **)malloc(sizeof(char *) * N);
    
    while (1)
    {                              
        // Llegir N línies
        int i;
        for (i = 0; i < N; i++)
        {
            if (fgets(linia, MIDA_LINIA, arxiuDades) == NULL)
            {
                break;
            }
            // Copiar la línia al buffer
            cell_producer.lines[i] = strdup(linia);
            if (cell_producer.lines[i] == NULL)
            {
                fprintf(stderr, "Error: No s'ha pogut duplicar la línia.\n");
                break;
            }
        }



        // Inici de la regió crítica del buffer
        pthread_mutex_lock(&params.mutexBuffer);
        while (params.comptador == B)
        {
            // Buffer ple, esperem
            pthread_cond_wait(&params.ple, &params.mutexBuffer);
        }

        // Inserir la cel·la al buffer de forma eficient        
        tmp = buffer[params.insercio];        
        buffer[params.insercio] = cell_producer;
        cell_producer = tmp;

       
        // Actualitzem els estats del buffer
        buffer[params.insercio].nelems = N;    
        params.insercio = (params.insercio + 1) % B;
        params.comptador++;

        // Avisar als consumidors que hi ha dades
        pthread_cond_signal(&params.buit);
        pthread_mutex_unlock(&params.mutexBuffer);
        // Final de la regió crítica del buffer

        if (i < N)
        {
            // No s'han llegit N línies, hem arribat al final del fitxer
            break;
        }
    }

    // Avisar als consumidors que hem acabat
    pthread_mutex_lock(&params.mutexBuffer);
    params.done = true;
    pthread_cond_broadcast(&params.buit);
    pthread_mutex_unlock(&params.mutexBuffer);

    fclose(arxiuDades); // Tancar l'arxiu    

    // Esperar que tots els fils acabin
    for (int i = 0; i < H; i++)
    {
        pthread_join(fils[i], NULL);
    }
    

    free(cell_producer.lines);
    // Alliberar memòria del buffer    
    free(buffer);

    // Destruir mutex i condicions
    pthread_mutex_destroy(&params.mutexBuffer);
    pthread_mutex_destroy(&params.mutexMatriu);
    pthread_cond_destroy(&params.buit);
    pthread_cond_destroy(&params.ple);

    return 0;
}



int main(int argc, char *argv[])
{
    int numCountries = 0;

    char *rutaDades;
    char *rutaCiutats;
    // Verificar que els paràmetres siguin correctes
    if (argc != 3)
    {
        rutaDades = "../data/GlobalLandTemperaturesByCityData.csv";
        rutaCiutats = "../data/GlobalLandTemperaturesByCityIDs.csv";
    }
    else
    {
        rutaDades = argv[1];
        rutaCiutats = argv[2];
        printf("Principal: Fitxers de dades proporcionats per arguments.\n");
    }

    FILE *arxiuCiutats = fopen(rutaCiutats, "r");
    if (arxiuCiutats == NULL)
    {
        fprintf(stderr, "Error a l'obrir l'arxiu de ciutats: %s\n", rutaCiutats);
        return EXIT_FAILURE;
    }

    // Obtenir nombre de països
    numCountries = read_country_ids(arxiuCiutats);
    fclose(arxiuCiutats);

    FILE *arxiuDades = fopen(rutaDades, "r");
    if (arxiuDades == NULL)
    {
        fprintf(stderr, "Error a l'obrir l'arxiu de dades: %s\n", rutaDades);
        return EXIT_FAILURE;
    }

    // Llegir la primera línia (capçalera)
    char primera[MIDA_LINIA];
    if (fgets(primera, MIDA_LINIA, arxiuDades) == NULL)
    {
        fprintf(stderr, "Error a l'obrir la primera línia de l'arxiu de dades\n");
        fclose(arxiuDades);
        return EXIT_FAILURE;
    }



    // Crear matriu buida
    void ***matriu = crear_matriu_buida(numCountries, 6);
    if (matriu == NULL)
    {
        fprintf(stderr, "Error: No s'ha pogut crear la matriu buida.\n");
        fclose(arxiuDades);
        return EXIT_FAILURE;
    }

    /*
     * PRODUCTOR
     */
    
    clock_t start_1 = clock();

    struct timeval start_2;
    if (gettimeofday(&start_2, NULL) != 0)
    {
        perror("gettimeofday failed");
        return EXIT_FAILURE;
    }

    int r = read_temperature_data(arxiuDades, matriu, numCountries);

    clock_t end_1 = clock();

    struct timeval end_2;
    if (gettimeofday(&end_2, NULL) != 0)
    {
        perror("gettimeofday failed");
        free_matriu(matriu, numCountries, 6);
        return EXIT_FAILURE;
    }

    if (r != 0)
    {
        fprintf(stderr, "Error al llegir les dades\n");
        free_matriu(matriu, numCountries, 6);
        return EXIT_FAILURE;
    }

    // Calculem temps d'ús de CPU
    double cpu_time = ((double)(end_1 - start_1)) / CLOCKS_PER_SEC;

    // Calculem el temps real que triga el programa
    double real_time = (end_2.tv_sec - start_2.tv_sec) +
                       (end_2.tv_usec - start_2.tv_usec) / 1e6;
    printf("-------------------------------------------------------------\n");
    printf("Temps d'execució (clock): %.6f seconds\n", cpu_time);
    printf("Temps d'execució (gettimeofday): %.6f seconds\n", real_time);

    printTop10(top10Temperatures(matriu, numCountries));
    free_matriu(matriu, numCountries, 6);
    return EXIT_SUCCESS;
}