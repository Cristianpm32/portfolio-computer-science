
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <sys/time.h>
#include "../utils/utils.h"

// Variables globals (Observem que aquí no tenim la matriu ni les dades dels fils)
#define NUM_FILS 8
#define BUFFER_SIZE 128
#define LINIES_PER_LECTURA 100000

/*
    * Estructura de dades per passar els arguments als fils. Aquesta estructura conté:
    * - El número de fil
    * - L'arxiu de dades
    * - Un booleà que indica si s'ha acabat de llegir l'arxiu
    * - El mutex per protegir l'arxiu de dades i el booleà (Zona crítica: Lectura de l'arxiu)
    * - El mutex per protegir la matriu (Zona crítica: Escriptura a la matriu)
    * - El nombre de files de la matriu
    * - El nombre de columnes de la matriu
    * - La matriu on es guardaran les dades
*/

typedef struct
{
    int thread_id;
    FILE *arxiuDades;
    bool *done;
    pthread_mutex_t *mutexFDandDone;
    pthread_mutex_t *mutexMatriu;
    int files;
    int columnes;
    void ***matriu;
} ThreadArgs;

// Funció que llegeix un bloc de dades de l'arxiu i actualitza la matriu. És la funció que executen els fils
void *llegirBloc(void *args)
{
    // Obtenim els arguments a partir de l'estructura que rebem per paràmetre
    ThreadArgs *dadesFils = (ThreadArgs *)args;
    FILE *arxiuDades = dadesFils->arxiuDades;
    bool *done = dadesFils->done;
    pthread_mutex_t *mutexFDandDone = dadesFils->mutexFDandDone;
    pthread_mutex_t *mutexMatriu = dadesFils->mutexMatriu;
    int files = dadesFils->files;
    void ***matriu = dadesFils->matriu;
    // Buffer per llegir una línia de l'arxiu
    char linia[BUFFER_SIZE];

    // Buffer per llegir LINIES_PER_LECTURA línies de l'arxiu
    char **buffer = malloc(LINIES_PER_LECTURA * sizeof(char *));

    // Si no s'ha pogut reservar memòria, sortim
    if (!buffer)
    {
        fprintf(stderr, "Error en reservar memòria per al buffer\n");
        pthread_exit(NULL);
    }

    // Reservem memòria per a cada línia
    for (int i = 0; i < LINIES_PER_LECTURA; i++)
    {
        buffer[i] = malloc(BUFFER_SIZE * sizeof(char));
        if (!buffer[i])
        {
            fprintf(stderr, "Error en reservar memòria per a la línia %d\n", i);
            // Alliberar memòria prèviament reservada
            for (int j = 0; j < i; j++)
            {
                free(buffer[j]);
            }
            free(buffer);
            pthread_exit(NULL);
        }
    }

    // Llegim LINIES_PER_LECTURA línies de l'arxiu i actualitzem la matriu mentre no s'hagi acabat de llegir
    while (1)
    {   
        // Protegim l'accés a l'arxiu i al booleà done amb un mutex, bloquejant-lo abans de llegir. D'aquesta forma
        // evitem que altres fils puguin llegir l'arxiu o canviar el booleà done mentre aquest fil està llegint.
        pthread_mutex_lock(mutexFDandDone);    

        // Variable per comptar les línies llegides    
        int liniesLlegides = 0;
        for (int i = 0; i < LINIES_PER_LECTURA; i++)
        {
            if (fgets(linia, sizeof(linia), arxiuDades) == NULL)
            {
                *done = true;
                break;
            }
            linia[strcspn(linia, "\n")] = '\0';
            strcpy(buffer[i], linia);
            liniesLlegides++;
        }

        // Desbloquegem el mutex perquè altres fils puguin llegir l'arxiu o canviar el booleà done
        pthread_mutex_unlock(mutexFDandDone);

        // Si no s'ha llegit cap línia, sortim, ja que hem acabat de llegir l'arxiu
        if (liniesLlegides == 0)
        {
            break;
        }

        // Processar les dades llegides
        for (int j = 0; j < liniesLlegides; j++)
        {
            // Variables per emmagatzemar les dades
            char *rest = NULL;
            char *token = strtok_r(buffer[j], ",", &rest);

            char *data = NULL;
            float temperatura_ciutat_float = 0.0f;
            int id_pais = 0;
            char *nom_pais = NULL;
            int comptador = 1;
         
            // El 8 és el nombre de columnes que té el fitxer
            while (comptador < 8 )
            {
                if (token == NULL)
                {                    
                    break;
                }

                switch (comptador)
                {
                case 1: // Fecha
                    data = token;
                    break;
                case 2: // Temperatura
                    temperatura_ciutat_float = atof(token);
                    break;
                case 5: // Nom Pais
                    nom_pais = token;
                    break;
                case 6: // ID Païs
                    id_pais = atoi(token);
                    break;
                default:
                    break;
                }

                comptador++;
                token = strtok_r(NULL, ",", &rest);
            }

            // Només actualitzem l'estructura compartida si totes les dades són vàlides i estan dins del rang
            if (comptador == 8 && id_pais >= 1 && id_pais <= files)
            {
                // Com que és una dada vàlida, aleshores bloquegem el mutex per protegir l'accés a la matriu
                // i actualitzem les dades si és necessari.
                pthread_mutex_lock(mutexMatriu);

                // Actualitzar nom del país
                strncpy((char *)matriu[id_pais - 1][1], nom_pais, 49);
                ((char *)matriu[id_pais - 1][1])[49] = '\0';

                // Actualitzar temperatura mínima
                if (temperatura_ciutat_float < *((float *)matriu[id_pais - 1][3]))
                {
                    *((float *)matriu[id_pais - 1][3]) = temperatura_ciutat_float;
                    strncpy((char *)matriu[id_pais - 1][2], data, 10);
                    ((char *)matriu[id_pais - 1][2])[10] = '\0';
                }

                // Actualitzar temperatura màxima
                if (temperatura_ciutat_float > *((float *)matriu[id_pais - 1][5]))
                {
                    *((float *)matriu[id_pais - 1][5]) = temperatura_ciutat_float;
                    strncpy((char *)matriu[id_pais - 1][4], data, 10);
                    ((char *)matriu[id_pais - 1][4])[10] = '\0';
                }
                // Desbloquegem el mutex perquè altres fils puguin accedir a la matriu
                pthread_mutex_unlock(mutexMatriu);
            }
        }
    
    }

    // Alliberem la memòria del buffer
    for (int i = 0; i < LINIES_PER_LECTURA; i++)
    {
        free(buffer[i]);
    }
    free(buffer);

    pthread_exit(NULL);
    return NULL;
}
int main(int argc, char *argv[])
{

    int numCountries = 0;
    int numCamps = 0;

    char *rutaDades;
    char *rutaCiutats;

    // Verificar que els paràmetres siguin correctes
    if (argc != 3)
    {
        rutaDades = "../data/GlobalLandTemperaturesByCityData.csv";
        rutaCiutats = "../data/GlobalLandTemperaturesByCityIDs.csv";
    }
    else
    {
        rutaDades = argv[1];
        rutaCiutats = argv[2];
    }
    // Obrir els arxius de ciutats
    FILE *arxiuCiutats = fopen(rutaCiutats, "r");
    if (arxiuCiutats == NULL)
    {
        fprintf(stderr, "Error a l'obrir l'arxiu de ciutats: %s\n", rutaCiutats);
        return EXIT_FAILURE;
    }

    // Obtenim nombre de països
    numCountries = read_country_ids(arxiuCiutats);
    fclose(arxiuCiutats);

    // Obrir l'arxiu de dades
    FILE *arxiuDades = fopen(rutaDades, "r");
    if (arxiuDades == NULL)
    {
        fprintf(stderr, "Error a l'obrir l'arxiu de dades: %s\n", rutaDades);
        return EXIT_FAILURE;
    }

    // LLEGIM LA PRIMERA LINIA
    char primera[BUFFER_SIZE];
    if (fgets(primera, BUFFER_SIZE, arxiuDades) == NULL)
    {
        fprintf(stderr, "Error a l'obrir la primera línia de l'arxiu de dades\n");
        return EXIT_FAILURE;
    }

    // Comptar el nombre de camps separats per comes per saber el nombre de columnes de la matriu
    char *token = strtok(primera, ",");
    while (token != NULL)
    {
        numCamps++;
        token = strtok(NULL, ",");
    }

    // Creem una matriu buida
    void ***matriu = crear_matriu_buida(numCountries, 6);

    // Comencem a paral·lelitzar
    pthread_t fils[NUM_FILS];

    // Creem una estructura de dades per passar els arguments als fils
    ThreadArgs args[NUM_FILS];

    // Creem els mutexs i el booleà per protegir les dades compartides entre els fils
    pthread_mutex_t mutexFDandDone = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t mutexMatriu = PTHREAD_MUTEX_INITIALIZER;
    bool done = false;

    // Inicialitzem els arguments dels fils, creant l'estructura de dades que passarem a cada fil
    for (int i = 0; i < NUM_FILS; i++)
    {
        args[i].thread_id = i + 1;
        args[i].arxiuDades = arxiuDades;
        args[i].done = &done;
        args[i].mutexFDandDone = &mutexFDandDone;
        args[i].mutexMatriu = &mutexMatriu;
        args[i].files = numCountries;
        args[i].columnes = numCamps;
        args[i].matriu = matriu;
    }

    clock_t start_1 = clock();

    struct timeval start_2;
    if (gettimeofday(&start_2, NULL) != 0)
    {
        perror("gettimeofday failed");
        return EXIT_FAILURE;
    }

    // Creem els fils i els passem per paràmetre els arguments a partir de l'estructura
    for (int i = 0; i < NUM_FILS; i++)
    {        
        if (pthread_create(&fils[i], NULL, llegirBloc, &args[i]) != 0)
        {
            fprintf(stderr, "Error al crear el hilo %d\n", i + 1);
            fclose(arxiuDades);
            free_matriu(matriu, numCountries, 6);
            return EXIT_FAILURE;
        }
    }

    // Esperem que tots els fils acabin
    for (int i = 0; i < NUM_FILS; i++)
    {
        pthread_join(fils[i], NULL);
    }

    clock_t end_1 = clock();

    
    struct timeval end_2;
    if (gettimeofday(&end_2, NULL) != 0)
    {
        perror("gettimeofday failed");
        free_matriu(matriu, numCountries, 6);
        return EXIT_FAILURE;
    }

    // Calculem el temps d'execució en segons
    double cpu_time = ((double)(end_1 - start_1)) / CLOCKS_PER_SEC;

    // Calcula el temps real en segons
    double real_time = (end_2.tv_sec - start_2.tv_sec) +
                       (end_2.tv_usec - start_2.tv_usec) / 1e6;

    printf("-------------------------------------------------------------\n");
    printf("Temps d'execució (clock): %.6f seconds\n", cpu_time);
    printf("Temps d'execució (gettimeofday): %.6f seconds\n", real_time);

    // Imprimim el top10 per comprovar que els resultats siguin correctes
    printTop10(top10Temperatures(matriu, numCountries));

    // Alliberem la memòria
    free_matriu(matriu, numCountries, 6);

    // Tanquem l'arxiu de dades
    fclose(arxiuDades);
    return EXIT_SUCCESS;
}

