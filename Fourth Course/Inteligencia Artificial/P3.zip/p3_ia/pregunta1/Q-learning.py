import numpy as np
import copy
import pandas as pd
import time

NORMAL_TRAINING = 1
IMPROVED_TRAINING = 2
DRUNKEN_SAILOR = 3
ERROR_RATE = 0.01
ALPHA = 0.9 # Si convergeix, Aixo es directament proporcional a la velocitat de convergencia
GAMMA = 0.2 # Si el conjunt d'estats es petit, el gamma pot ser petit, ja que no hi ha tantes transicions a considerar.
EPSILON = 0.05 # Si augmentes el epsilon, fas que sigui mes lenta la convergencia, pero si et quedes a 0 et pots quedar a un minim local. (En aquest aas el problema es tan senzill que un minim local es un minim global)
ITERATIONS = 10000
INTERMEDIATE_EPISODES_1 = 7
INTERMEDIATE_EPISODES_2 = 10
THRESHOLD = 10e-4

class CustomEnvironment:
    def __init__(self):        
        self.state_space = [(i, j) for i in range(1, 4) for j in range(1, 5)]        
        self.state_space.remove((2, 2))
        self.action_space = ["U", "D", "L", "R"] 
        self.current_state = (1, 1)
        self.terminal_states = (3, 4)  # Defineix l'estat terminal


    def reset(self):
        self.current_state = (1, 1)
        return self.current_state


    # Aquí permetem que l'entorn sigui estocàstic. En general donat un estat i una acció, 
    # sempre acabarem al mateix estat, però podria haver-hi un error i acabar en un altre estat.
    def step(self, action, mode=NORMAL_TRAINING):
        if mode == DRUNKEN_SAILOR:
            if np.random.rand() < ERROR_RATE:
                action = np.random.choice(self.action_space)
        old_state = self.current_state
        invalid = False
        if action == "U":
            self.current_state = (self.current_state[0] + 1, self.current_state[1])
        elif action == "D":
            self.current_state = (self.current_state[0] - 1, self.current_state[1])            
        elif action == "L":
            self.current_state = (self.current_state[0], self.current_state[1] - 1)
        elif action == "R":
            self.current_state = (self.current_state[0], self.current_state[1] + 1)


        # Comprova si l'estat és vàlid
        if self.current_state not in self.state_space:
            self.current_state = old_state
            invalid = True                                                          

        # Compute the reward
        if self.current_state == self.terminal_states:
            reward = 100
            done = True
        else:
            if mode == NORMAL_TRAINING:
                reward = -1
                done = False
            elif mode == IMPROVED_TRAINING or mode == DRUNKEN_SAILOR:
                reward = self.reward_function(self.current_state)
                done = False
        return self.current_state, reward, done, invalid
    
    def reward_function(self, state):
        # Utilitzem les coordenades de l'estat inicial per calcular la recompensa
        reward = -5 + (abs(1-state[0]) + abs(1-state[1]))
        return reward

    def converged(self, Q, Q_old, threshold):
        for state in Q.keys():
            for action in Q[state].keys():
                if abs(Q[state][action] - Q_old[state][action]) > threshold:
                    return False
        return True

    def train(self, alpha=ALPHA, gamma=GAMMA, epsilon=EPSILON, iterations_limit=ITERATIONS, mode=NORMAL_TRAINING):
        Q = {state: {action: 0 for action in self.action_space} for state in self.state_space}
        Q_first = copy.deepcopy(Q)
        Q_old = copy.deepcopy(Q)
        Q_intermediate_1 = copy.deepcopy(Q)
        Q_intermediate_2 = copy.deepcopy(Q)
        converged = False
        iterations = 1
        episodes = 0
        state = self.reset()

        while iterations < iterations_limit and not converged:
            # Selecció d'acció amb epsilon-greedy. (Behavorial policy)
            if np.random.rand() < epsilon:
                action = np.random.choice(self.action_space)  # Explora
            else:
                state_actions = Q[state]
                max_value = max(state_actions.values())
                max_actions = [a for a, v in state_actions.items() if v == max_value]
                action = np.random.choice(max_actions)  # Si hi ha accions amb el mateix valor, tria una aleatòriament

            # Realitza l'acció
            next_state, reward, done, invalid = self.step(action, mode)
            if invalid:
                Q[state][action] = -1000000
                continue

            """Actualització Q-learning
                        
            Per tal d'actualitzar la taula Q, utilitzarem una target policy que serà greedy.
            
            Per a fer-ho: 
            1. Primer calculem el td_target que és la suma de la recompensa 
            més el màxim sobre totes les accions possibles del valor Q del següent estat amb cada acció.
            Observem que també tenim un factor de descompte GAMMA per premiar les recompenses a curt termini.
            
            2. Ara calculem l'error temporal (td_error) que és la diferència entre el td_target i el valor Q actual.
            
            3. Actualitzem el valor Q amb el learning rate corresponent.            
                        
            """
            
            if done:       
                # En cas que l'estat sigui terminal, el td_target és la recompensa, 
                # ja que no hi haurà següent estat                         
                td_target = reward
            else:                
                next_state_actions = Q[next_state]
                max_next_Q = max(next_state_actions.values())
                td_target = reward + gamma * max_next_Q

            td_error = td_target - Q[state][action]             
            Q[state][action] += alpha * td_error

            # Comprova convergència a cada episodi (Hem arribat a l'estat terminal)
            if done:
                state = self.reset()
                converged = self.converged(Q, Q_old, THRESHOLD)
                if converged:
                    break
                Q_old = copy.deepcopy(Q)
                episodes += 1
                
                if(episodes == INTERMEDIATE_EPISODES_1):
                    Q_intermediate_1 = copy.deepcopy(Q)
                if(episodes == INTERMEDIATE_EPISODES_2):
                    Q_intermediate_2 = copy.deepcopy(Q)
            else:
                state = next_state

            iterations += 1

        return Q, Q_first, Q_intermediate_1, Q_intermediate_2, iterations, episodes
    
                

def display_q_table(Q, title="Q-table"):
    
    print("*" * 70)
    print(f"{title}\n")
    print("{:<10} {:<10} {:<10} {:<10} {:<10} {:<10}".format('State', 'U', 'D', 'L', 'R', 'Max Q'))
    print("-" * 70)
    for state in sorted(Q.keys()):
        q_values = Q[state]
        u = q_values.get('U', 0.0)
        d = q_values.get('D', 0.0)
        l = q_values.get('L', 0.0)
        r = q_values.get('R', 0.0)
        max_q = max(q_values.values())
        print("{:<10} {:<10.4f} {:<10.4f} {:<10.4f} {:<10.4f} {:<10.4f}".format(
            str(state), u, d, l, r, max_q
        ))
    print("")


def paint_path(path_cells):
    """
    Paints the path on a grid using 1-based indexing.

    Parameters:
    - path_cells (list of tuples): List of cells in the path, each as (row, column) starting from (1,1).

    Returns:
    - str: A string representation of the grid with the path painted.
    """
    # Define special cells with 1-based indexing
    start = (1, 1)
    end = (3, 4)
    obstacle = (2, 2)

    # Determine grid size based on maximum row and column indices
    all_cells = path_cells + [start, end, obstacle]        

    rows, cols = 3, 4

    # Initialize grid with '.'
    grid = [['.' for _ in range(cols)] for _ in range(rows)]

    # Mark the obstacle
    grid[obstacle[0] - 1][obstacle[1] - 1] = 'X'

    # Mark the path
    for cell in path_cells:
        row, col = cell
        if cell == start:
            grid[row - 1][col - 1] = 'S'
        elif cell == end:
            grid[row - 1][col - 1] = 'E'
        elif cell != obstacle:
            grid[row - 1][col - 1] = '*'

    # Ensure start and end are correctly marked even if not in path_cells
    grid[start[0] - 1][start[1] - 1] = 'S'
    grid[end[0] - 1][end[1] - 1] = 'E'

    # Convert grid to string for display with (1,1) at bottom-left
    grid_str = '   ' + ' '.join(str(col) for col in range(1, cols + 1)) + '\n'
    grid_str += '  +' + '--' * cols + '+\n'
    for row_idx in range(rows, 0, -1):  # Start from the top row
        row = grid[row_idx - 1]
        grid_str += f"{row_idx} | " + ' '.join(row) + ' |\n'
    grid_str += '  +' + '--' * cols + '+\n'
    print(grid_str)


         
def display_optimal_path(Q):      
    state = (1, 1)
    path = [state]
    while state != (3, 4):
        state_actions = Q[state]
        max_action = max(state_actions, key=state_actions.get)
        if max_action == "U":
            next_state = (state[0] + 1, state[1])
        elif max_action == "D":
            next_state = (state[0] - 1, state[1])
        elif max_action == "L":
            next_state = (state[0], state[1] - 1)
        elif max_action == "R":
            next_state = (state[0], state[1] + 1)                                                        
        state = next_state
        path.append(state)
        
    print("-" * 70)
    print("Optimal path:")
    print(" -> ".join(map(str, path)))
    print("")                
    paint_path(path)
    print("-" * 70)
    

 

def main():
    env = CustomEnvironment()
    start_time = time.time()
    Q, Q_first, Q_intermediate1, Q_intermediate2, iteracions, episodes = env.train(mode=DRUNKEN_SAILOR)
    end_time = time.time()
    display_q_table(Q_first, title="Q_first")
    display_q_table(Q_intermediate1, title=f"Q-table {INTERMEDIATE_EPISODES_1} Episodies")
    display_q_table(Q_intermediate2, title=f"Q-table {INTERMEDIATE_EPISODES_2} Episodies")    
    display_q_table(Q, title="Q-table")
    print(f"Episodies fins a la convergencia: {episodes}")
    print(f"Iteracions fins a la convergencia: {iteracions}")
    # Mostrem el camí òptim
    display_optimal_path(Q)
    print(f"Temps d'execució: {end_time - start_time:.4f} segons")
if __name__ == "__main__":
    main() 
    
    
# Main per a generar taula de valors per a optimitzar paràmetres
""" def main():
    env = CustomEnvironment()

    # Define parameter ranges
    alpha_values = [round(a, 1) for a in np.arange(0.1, 1.1, 0.1)]
    epsilon_values = [round(e, 1) for e in np.arange(0.1, 1.1, 0.1)]
    gamma = 0.1  # Fixed decay rate

    # Initialize a DataFrame to store the results
    results_table = pd.DataFrame(index=alpha_values, columns=epsilon_values)

    # Grid search over alpha and epsilon
    for alpha in alpha_values:
        for epsilon in epsilon_values:
            _, _, _, _, _, episodes = env.train(alpha=alpha, gamma=gamma, epsilon=epsilon, mode=IMPROVED_TRAINING)
            results_table.at[alpha, epsilon] = episodes

    # Display the results
    print("\nNumber of Episodes to Converge (γ = 0.2)\n")
    print(results_table.astype(int).to_string())

    # Optionally, save the results to a CSV file
    # results_table.to_csv("optimization_results.csv")

if __name__ == "__main__":
    main()
    


         """