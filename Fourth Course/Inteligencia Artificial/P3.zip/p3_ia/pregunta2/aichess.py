#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep  8 11:22:03 2022

@author: ignasi
"""
import chess
import numpy as np
import sys
import copy
import time
import pandas as pd
#import matplotlib.pyplot as plt
from itertools import permutations

NORMAL_TRAINING = 1
IMPROVED_TRAINING = 2
DRUNKEN_SAILOR_FIRST_SCENARIO = 3
DRUNKEN_SAILOR_SECOND_SCENARIO = 4
ERROR_RATE = 0.01
ALPHA = 0.9 # Si convergeix, Aixo es directament proporcional a la velocitat de convergencia
GAMMA = 0.2# Si el conjunt d'estats es petit, el gamma pot ser petit, ja que no hi ha tantes transicions a considerar.
EPSILON = 0.05 # Si augmentes el epsilon, fas que sigui mes lenta la convergencia, pero si et quedes a 0 et pots quedar a un minim local. (En aquest aas el problema es tan senzill que un minim local es un minim global)
ITERATIONS = 100000000
INTERMEDIATE_EPISODES_1 = 10
INTERMEDIATE_EPISODES_2 = 20
THRESHOLD = 10e-4
    
class Aichess():
    

    def __init__(self, TA, myinit=True):

        if myinit:
            self.chess = chess.Chess(TA, True)
        else:
            self.chess = chess.Chess([], False)
        
        self.currentStateW = self.chess.boardSim.currentStateW;        
        self.checkMate = False        
        """
        
        Per tal d'implementar l'algorisme Q-learning volem construir una matriu Q que sigui el més senzilla possible.
        Per a fer-ho, mapegem els estats i les accions a enters. Això ens permetrà accedir a la matriu Q amb els índexs corresponents.
        Ara bé, necessitem poder passar d'estats a index amb cost O(1). Per això utilitzem 2 diccionaris:
        - state_space: Mapeja els identificadors a estats. Aquí els values son estructures de la forma {
            "rook": [rook_x, rook_y, 2],
            "king": [king_x, king_y, 6]
        }
        
        - state_to_id: Mapeja els estats a identificadors. (Les keys son tuples, ja que les llistes no son hashable)                
        
        Repliquem la mateixa idea per a les accions.
        - action_space: Mapeja els identificadors a accions. 
        - action_to_id: Mapeja les accions a identificadors.
            
        Tot i que les funcions no siguin directament una la inversa de l'altra, ens permeten fer la tasca de forma eficient.
        Per a fer-ho tenim la funcio getStateId i getActionId. 
        
        Aquesta construcció permet accedir al Q-value de l'estat i i l'accio j amb Q[i][j] i, j enters.
        """
        self.state_space = {}
        self.state_to_id = {}
        state_id = 0
                                          
        self.current_state = [[7, 0, 2], [7, 4, 6]]                
        # Creem tots els estats possibles
        for rook_x in range(8):
            for rook_y in range(8):
                # Iterem sobre tots els estats possibles del rei
                for king_x in range(8):
                    for king_y in range(8):
                        
                        # Comprovem que la torre o el rei no estigui a la mateixa posició que el rei negre
                        if rook_x == 0 and rook_y == 4 or king_x == 0 and king_y == 4:
                            continue      
                        # Comprovem que el rei blanc no estigui en posició de checkmate per part del rei negre
                        if abs(king_x - 0) <= 1 and abs(king_y - 4) <= 1:
                            continue
                        # Comprovem que la torre i el rei no estiguin a la mateixa posició               
                        if rook_x == king_x and rook_y == king_y:
                            continue                        
                        
                        # Mapegem l'identificador a l'estat
                        self.state_space[state_id] = {
                            "rook": [rook_x, rook_y, 2],  # Rook
                            "king": [king_x, king_y, 6]   # King
                        }
                        # Mapegem l'estat a un identificador
                        self.state_to_id[((rook_x, rook_y, 2), (king_x, king_y, 6))] = state_id
                        state_id += 1
                    
                        
                
        """
        Repliquem la mateixa idea per a les accions. En aquest cas, tenim 36 accions possibles. 28 per la torre i 8 pel rei.
        """
        self.action_space = {}
        self.action_to_id = {}
        action_id = 0

        # Definim les accions de la torre
        rook_directions = ["up", "down", "left", "right"]
        max_rook_distance = 7

        for direction in rook_directions:
            for distance in range(1, max_rook_distance + 1):
                action = {"piece": "rook", "direction": direction, "distance": distance}
                self.action_space[action_id] = action                
                action_key = (action["piece"], action["direction"], action["distance"])
                # De nou, utilitzem una tupla com a key. No podem utilitzar una llista ja que no és hashable
                self.action_to_id[action_key] = action_id
                action_id += 1

        # Definim les accions del rei
        king_directions = [
            "up", "down", "left", "right",
            "up-left", "up-right", "down-left", "down-right"
        ]

        for direction in king_directions:
            action = {"piece": "king", "direction": direction}
            self.action_space[action_id] = action            
            action_key = (action["piece"], action["direction"])
            self.action_to_id[action_key] = action_id
            action_id += 1
                           
        
    def isCheckMate(self, mystate):
        
        # list of possible check mate states
        listCheckMateStates = [[[0,0,2],[2,4,6]],[[0,1,2],[2,4,6]],[[0,2,2],[2,4,6]],[[0,6,2],[2,4,6]],[[0,7,2],[2,4,6]]]

        # Check all state permuations and if they coincide with a list of CheckMates
        for permState in list(permutations(mystate)):
            if list(permState) in listCheckMateStates:
                return True

        return False

    def h(self,state):
        
        if state[0][2] == 2:
            posicioRei = state[1]
            posicioTorre = state[0]
        else:
            posicioRei = state[0]
            posicioTorre = state[1]
        # With the king we wish to reach configuration (2,4), calculate Manhattan distance
        fila = abs(posicioRei[0] - 2)
        columna = abs(posicioRei[1]-4)
        # Pick the minimum for the row and column, this is when the king has to move in diagonal
        # We calculate the difference between row an colum, to calculate the remaining movements
        # which it shoudl go going straight        
        hRei = min(fila, columna) + abs(fila-columna)
        # with the tower we have 3 different cases
        if posicioTorre[0] == 0 and (posicioTorre[1] < 3 or posicioTorre[1] > 5):
            hTorre = 0
        elif posicioTorre[0] != 0 and posicioTorre[1] >= 3 and posicioTorre[1] <= 5:
            hTorre = 2
        else:
            hTorre = 1
        # In our case, the heuristics is the real cost of movements
        return -(hRei + hTorre)
    
    def reset(self, mode=NORMAL_TRAINING):
        self.current_state = [[7, 0, 2], [7, 4, 6]]
        if mode == DRUNKEN_SAILOR_SECOND_SCENARIO:
            self.current_state = [[7, 0, 2], [7, 7, 6]]                
        return self.current_state
        
    
    
    def getStateId(self, state):
            
        """ Funció que converteix una llista a una tupla p. ex. [[7, 0, 2], [7, 4, 6]] a ((7, 0, 2), (7, 4, 6)) 
        i retorna l'identificador de l'estat. 
        
        Hem de comprovar que l'ordre de les peces sigui el correcte.

        Returns:
            int -- Identificador de l'estat
        """
        
        if(state[0][2] == 2 and state[1][2] == 6):
            
            st = ((state[0][0], state[0][1], state[0][2]), (state[1][0], state[1][1], state[1][2]))
            # L'ordre es correcte           
            if st in self.state_to_id:                
                return self.state_to_id[st]
        else:
            # L'ordre està invertit            
            st = ((state[1][0], state[1][1], state[1][2]), (state[0][0], state[0][1], state[0][2]))
            if st in self.state_to_id:
                return self.state_to_id[st]
            
        return -1
    
    def getActionId(self, action):   
        """
        Funció que retorna l'identificador de l'acció donada una acció.
        El que fem es transformar una estructura de la forma: 
        
        {
            "piece": "rook",
            "direction": "up",
            "distance": 1
        }
        
        a una tupla: ("rook", "up", 1) i busquem l'identificador corresponent.
        
        Returns:
            int -- Identificador de l'acció  
        
        """     
        if action["piece"] == "rook":
            key = (action["piece"], action["direction"], action["distance"])
        else:
            key = (action["piece"], action["direction"])
        return self.action_to_id.get(key, None)
    
    
    def step(self, action, mode=NORMAL_TRAINING):
        # Introduir estocasticitat en els modes Drunken Sailor
        if mode == DRUNKEN_SAILOR_FIRST_SCENARIO or mode == DRUNKEN_SAILOR_SECOND_SCENARIO:
            if np.random.rand() < ERROR_RATE:
                action = np.random.choice(list(self.action_space.values()))

        invalid = False
        next_state = copy.deepcopy(self.current_state)
        old_state = copy.deepcopy(self.current_state)
        piece = action["piece"]
        direction = action["direction"]

        # Inicialitza reward i done per evitar errors d'variables no definides
        reward = -100000  # Assigna una penalització per defecte a moviments invàlids
        done = False

        if piece == "rook":
            distance = action["distance"]
            rook_pos = next_state[0] if next_state[0][2] == 2 else next_state[1]
            king_pos = next_state[1] if next_state[1][2] == 6 else next_state[0]

            # Determina els passos per la ruta basant-se en la direcció
            if direction == "up":
                step_x, step_y = -1, 0
            elif direction == "down":
                step_x, step_y = 1, 0
            elif direction == "left":
                step_x, step_y = 0, -1
            elif direction == "right":
                step_x, step_y = 0, 1
            else:
                
                action_executed_id = self.getActionId(action)
                return self.current_state, reward, done, True, action_executed_id

            # Itera sobre cada casella intermitja per comprovar si està buida
            for step in range(1, distance):
                intermediate_x = rook_pos[0] + step_x * step
                intermediate_y = rook_pos[1] + step_y * step
                # Comprova si hi ha una peça en la casella intermitja
                white_king = next_state[1] if next_state[1][2] == 6 else next_state[0]
                black_king = [0, 4, 12]                    
                if(white_king[0] == intermediate_x and white_king[1] == intermediate_y) or (black_king[0] == intermediate_x and black_king[1] == intermediate_y):
                    # Hi ha una peça en la ruta                                    
                    invalid = True
                    action_executed_id = self.getActionId(action)
                    return self.current_state, reward, done, invalid, action_executed_id

            # Comprova que la posició de destinació està dins del tauler
            target_x = rook_pos[0] + step_x * distance
            target_y = rook_pos[1] + step_y * distance
            if not (0 <= target_x < 8 and 0 <= target_y < 8):
                
                invalid = True
                action_executed_id = self.getActionId(action)
                return self.current_state, reward, done, invalid, action_executed_id

            # Actualitza la posició de la torre en el next_state
            rook_pos[0] = target_x
            rook_pos[1] = target_y
            reward = 0  # Assigna recompensa neutral inicialment per moviments vàlids

        elif piece == "king":
            king_pos = next_state[1] if next_state[1][2] == 6 else next_state[0]
            rook_pos = next_state[0] if next_state[0][2] == 2 else next_state[1]

            # Calcula la posició de destinació basada en la direcció
            if direction == "up":
                target_x = king_pos[0] - 1
                target_y = king_pos[1]
            elif direction == "down":
                target_x = king_pos[0] + 1
                target_y = king_pos[1]
            elif direction == "left":
                target_x = king_pos[0]
                target_y = king_pos[1] - 1
            elif direction == "right":
                target_x = king_pos[0]
                target_y = king_pos[1] + 1
            elif direction == "up-left":
                target_x = king_pos[0] - 1
                target_y = king_pos[1] - 1
            elif direction == "up-right":
                target_x = king_pos[0] - 1
                target_y = king_pos[1] + 1
            elif direction == "down-left":
                target_x = king_pos[0] + 1
                target_y = king_pos[1] - 1
            elif direction == "down-right":
                target_x = king_pos[0] + 1
                target_y = king_pos[1] + 1
            else:
                
                action_executed_id = self.getActionId(action)
                return self.current_state, reward, done, True, action_executed_id

            # Comprova que la posició de destinació està dins del tauler
            if not (0 <= target_x < 8 and 0 <= target_y < 8):                
                invalid = True
                action_executed_id = self.getActionId(action)
                return self.current_state, reward, done, invalid, action_executed_id

            # Actualitza la posició del rei en el next_state
            king_pos[0] = target_x
            king_pos[1] = target_y
            reward = 0  # Assigna recompensa neutral inicialment per moviments vàlids

        else:
            print(f"[Error] Tipus de peça desconegut: {piece}")
            action_executed_id = self.getActionId(action)
            return self.current_state, reward, done, True, action_executed_id

        # Comprova si l'estat és vàlid després del moviment
        next_state_id = self.getStateId(next_state)
        if next_state_id == -1:
            self.current_state = old_state
            invalid = True
            reward = -100  # Penalització per estat invàlid
        else:
            self.current_state = next_state

            # Comprovem si és un estat terminal
            done = self.isCheckMate(self.current_state)

            if done:
                if mode == NORMAL_TRAINING:
                    reward = 100
                elif mode in [IMPROVED_TRAINING, DRUNKEN_SAILOR_FIRST_SCENARIO, DRUNKEN_SAILOR_SECOND_SCENARIO]:
                    reward = self.h(self.current_state)
            else:
                if mode == NORMAL_TRAINING:
                    reward = -1
                elif mode in [IMPROVED_TRAINING, DRUNKEN_SAILOR_FIRST_SCENARIO, DRUNKEN_SAILOR_SECOND_SCENARIO]:
                    reward = self.h(self.current_state)

        # Determina l'ID de l'acció executada
        action_executed_id = self.getActionId(action)

        return self.current_state, reward, done, invalid, action_executed_id
    
    def reconstructPath(self, initialState,Q_table, mode=NORMAL_TRAINING):
        """
        Reconstrueix el camí òptim a partir de la matriu Q.

        Input:
        - initialState (list): Estat inicial del taulell. Per exemple  [[7, 0, 2], [7, 4, 6]]

        Returns:
        - path (list): Llista d'estats que formen el camí òptim
        """

        currentStateId = self.getStateId(initialState)
        self.current_state = initialState

        checkMate = False

        # Inicialitzem el camí amb l'estat inicial
        path = [initialState]
        path_actions = []
        passos = 0
        while not checkMate and passos < 100:
            actions = Q_table[currentStateId]
            maxQ = -10000000
            maxActionId = -1
            # Obtenim l'acció amb el valor Q més alt
            for actionId in actions.keys():
                qValue = actions[actionId]
                if maxQ < qValue:
                    maxQ = qValue
                    maxActionId = actionId
            
            # Només volem que ens retorni l'estat que es dona després de fer l'acció
            state = self.step(self.action_space[maxActionId], mode)[0]
            path_actions.append(self.action_space[maxActionId])
            # Afegim l'estat al camí
            path.append(state)
            currentStateId = self.getStateId(state)

            # Comprovem si hem arribat a un estat terminal
            if self.isCheckMate(state):
                checkMate = True
            passos += 1
            
        # Si hi ha més de 100 moviments, no hem arribat a cap solució        
        
        if passos == 100:
            path = []
        
        return path, path_actions    
    
    def train(self, alpha=ALPHA, gamma=GAMMA, epsilon=EPSILON, iterations_limit=ITERATIONS, mode=NORMAL_TRAINING):        
        """
        Entrena l'agent utilitzant l'algorisme Q-learning amb una criteri de convergència millorada.
        """
        print("[i] Optimitzant matriu Q-learning...")
        
        # Inicialització de la matriu Q amb valors inicials de 0.0
        Q = {state: {action: 0.0 for action in self.action_space.keys()} for state in self.state_space.keys()}                        
        
        converged = False
        iterations = 0
        episodes = 0
        state = self.reset()
        state_id = self.getStateId(state)        
        max_delta = 0  # Canvi màxim en Q-valors durant l'episodi
        
        while iterations < iterations_limit and not converged:
            # Selecció d'acció amb política epsilon-greedy
            if np.random.rand() < epsilon:
                # Exploració: tria una acció aleatòria
                action_id = np.random.choice(list(self.action_space.keys()))
                action = self.action_space[action_id]
            else:
                # Explotació: tria l'acció amb el màxim valor Q per a l'estat actual
                state_actions = Q[state_id]
                max_value = max(state_actions.values())
                # Gestiona múltiples accions amb el mateix valor Q
                max_actions = [a for a, v in state_actions.items() if v == max_value]                
                action_id = np.random.choice(max_actions)
                action = self.action_space[action_id]                

            # Realitza l'acció seleccionada
            next_state, reward, done, invalid, action_executed_id = self.step(action, mode)
            
            if invalid:
                # Penalització per acció invàlida
                Q[state_id][action_executed_id] = -100000                
                continue

            # Càlcul del td_target
            if done:       
                # Estat terminal: el target és només la recompensa
                td_target = reward
            else:
                # Estat no terminal: recompense més el millor Q del següent estat
                next_state_id = self.getStateId(next_state)                
                next_state_actions = Q[next_state_id]
                max_next_Q = max(next_state_actions.values())
                td_target = reward + gamma * max_next_Q

            # Càlcul de l'error temporal
            td_error = td_target - Q[state_id][action_executed_id]             
            # Actualització del valor Q
            Q[state_id][action_executed_id] += alpha * td_error  
            
            # Calcula el canvi absolut en el valor Q
            delta = abs(alpha * td_error)
            
            # Actualitza el màxim delta si és necessari
            if delta > max_delta:
                max_delta = delta
            
            # Si l'episodi ha acabat, verifica la convergència
            if done:
                episodes += 1                                
                if max_delta < THRESHOLD:
                    converged = True                                                    
                
                # Reinicia l'episodi
                state = self.reset()
                state_id = self.getStateId(state)
                max_delta = 0  # Reseteja el màxim delta per al següent episodi
                                            
                
            else:
                # Continua amb el següent estat dins del mateix episodi
                state = next_state
                state_id = self.getStateId(state)

            iterations += 1
           
        return Q, {}, iterations, episodes
            
    """
    Mètodes per imprimir els moviments de les peces. 
    """
    
    def printMovements(self, path):
        """
        Imprimeix els moviments de les peces a partir del camí òptim.
        """            
        print("[i] Imprimint moviments: ")
        self.chess.board.print_board()
        for i in range(1, len(path)):
            movement = self.getMovement(path[i-1], path[i])
            self.chess.move(movement[0], movement[1])
            self.chess.board.print_board()

            
    #Mètodes de la pràctica 2
    def getPieceState(self, state, piece):
        pieceState = None
        for i in state:
            if i[2] == piece:
                pieceState = i
                break
        return pieceState

    def getMovement(self, state, nextState):
        #Donat un estat i un estat successor, retornem la posició de la peça moguda en tots dos estats,
        pieceState = None
        pieceNextState = None
        for piece in state:
            if piece not in nextState:
                movedPiece = piece[2]
                pieceNext = self.getPieceState(nextState, movedPiece)
                if pieceNext != None:
                    pieceState = piece
                    pieceNextState = pieceNext
                    break

        return [pieceState, pieceNextState]
            
# Si volem, també podem utilitzar la llibreria matplotlib per a visualitzar els passos dels moviments de les peces.
# Tot i que la representació és més estètica, també és més lenta.                              
def draw_chessboard(steps, states, title="Chess Steps"):
    fig, axes = plt.subplots(2, 4, figsize=(12, 12))  # Crea una graella per a 8 passos
    axes = axes.ravel()  # Aplanar els eixos per a accés fàcil
    
    # Coordenades de les peces
    piece_symbols = {2: "♜", 6: "♔", 12: "♚"}  # Torre blanca, Rei blanc, Rei negre
    
    # Dibuix de cada estat/pas
    for step, (state, ax) in enumerate(zip(states, axes)):
        if step > 0:
            if steps[step-1]["piece"] == "rook":
                piece = "Torre"
                direction = steps[step-1]["direction"]
                distance = steps[step-1]["distance"]
                ax.set_title(f"Step {step}: Move {piece} {direction} {distance}")
            else:
                ax.set_title(f"Step {step}: Move Rei {steps[step-1]['direction']}")
        else:
            ax.set_title(f"Step {step}: Initial State")
        # Creem el patró de quadres del tauler
        board = np.zeros((8, 8))
        for i in range(8):
            for j in range(8):
                board[i, j] = (i + j) % 2  # Blanc o negre
        
        # Dibuixem el tauler
        ax.imshow(board, cmap="gray", extent=[0, 8, 0, 8])
        state.append([0, 4, 12])
        # Afegim les peces en les posicions donades
        for piece in state:
            x, y, num = piece  # Obtenim la fila, columna i tipus de peça
            color = "red" if num in [2, 6] else "blue"  # Color segons tipus de peça
            ax.text(y + 0.5, 7 - x + 0.5, piece_symbols[num], 
                    color=color, ha="center", va="center", fontsize=20)
        
        ax.axis("off")  # Traiem els eixos

    # Amagar els subplots no utilitzats
    for i in range(len(states), len(axes)):
        fig.delaxes(axes[i])
    
    plt.tight_layout()
    plt.show()

"""
Funcions per a la configuració de l'entrenament
""" 
def get_user_input(prompt, default, cast_func):
    user_input = input(f"{prompt} per defecte: {default}: ")
    if user_input.strip() == "":
        return default
    try:
        return cast_func(user_input)
    except ValueError:
        print("Entrada invàlida. S'utilitzara el valor per defecte.")
        return default

def configurar_train():
    print("[i] Configura els paràmetres de l'algorisme")
    alpha = get_user_input("Alpha (taxa d'aprenentatge)", ALPHA, float)
    gamma = get_user_input("Gamma (factor de descompte)", GAMMA, float)
    epsilon = get_user_input("Epsilon (taxa d'exploració)", EPSILON, float)    
    
    print("-" * 70)
    # Selección del modo de entrenamiento
    print("[i] Selecciona el mode d'entrenament:")
    print("1. Normal")
    print("2. Millorat")
    print("3. Drunken Sailor 1")
    print("4. Drunken Sailor 2")
    mode_input = input(f"[i] Mode per defecte: {IMPROVED_TRAINING}: ")
    if mode_input.strip() == "":
        mode = IMPROVED_TRAINING
    elif mode_input == "1":
        mode = NORMAL_TRAINING
    elif mode_input == "2":
        mode = IMPROVED_TRAINING
    elif mode_input == "3":
        mode = DRUNKEN_SAILOR_FIRST_SCENARIO
    elif mode_input == "4":
        mode = DRUNKEN_SAILOR_SECOND_SCENARIO
    else:
        print("Entrada invàlida. S'utilitzara el mode per defecte.")
        mode = IMPROVED_TRAINING
    
    return alpha, gamma, epsilon, mode


def main():
    if len(sys.argv) < 1:
        sys.exit(1)

    # intiialize board
    TA = np.zeros((8, 8))
    # load initial state
    # white pieces
    TA[7][0] = 2
    TA[7][4] = 6
    TA[0][4] = 12
    
    # initialise bord
    aichess = Aichess(TA, True)
    initialState = [[7, 0, 2], [7, 4, 6]]
        
    print("-" * 70)
    alpha, gamma, epsilon, mode = configurar_train()
    #alpha, gamma, epsilon, mode = ALPHA, GAMMA, EPSILON, DRUNKEN_SAILOR_FIRST_SCENARIO


    
    start_time = time.perf_counter()
    Q_table, _, iterations, episodes = aichess.train(alpha=alpha, gamma= gamma, epsilon=epsilon,mode=mode)
    reconstructed_path, _ = aichess.reconstructPath(initialState, Q_table)
    
    end_time = time.perf_counter()
    print("-" * 70)
    print("[i] Entrenament acabat en: ")            
    print("Episodes: ", episodes)
    print("Iterations: ", iterations) 
    elapsed_time = end_time - start_time
    print(f"Temps d'entrenament: {elapsed_time:.4f} segons")        
    print(f"{len(reconstructed_path)-1} moviments" )    
    print("-" * 70)

    print("[i] Optimal path:")
    print(" -> ".join(map(str, reconstructed_path)))
    print("-" * 70)

     
    print_movements = input("Vols imprimir els moviments de les peces? (s/n): ").strip().lower()
    if print_movements == '' or print_movements == 's':
        aichess.printMovements(reconstructed_path)      
    
    #draw_chessboard(steps, reconstructed_path)
    
    
    
    

if __name__ == "__main__":
    main()